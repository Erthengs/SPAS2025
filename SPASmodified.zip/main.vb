﻿Imports System.ComponentModel.DataAnnotations
Imports System.Data.Entity
Imports System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder
Imports System.Data.Entity.Core.Common.EntitySql
Imports System.Data.Entity.Migrations
Imports System.IO
Imports System.Linq.Expressions
Imports System.Management.Instrumentation
Imports System.Reflection
Imports System.Security.Cryptography
Imports System.Windows.Forms.VisualStyles
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar
Imports System.Xml
Imports Microsoft.EntityFrameworkCore.Metadata.Internal
Imports Microsoft.EntityFrameworkCore.Query.Internal
Imports Microsoft.EntityFrameworkCore.Query.SqlExpressions
Imports Microsoft.VisualBasic.Devices
Imports Npgsql
Imports NpgsqlTypes
Imports System.Diagnostics
Imports System.Refection

Public Class SPAS
    Private Const V As Boolean = False
    Private oldend_date As Date
    Private current_tabpage As Integer
    Private current_tabpage_basis As Integer
    Public isManualChange As Boolean = False
    Private isProgrammaticChange As Boolean = True
    Private originalValues As New Dictionary(Of String, Object)
    Private editingControl As System.Windows.Forms.TextBox
    Private originalValue As Object ' Stores the original cell value
    'bekende fouten



    '========================================================================================================
    '======                                                                                            ======
    '======                                 A L G E M E E N                                            ======
    '======                                                                                            ======
    '========================================================================================================
    Private Sub SPAS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Login.ShowDialog()
        AttachHandlers(Me.Controls)
    End Sub

    Private Sub FieldChangedHandler(sender As Object, e As EventArgs)
        ' Enable Save and Cancel, disable other buttons
        'als er een veld gewijzigd wordt komt SPAS in edit modus
        ' Get the name of the calling method
        Dim stackTrace As New StackTrace()
        Dim callingMethod As MethodBase = stackTrace.GetFrame(1)?.GetMethod()
        Dim callerName As String = If(callingMethod IsNot Nothing, callingMethod.Name, "Unknown")

        ' Show the calling procedure name
        'MessageBox.Show($"Called from:{callerName} -- Manualchange:{isManualChange}")

        '
        If Not isManualChange Then Return

        Enable_Buttons(True, False)
        If TC_Main.SelectedIndex = 0 Then Lbx_Basis.Enabled = False
        If TC_Main.SelectedIndex = 1 Then Dgv_Bank.Enabled = False
        'MsgBox($"{sender.GetType().Name} changed. IsmanualChange: {isManualChange}")
    End Sub
    Private Sub AttachHandlers(controls As Control.ControlCollection)
        Dim excludedPanels As New List(Of String) From {"Testpanel", "Pan_bank", "Pan_Bank2"}

        For Each ctrl As Control In controls

            If TypeOf ctrl Is System.Windows.Forms.TextBox AndAlso Not excludedPanels.Contains(ctrl.Parent.Name) Then
                AddHandler DirectCast(ctrl, System.Windows.Forms.TextBox).TextChanged, AddressOf FieldChangedHandler
            ElseIf TypeOf ctrl Is System.Windows.Forms.ComboBox AndAlso Not excludedPanels.Contains(ctrl.Parent.Name) Then
                AddHandler DirectCast(ctrl, System.Windows.Forms.ComboBox).SelectedIndexChanged, AddressOf FieldChangedHandler
            ElseIf TypeOf ctrl Is System.Windows.Forms.RadioButton AndAlso Not excludedPanels.Contains(ctrl.Parent.Name) Then
                AddHandler DirectCast(ctrl, System.Windows.Forms.RadioButton).CheckedChanged, AddressOf FieldChangedHandler
            ElseIf TypeOf ctrl Is System.Windows.Forms.DateTimePicker AndAlso Not excludedPanels.Contains(ctrl.Parent.Name) Then
                AddHandler DirectCast(ctrl, System.Windows.Forms.DateTimePicker).ValueChanged, AddressOf FieldChangedHandler
            ElseIf TypeOf ctrl Is System.Windows.Forms.CheckBox AndAlso Not excludedPanels.Contains(ctrl.Parent.Name) Then
                AddHandler DirectCast(ctrl, System.Windows.Forms.CheckBox).CheckedChanged, AddressOf FieldChangedHandler
            ElseIf TypeOf ctrl Is System.Windows.Forms.DataGridView AndAlso Not excludedPanels.Contains(ctrl.Parent.Name) Then
                AddHandler DirectCast(ctrl, System.Windows.Forms.DataGridView).CellValueChanged, AddressOf FieldChangedHandler
                'AddHandler DirectCast(ctrl, System.Windows.Forms.DataGridView).CurrentCellDirtyStateChanged, AddressOf DataGridViewDirtyStateChanged
            End If

            ' Recursively handle nested controls
            If ctrl.HasChildren Then
                AttachHandlers(ctrl.Controls)
            End If
        Next
    End Sub

    Private Sub TabControl_Selected(sender As Object, e As TabControlEventArgs) Handles TC_Main.Selected
        'dit is tijdelijk, zolang de save-button niet enabled/disabled moet worden
        current_tabpage = TC_Main.SelectedIndex
    End Sub

    Sub Enable_Buttons(ByVal SaveCancel As Boolean, AddDelete As Boolean)


        MenuSave.Enabled = SaveCancel
        MenuCancel.Enabled = SaveCancel

        MenuAdd.Enabled = AddDelete
        MenuDelete.Enabled = AddDelete
    End Sub

    Private Sub TC_Main_Selecting(sender As Object, e As TabControlCancelEventArgs) Handles TC_Main.Selecting, TC_Object.Selecting
        'If current_tabpage = 1 Then 'workaround omdat in tabpage bank het uitsc

        'Else
        If MenuSave.Enabled Or MenuCancel.Enabled Then
            MessageBox.Show("Bewaar of annuleer de huidige bewerking.", "Actie Nodig", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            e.Cancel = True
        End If
        'Enable_Buttons(False, False)
    End Sub
    'Private Sub TC_Object_Selecting(sender As Object, e As TabControlCancelEventArgs) Handles TC_Object.Selecting
    ' Check if Save or Cancel buttons are enabled
    'If MenuSave.Enabled Or MenuCancel.Enabled Then
    'MessageBox.Show("Bewaar of annuleer de huidige bewerking.", "Actie Nodig", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    'e.Cancel = True
    'End If
    'End Sub



    Sub StoreInitialValues(controls As Control.ControlCollection)
        'MsgBox("original values stored")
        For Each ctrl As Control In controls
            If TypeOf ctrl Is System.Windows.Forms.TextBox Then
                originalValues(ctrl.Name) = DirectCast(ctrl, System.Windows.Forms.TextBox).Text
            ElseIf TypeOf ctrl Is System.Windows.Forms.ComboBox Then
                originalValues(ctrl.Name) = DirectCast(ctrl, System.Windows.Forms.ComboBox).SelectedIndex
            ElseIf TypeOf ctrl Is System.Windows.Forms.CheckBox Then
                originalValues(ctrl.Name) = DirectCast(ctrl, CheckBox).Checked
            ElseIf TypeOf ctrl Is System.Windows.Forms.RadioButton Then
                originalValues(ctrl.Name) = DirectCast(ctrl, RadioButton).Checked
            ElseIf TypeOf ctrl Is System.Windows.Forms.DateTimePicker Then
                originalValues(ctrl.Name) = DirectCast(ctrl, DateTimePicker).Value
            End If

            ' Recursively handle nested controls
            If ctrl.HasChildren Then
                StoreInitialValues(ctrl.Controls)
            End If
        Next
    End Sub

    Sub Show_buttons()
        'Knoppen
        Dim i = TC_Main.SelectedIndex
        Dim j = TC_Boeking.SelectedIndex
        'CRUD-knoppen
        MenuAdd.Visible = (i = 0) Or (i = 4 And j = 2)
        MenuSave.Visible = i = 0 Or i = 2 Or i = 3 Or (i = 4 And j < 3) Or i = 6 Or i = 1
        MenuCancel.Visible = i = 0 Or i = 3 Or (i = 4 And j < 3) Or i = 6 Or i = 1
        MenuDelete.Visible = i = 0 Or i = 2 Or i = 3 Or (i = 4 And j < 3 And j <> 1) Or i = 6
        'Outputknoppen
        Menu_Print.Visible = (i = 2 Or i = 3)
        Menu_Export.Visible = (i > 0 And i <> 4) Or (i = 4 And (j = 1 Or j = 3))
        'Knoppen specifiek voor bank
        MenuCategoriseer.Visible = (i = 1)
        MenuBanktransactie.Visible = (i = 1)
        MenuUploadAlles.Visible = (i = 1)
    End Sub

    Sub InitLoad()
        If username = "" Then Exit Sub

        RunSQL("Update contract Set Active ='false' where enddate < current_date", "NULL", "SPAS_Load")
        Load_Comboboxes()
        TC_Object.SelectedIndex = 0

        Load_Table()
        If Lbx_Basis.Items.Count = 0 Then Empty_Tabpage()
        nocat = QuerySQL("SELECT value FROM settings WHERE label='nocat'")
        Load_Account_Settings()
        report_year = QuerySQL("select min(extract (year from date)) from journal")

        Dim sql = $"SELECT module, name, sql from query where category = 'Overzicht' order by module, name;"
        Populate_DataTree(sql, ReportTree)
        sql = $"select g.name, a.name  from account a left join accgroup g on g.id = a.fk_accgroup_id where a.active = true and g.active = true order by g.name, a.name"
        Populate_DataTree_New(sql, AccountTree)
        Show_buttons()

    End Sub


    '========================================================================================================
    '======                                                                                            ======
    '======                              C O M B O B O X E N                                           ======
    '======                                                                                            ======
    '========================================================================================================
    Sub Load_Cmx_Bank_Account()
        Load_Combobox(Cmx_Bank_Account, "id", "name", "SELECT a.id, a.name FROM account a WHERE a.active = True ORDER BY a.source, a.name")
    End Sub


    Sub Load_Comboboxes()
        'can go wrong if tables are empty
        Load_Cmx_Bank_Account()
        Load_Combobox(Cmx_01_cp__fk_bankacc_id, "id", "name", "SELECT ba.id, ba.name||'/'||ba.accountno as name FROM bankacc ba WHERE ba.expense=True AND ba.active=TRUE ORDER BY ba.name")
        Load_Combobox(Cmx_Incasso_Bankaccount, "id", "name", "SELECT ba.id, ba.accountno AS name FROM bankacc ba WHERE ba.expense=FALSE AND ba.active=TRUE ORDER BY name")
        Load_Combobox(Cmx_01_Target__fk_cp_id, "id", "name", "SELECT cp.id, CONCAT(cp.name, ', ', cp.name_add) as name FROM cp WHERE cp.active=True ORDER BY cp.name")
        Load_Combobox(Cmx_00_contract__fk_relation_id, "id", "name", "SELECT r.id, CONCAT(r.name, ', ', r.name_add) as name FROM relation r WHERE r.active=TRUE ORDER BY r.name")
        Load_Combobox(Cmbx_journaalposten_relatie, "id", "name", "SELECT r.id, CONCAT(r.name, ', ', r.name_add) as name FROM relation r ORDER BY name")
        Load_Combobox(Cmbx_journaalposten_account, "id", "name", "SELECT a.id, a.name FROM account a ORDER BY name")
        Load_Combobox(Cmx_Bank_bankacc, "id", "name", "SELECT ba.id, CONCAT(ba.Name, '/', ba.accountno) as name FROM bankacc ba ORDER BY ba.name DESC")

        Load_Combobox(Cmx_00_Contract__fk_account_id, "id", "name", "SELECT a.id, CONCAT(a.id, ' ',a.name) As name FROM account a
                                          WHERE a.active=TRUE AND a.source='cat' AND a.type = 'Inkomsten' ORDER BY a.name")
        Load_Combobox(Cmx_01_account__fk_accgroup_id, "id", "name", "SELECT ag.id, ag.name FROM accgroup ag WHERE ag.active=True ORDER BY ag.name")
        Populate_Single_Combobox(Cmbx_Reporting_Year, "select distinct extract (year from date) As Year from journal_archive 
                                            union select distinct min(extract (year from date)) from journal")

        Populate_Combobox(Cmbx_Overboeking_Bron, "select a.id, a.name, sum(j.amt1) from journal j left join account a on a.id=j.fk_account 
        WHERE a.active=True group by a.id, a.name having sum(amt1)>0::money ORDER BY a.name")
        Populate_Combobox(Cmbx_Overboeking_Target, "select a.id, a.name, sum(j.amt1), a.id from journal j left join account a on a.id=j.fk_account 
        WHERE a.active=True group by a.id, a.name ORDER BY a.name")
        Fill_Cmx_Journal_List()

        If Me.Dgv_Mgnt_Tables.Rows(8).Cells(1).Value > 0 Then
            Load_Combobox(Cmx_01_contract__fk_target_id, "id", "name", "SELECT id, name||', '||name_add as name FROM target WHERE active=TRUE ORDER BY name")
        End If
        '@@@ hier gaat iets fout
        Fill_Cmx_Excasso_Select_Combined()
        Me.Cmbx_journaalposten_account.SelectedIndex = -1
        Me.Cmbx_journaalposten_relatie.SelectedIndex = -1
        Cmbx_Overboeking_Bron.SelectedIndex = -1
        Cmbx_Overboeking_Target.SelectedIndex = -1

    End Sub





    '========================================================================================================
    '======                                                                                            ======
    '======                         B A S I S A D M I N I S T R A T I E                                ======
    '======                                                                                            ======
    '========================================================================================================

    Sub TC_Object_Click(sender As Object, e As EventArgs) Handles TC_Object.Click, TC_Object.SelectedIndexChanged
        If Not MenuSave.Enabled Then
            isManualChange = False
            Load_Table()
            isManualChange = True
            Enable_Buttons(False, True)
        End If
        'current_tabpage_basis = TC_Object.SelectedIndex
    End Sub

    '************************************      TARGET    *****************************************
    Private Sub Rbtn_Target_Child_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Target_Child.CheckedChanged
        If MenuSave.Enabled Then Tbx_01_Target__ttype.Text = Rbtn_Target_Child.Text
    End Sub

    Private Sub Rbtn_Target_Elder_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Target_Elder.CheckedChanged
        If MenuSave.Enabled Then Tbx_01_Target__ttype.Text = Rbtn_Target_Elder.Text
    End Sub

    Private Sub Rbtn_Target_Other_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Target_Other.CheckedChanged
        If MenuSave.Enabled Then Tbx_01_Target__ttype.Text = Rbtn_Target_Other.Text
    End Sub


    Sub Basis_Add()

        Dim t As String = TC_Object.SelectedIndex.ToString

        Add_Mode = True
        Manage_Buttons_Target(False, False, False, True, True, "Menu_Add_Click")
        Empty_Tabpage()


        If TC_Object.SelectedIndex = 0 Then  'additional functionality for contract management

            Dtp_31_contract__startdate.Value = Date.Today
            Me.Rbn_00_contract_child.Checked = True
            Rbn_00_contract_child.Checked = True
            '---------------- Temp solution of error
            Lbl_00_Contract__name.Text = Contract_number("K")
            Load_Combobox(Cmx_01_contract__fk_target_id, "id", "name", "Select id, Name||', '||name_add as name FROM target
                                                        WHERE ttype='" & Rbn_00_contract_child.Text & "' AND active= TRUE ORDER BY name")
            '-------standaard_waarden ophalen

            Tbx_11_Contract__donation.Text = QuerySQL("select value from settings where label ilike 'standaard_bedrag_kind'")
            Tbx_11_contract__overhead.Text = QuerySQL("select value from settings where label ilike 'standaard_overhead_kind'")
            Dtp_31_contract__startdate.Value = New DateTime(Date.Today.Year, Date.Today.Month, 1).AddMonths(1)
            '----------------

            Handle_Contract_Fields()
            Cmx_02_Contract__term.Text = 12
            Pan_Contract_Date_New.Visible = False
            Cbx_00_contract__active.Checked = True
            Rbn_00_contract_child.Checked = True
            Pan_contract_select_target.Enabled = True
            Lbl_00_Contract__name.Text = Contract_number("K")
            Load_Combobox(Cmx_01_contract__fk_target_id, "id", "name", $"SELECT id, 
            name||', '||name_add) as name FROM target WHERE ttype='{Rbn_00_contract_child.Text}' And active=true ORDER BY name")
            Cmx_01_contract__fk_target_id.Text = ""
            Chx_00_contract__autcol.Enabled = False

        End If
        If TC_Object.SelectedIndex = 1 Then
            Pan_Target.Enabled = True
            Cbx_00_target__active.Checked = True
            Dtp_00_Target__birthday.Value = Date.Today
        ElseIf TC_Object.SelectedIndex = 4 Then
            ' = True
            Cbx_00_Account__active.Checked = True
            Lbl_00_Account__source.Text = "cat"
            Lbl_20_Account__f_key.Text = QuerySQL("SELECT Max(f_key) FROM account Where source='cat'") + 1
            Tbx_01_Account__name.Enabled = True
            Lbl_00_pkid.Text = ""

        End If

    End Sub

    Sub Cancel()
        'isManualChange = False
        Select_Obj2("Cancel")
        Manage_Buttons_Target(True, True, True, False, False, "Cancel")
        Add_Mode = False
        Pan_Target.Enabled = False
        Pan_contract_select_target.Enabled = False

        If TC_Object.SelectedIndex = 0 Then  'additional functionality for contract management
            Handle_Contract_Fields()
            Pan_Contract_Date_New.Visible = False
        End If
        If TC_Object.SelectedIndex = 4 Then
            Lbl_Account_Budget_Difference.Text = ""
        End If


    End Sub

    Sub Basis_Save()
        Dim tbl As String = Me.TC_Object.TabPages(Me.TC_Object.SelectedIndex).Name
        Dim val, val2 As Integer
        Dim errmsg = Handle_errors("")
        If errmsg <> "" Then
            MsgBox(errmsg)
            Exit Sub
        End If
        If Lbx_Basis.SelectedIndex = 6 Then
            If Cbx_00_BankAcc__income.Checked And (Tbx_00_BankAcc__bic.Text = "" Or Tbx_00_BankAcc__id2.Text = "") Then
                MsgBox("Voor inkomstenaccounts is het invullen van BIC en bankidnummer verplicht")
                Exit Sub
            End If
        End If
        'check uitvoeren op overlappende contracten met hetzelfde sponsordoel...

        If Lbx_Basis.SelectedIndex <> -1 Then val = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember)

        Select Case TC_Object.SelectedIndex
            Case 0
                If Add_Mode Then

                    Insert_into_table() 'regular adding to database
                    val = Convert.ToInt32(QuerySQL("Select MAX(id) FROM " & tbl))
                    reload = True

                Else 'change mode

                    'relation, target and target type can never be changed; this would imply another contract
                    'description may be changed freely -- now not possible

                    'Handle_Contract_Fields()
                    If Dtp_30_Contract_Change.Visible = True Then   'new version of the contract / edit_mode

                        '1 Close current contract by updating enddate and active if applicable
                        Dim d1, d2 As DateTime
                        Dim act As Boolean

                        d1 = Me.Dtp_30_Contract_Change.Value
                        Dim _d1 As String = d1.Year & "-" & d1.Month & "-" & d1.Day
                        d2 = New DateTime(d1.Year, d1.Month, d1.Day).AddDays(-1)
                        act = d2 > Date.Today
                        Dim _d2 As String = d2.Year & "-" & d2.Month & "-" & d2.Day
                        Dim sqlstr, msg As String
                        sqlstr = "UPDATE contract SET enddate='" & _d2 & "', active=" & act & " WHERE id=" & val & ";"

                        '2 Create a new contractversion 
                        sqlstr &= $"INSERT INTO public.contract(fk_target_id, fk_relation_id, 
                                    donation, overhead, description, autcol, name, term,intern, fk_account_id) 
                                    SELECT fk_target_id, fk_relation_id, 
                                    donation, overhead, description, autcol, name, term,  
                                    intern, fk_account_id FROM contract WHERE id={val};"


                        RunSQL(sqlstr, "NULL", "MenuSave.Click upsert new version")

                        val2 = Convert.ToInt32(QuerySQL("Select MAX(id) FROM " & tbl))
                        '3 update new version with new values, startdate / enddate and active
                        sqlstr = "UPDATE contract SET startdate='" & _d1 & "', 
                           donation='" & Cur2(Replace(Tbx_11_Contract__donation.Text, ".", "")) & "', 
                           overhead='" & Cur2(Replace(Tbx_11_contract__overhead.Text, ".", "")) & "', 
                           enddate ='2999-12-31',active=true  
                           WHERE id=" & val2 & ";"

                        'MsgBox(Cur2(Replace(Tbx_11_Contract__donation.Text, ".", "")))
                        RunSQL(sqlstr, "NULL", "MenuSave.Click update New version")
                        'reload = True
                        msg = "Een nieuwe versie van het contract is aangemaakt."
                        If act Then msg &= "De wijziging gaat in in de toekomst (nu nog inactief); wilt u de laatste versie nu bekijken?"

                        val = val2
                        reload = True
                        Pan_Contract_Date_New.Visible = False

                    Else
                        'updating description in the regular way
                        val = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember)
                        Update_table()
                    End If
                    Dim acc_id As Integer = QuerySQL("select id from account where source = 'Doel' and f_key=" & Cmx_01_contract__fk_target_id.SelectedValue)
                    Calculate_Budget(acc_id)
                End If
            Case 1
                Dim tmp_cp = Cmx_01_Target__fk_cp_id.SelectedText

                Pan_contract_select_target.Enabled = False
                Pan_Target.Enabled = False
                If Add_Mode Then
                    Insert_into_table()
                    val = Convert.ToInt32(QuerySQL("Select MAX(id) FROM " & tbl))
                    reload = True

                Else
                    val = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember)
                    Update_table()
                End If
                Cmx_01_Target__fk_cp_id.SelectedText = tmp_cp


            Case Else
                Pan_contract_select_target.Enabled = False
                Pan_Target.Enabled = False
                If Add_Mode Then
                    Insert_into_table()
                    val = Convert.ToInt32(QuerySQL("Select MAX(id) FROM " & tbl))
                    reload = True

                Else
                    val = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember)
                    Update_table()
                End If
        End Select

        If reload Then
            Load_Table()
            Locate_Listbox_Position(val)

        End If
        'finalizing
        Manage_Buttons_Target(True, True, True, False, False, "MenuSave.Click")
        Add_Mode = False
        reload = False
    End Sub


    Private Sub Lbx_Basis_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lbx_Basis.SelectedIndexChanged

        If InStr(sender.ToString, "System.Data.DataRowView") > 0 Then Exit Sub
        Click_Lbx_Basis()

    End Sub
    Private Sub Lbx_Basis_Click(sender As Object, e As EventArgs) Handles Lbx_Basis.Click
        If InStr(sender.ToString, "System.Data.DataRowView") > 0 Then Exit Sub
        'Click_Lbx_Basis()
    End Sub
    Sub Click_Lbx_Basis()
        If Lbx_Basis.Items.Count > 0 Then
            Select_Obj2("Lbx_Basis_SelectedIndexChanged")
        Else
            Empty_Tabpage()
        End If
    End Sub
    Private Sub Tbx_Target__ttype_TextChanged(sender As Object, e As EventArgs) Handles Tbx_01_Target__ttype.TextChanged
        Rbtn_Target_Child.Checked = Strings.Trim(Tbx_01_Target__ttype.Text) = "Kind"
        Rbtn_Target_Elder.Checked = Strings.Trim(Tbx_01_Target__ttype.Text) = "Oudere"
        Rbtn_Target_Other.Checked = Strings.Trim(Tbx_01_Target__ttype.Text) = "Overig"
        '@@@ hard value vervangen door tt_type.Text
    End Sub
    Private Sub Rbtn_Target_Alone_CheckedChanged(sender As Object, e As EventArgs)
        If MenuSave.Enabled Then Tbx_00_Target__living.Text = Rbtn_Target_Alone.Text
    End Sub

    Private Sub Rbtn_Target_Institution_CheckedChanged(sender As Object, e As EventArgs)
        If MenuSave.Enabled Then Tbx_00_Target__living.Text = Rbtn_Target_Institution.Text
    End Sub

    Private Sub Rbtn_Target_OtherHousing_CheckedChanged(sender As Object, e As EventArgs)
        If MenuSave.Enabled Then Tbx_00_Target__living.Text = Rbtn_Target_OtherHousing.Text
    End Sub

    Private Sub Tbx_Target__living_TextChanged(sender As Object, e As EventArgs) Handles Tbx_00_Target__living.TextChanged
        Rbtn_Target_Alone.Checked = Strings.Trim(Tbx_00_Target__living.Text) = "Alleen"
        Rbtn_Target_Institution.Checked = Strings.Trim(Tbx_00_Target__living.Text) = "Tehuis"
        Rbtn_Target_OtherHousing.Checked = Strings.Trim(Tbx_00_Target__living.Text) = "Overig"
    End Sub

    Private Sub Tbx_Target__income_TextChanged(sender As Object, e As EventArgs) Handles _
        Tbx_10_Target__income.TextChanged, Tbx_10_Target__pension.TextChanged, Tbx_10_Target__benefit.TextChanged,
        Tbx_10_Target__allowance.TextChanged, Tbx_10_Target__otherincome.TextChanged,
        Tbx_10_Target__rent.TextChanged, Tbx_10_Target__heating.TextChanged, Tbx_10_Target__heating.TextChanged,
        Tbx_10_Target__gaselectra.TextChanged, Tbx_10_Target__water.TextChanged, Tbx_10_Target__food.TextChanged,
        Tbx_10_Target__medicine.TextChanged
        Calculate_Target_Totals()
    End Sub

    Private Sub Tbx_Target__income_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__income.Leave
        Tbx_10_Target__income.Text = Tbx2Dec(Tbx_10_Target__income.Text)
    End Sub
    Private Sub Tbx_Target__pension_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__pension.Leave
        Tbx_10_Target__pension.Text = Tbx2Dec(Tbx_10_Target__pension.Text)
    End Sub
    Private Sub Tbx_Target__benefit_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__benefit.Leave
        Tbx_10_Target__benefit.Text = Tbx2Dec(Tbx_10_Target__benefit.Text)
    End Sub
    Private Sub Tbx_Target__allowance_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__allowance.Leave
        Tbx_10_Target__allowance.Text = Tbx2Dec(Tbx_10_Target__allowance.Text)
    End Sub
    Private Sub Tbx_Target__otherincome_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__otherincome.Leave
        Tbx_10_Target__otherincome.Text = Tbx2Dec(Tbx_10_Target__otherincome.Text)
    End Sub
    Private Sub Tbx_Target__rent_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__rent.Leave
        Tbx_10_Target__rent.Text = Tbx2Dec(Tbx_10_Target__rent.Text)
    End Sub
    Private Sub Tbx_Target__heating_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__heating.Leave
        Tbx_10_Target__heating.Text = Tbx2Dec(Tbx_10_Target__heating.Text)
    End Sub
    Private Sub Tbx_Target__gaselectra_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__gaselectra.Leave
        Tbx_10_Target__gaselectra.Text = Tbx2Dec(Tbx_10_Target__gaselectra.Text)
    End Sub
    Private Sub Tbx_Target__water_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__water.Leave
        Tbx_10_Target__water.Text = Tbx2Dec(Tbx_10_Target__water.Text)
    End Sub
    Private Sub Tbx_Target__food_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__food.Leave
        Tbx_10_Target__food.Text = Tbx2Dec(Tbx_10_Target__food.Text)
    End Sub
    Private Sub Tbx_Target__medicine_Leave(sender As Object, e As EventArgs) Handles Tbx_10_Target__medicine.Leave
        Tbx_10_Target__medicine.Text = Tbx2Dec(Tbx_10_Target__medicine.Text)
    End Sub
    Private Sub Tbx_Target__name_Leave(sender As Object, e As EventArgs) Handles Tbx_01_Target__name.Leave
        If Lbx_Basis.Items.Count <> 0 Then ind1 = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember)
    End Sub
    Private Sub Tbx_Target__name_add_Leave(sender As Object, e As EventArgs) Handles Tbx_01_Target__name_add.Leave
        If Lbx_Basis.Items.Count <> 0 Then ind1 = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember)
    End Sub

    Private Sub Tbx_CP__name_TextChanged(sender As Object, e As EventArgs) Handles Tbx_01_CP__name.TextChanged
        reload = True
        If Lbx_Basis.Items.Count = 0 Then Add_Mode = True
    End Sub

    Private Sub navigation_complete(ByVal sender As System.Object,
           ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs)

        Dim HTMlAuthorCode As String = sender.DocumentText
        My.Computer.FileSystem.WriteAllText("C:\temp\xe.html", HTMlAuthorCode, True)

        Dim strAuthorCode As String = sender.Document.Body.InnerText
        My.Computer.FileSystem.WriteAllText("c:\temp\xe.txt", strAuthorCode, True)
        sender.Dispose()
    End Sub


    Private Sub Rbtn_Income_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Account_Income.CheckedChanged
        If MenuSave.Enabled Then Tbx_00_Account__type.Text = Rbtn_Account_Income.Text
    End Sub

    Private Sub Rbtn_Account_Transit_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Account_Transit.CheckedChanged
        If MenuSave.Enabled Then Tbx_00_Account__type.Text = Rbtn_Account_Transit.Text
    End Sub

    Private Sub Rbtn_Account_Expense_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Account_Expense.CheckedChanged
        If MenuSave.Enabled Then Tbx_00_Account__type.Text = Rbtn_Account_Expense.Text
    End Sub

    Private Sub Tbx_Account__type_TextChanged(sender As Object, e As EventArgs) Handles Tbx_00_Account__type.TextChanged
        Rbtn_Account_Income.Checked = Tbx_00_Account__type.Text = "Generiek (fonds)"
        Rbtn_Account_Expense.Checked = Tbx_00_Account__type.Text = "Specifiek (doel)"
        Rbtn_Account_Transit.Checked = Tbx_00_Account__type.Text = "Anders"
    End Sub
    Private Sub Tbx_BankAcc__accountno_Leave(sender As Object, e As EventArgs) Handles Tbx_01_BankAcc__accountno.Leave
        If Tbx_01_BankAcc__accountno.Text = "" Then Exit Sub
        Tbx_01_BankAcc__accountno.Text = Tbx_01_BankAcc__accountno.Text.ToUpper
        If IBANcheck(Tbx_01_BankAcc__accountno.Text) <> 1 Then
            MsgBox("Bankrekeningnummer Is niet correct", vbCritical)
            Tbx_01_BankAcc__accountno.Focus()
        End If
    End Sub

    Private Sub Tbx_10_Relation__name_TextChanged(sender As Object, e As EventArgs) Handles Tbx_01_relation__name.TextChanged
        If Add_Mode Then Generate_Reference()
        If Lbx_Basis.Items.Count = 0 Then Add_Mode = True
    End Sub
    Private Sub Tbx_00_Relation__iban_Leave(sender As Object, e As EventArgs) Handles Tbx_00_Relation__iban.Leave
        If Tbx_00_Relation__iban.Text = "" Then Exit Sub
        Tbx_00_Relation__iban.Text = Tbx_00_Relation__iban.Text.ToUpper
        If IBANcheck(Tbx_00_Relation__iban.Text) <> 1 Then
            MsgBox("Bankrekeningnummer Is niet correct", vbCritical)
            Tbx_00_Relation__iban.Focus()
        End If
    End Sub
    Private Sub Rbn_00_contract_child_Click(sender As Object, e As EventArgs) Handles Rbn_00_contract_child.Click
        Tbx_Contract_ttype.Text = "Kind"
        Lbl_00_Contract__name.Text = Contract_number("K")
        Load_Combobox(Cmx_01_contract__fk_target_id, "id", "name", "Select id, Name||', '||name_add as name FROM target
                                                        WHERE ttype='" & Rbn_00_contract_child.Text & "' ORDER BY name")
        '-------standaard_waarden ophalen
        Dim settingdata = Collect_data2("select value from settings where label ilike 'standaard_%_kind' order by label")
        Tbx_11_Contract__donation.Text = settingdata.Rows(0)(0)
        Tbx_11_contract__overhead.Text = settingdata.Rows(1)(0)

        '----------------------------

    End Sub
    Private Sub Tbx_10_Contract__transport_TextChanged(sender As Object, e As EventArgs)
        'Calculate_contract_amounts()
    End Sub

    Private Sub Tbx_11_contract__overhead_TextChanged(sender As Object, e As EventArgs) Handles Tbx_11_contract__overhead.TextChanged, Tbx_11_Contract__donation.TextChanged
        Calculate_contract_amounts()
    End Sub

    Private Sub Pic_Target__photo_DoubleClick(sender As Object, e As EventArgs) Handles Pic_Target__photo.DoubleClick, Pic_cp__photo.DoubleClick
        Save_Image(Pic_Target__photo)
    End Sub

    Private Sub Tbx_11_Contract__donation_Leave(sender As Object, e As EventArgs) Handles Tbx_11_Contract__donation.Leave
        Tbx_11_Contract__donation.Text = Tbx2Dec(Tbx_11_Contract__donation.Text)
    End Sub
    Private Sub Tbx_11_contract__overhead_Leave(sender As Object, e As EventArgs) Handles Tbx_11_contract__overhead.Leave
        Tbx_11_contract__overhead.Text = Tbx2Dec(Tbx_11_contract__overhead.Text)
    End Sub

    Private Sub Cmx_01_contract_fk_target_id_Leave(sender As Object, e As EventArgs) Handles Cmx_01_contract__fk_target_id.Leave
        If (Cmx_01_contract__fk_target_id.SelectedIndex = -1) Then
            Cmx_01_contract__fk_target_id.Focus()
            Exit Sub
        End If
        Exit Sub
        Dim id = Cmx_01_contract__fk_target_id.SelectedValue
        Try
            Pic_Contract_Target_photo.Image = BlobToImage(QuerySQL("SELECT photo FROM target WHERE id='" & id & "'"))

        Catch ex As Exception
            Pic_Contract_Target_photo.Image = Nothing
        End Try
    End Sub

    Private Sub Cmx_01_contract_fk_target_id_SelectedValueChanged(sender As Object, e As EventArgs) Handles Cmx_01_contract__fk_target_id.SelectedValueChanged
        Dim id = Cmx_01_contract__fk_target_id.SelectedValue
        'Tbx_Contract_ttype.Text = QuerySQL("Select ttype FROM target WHERE id=" & id)
        Try
            Pic_Contract_Target_photo.Image = BlobToImage(QuerySQL("SELECT photo FROM target WHERE id='" & id & "'"))
        Catch ex As Exception
            Pic_Contract_Target_photo.Image = Nothing
        End Try
    End Sub

    Private Sub Cmx_01_contract_fk_relation_id_Leave(sender As Object, e As EventArgs) Handles Cmx_00_contract__fk_relation_id.Leave
        If (Cmx_00_contract__fk_relation_id.SelectedIndex = -1) Then
            Cmx_00_contract__fk_relation_id.Focus()
            Exit Sub
        End If

        Get_Sponsor_data()
    End Sub

    Private Sub Dtp_01_contract__enddate_Enter(sender As Object, e As EventArgs) Handles Dtp_31_contract__enddate.Enter
        oldend_date = Dtp_31_contract__enddate.Value
        Dim newEndDate As Date = Date.Today.AddMonths(1)

        If Not Add_Mode Then Dtp_31_contract__enddate.Value = New DateTime(newEndDate.Year, newEndDate.Month, 1).AddDays(-1) 'end of current month
    End Sub

    Private Sub Rbn_00_contract_elder_Click(sender As Object, e As EventArgs) Handles Rbn_00_contract_elder.Click
        Tbx_Contract_ttype.Text = "Oudere"
        Lbl_00_Contract__name.Text = Contract_number("O")
        Load_Combobox(Cmx_01_contract__fk_target_id, "id", "name",
                      $"SELECT id, name||', '||name_add as name FROM target WHERE ttype='{Rbn_00_contract_elder.Text}' ORDER BY name")
        Dim presetdata = Collect_data2("select value from settings where label ilike 'standaard_%_oudere' order by label")
        Tbx_11_Contract__donation.Text = presetdata.Rows(0)(0)
        Tbx_11_contract__overhead.Text = presetdata.Rows(1)(0)
    End Sub

    Private Sub Rbn_00_contract_other_Click(sender As Object, e As EventArgs) Handles Rbn_00_contract_other.Click
        Tbx_Contract_ttype.Text = "Overig"
        Load_Combobox(Cmx_01_contract__fk_target_id, "id", "name", "SELECT id, name||', '||name_add as name FROM target
                                                        WHERE ttype='" & Rbn_00_contract_other.Text & "' ORDER BY name")
        Lbl_00_Contract__name.Text = Contract_number("V")
        Tbx_11_Contract__donation.Text = 0
        Tbx_11_contract__overhead.Text = 0
    End Sub
    Sub Check_Contract_Status()
        'check that contract is not already ended or has a newer version
        Dim sd As Date = QuerySQL("SELECT MAX(startdate) FROM contract 
                                       WHERE name='" & Lbl_00_Contract__name.Text & "'")

        If Me.Dtp_31_contract__enddate.Value < Date.Today Or  '@@@eigenlijk: de eerste dag van de volgende maand
            Me.Dtp_31_contract__enddate.Value < sd Then
            MsgBox("Een contract dat beeindigd is of niet de laatste versie is kan niet gewijzigd worden.")
            Select_Obj2("Check_Contract_Status")
            Add_Mode = False
            Pan_Target.Enabled = False

            If TC_Object.SelectedIndex = 0 Then  'additional functionality for contract management
                Handle_Contract_Fields()
                Pan_Contract_Date_New.Visible = False
            End If
            Exit Sub
        End If
    End Sub
    Private Sub Tbx_01_contract_yeartotal_TextChanged(sender As Object, e As EventArgs) Handles Tbx_01_contract_yeartotal.TextChanged
        Try
            If Not Add_Mode And MenuSave.Enabled Then
                'If Edit_Mode And Not Add_Mode Then
                Dim name = Lbl_00_Contract__name.Text
                '0. Retrieve all versions of the contract 

                '1 determine whether there is a future version. If so then a change is not allowed (first
                'delete that version

                Dim next_date As Date = QuerySQL("select max(startdate) from contract where name ='" & name & "'")
                If next_date > Date.Today Then
                    MsgBox("Er is een nieuwere versie die nog niet is ingegaan (" & next_date & ")" & vbCrLf &
                           "S.v.p. deze eerst verwijderen. " & next_date)
                    Cancel()
                    Exit Sub

                End If

                'Set new start dates
                Dim mindate As DateTime
                'a new version must start 1 month later 
                mindate = Dtp_31_contract__startdate.Value
                Dtp_30_Contract_Change.MinDate = New DateTime(mindate.Year, mindate.Month, 1).AddMonths(1)

                'set default new startdate to first day of the next month
                Dim m_add, m_year As Integer
                If Me.Dtp_30_Contract_Change.Value.Month = 12 Then
                    m_add = -11
                    m_year = 1
                Else
                    m_add = IIf(Me.Dtp_30_Contract_Change.Value.Day > 1, 1, 0)
                    m_year = 0
                End If
                Me.Dtp_30_Contract_Change.Value = CDate("01-" & Me.Dtp_30_Contract_Change.Value.Month +
                    m_add & "-" & Me.Dtp_30_Contract_Change.Value.Year + m_year)

                Pan_Contract_Date_New.Visible = True

            End If
            If Add_Mode Then
                Pan_Contract_Date_New.Visible = False
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Chx_00_contract__autcol_Click(sender As Object, e As EventArgs) Handles Chx_00_contract__autcol.Click
        'check if the sponsor provided an authorization for automatic collection
        If Chx_00_contract__autcol.Checked = False Then
            Dim SQLstr As String = "UPDATE contract SET autcol=False WHERE id=" & Lbl_Contract_pkid.Text
            If Chbx_test.Checked Then MsgBox(SQLstr)
            RunSQL(SQLstr, "NULL", "")
            Exit Sub
        End If

        Dim dtp As String
        Dim ttype As String
        Dim rel_id = Cmx_00_contract__fk_relation_id.SelectedValue
        MsgBox(rel_id)

        If Rbn_00_contract_child.Checked Then
            dtp = "date1"
            ttype = "kindersponsoring"
        ElseIf Rbn_00_contract_elder.Checked Then
            dtp = "date2"
            ttype = "ouderensponsoring"
        Else
            dtp = "date3"
            ttype = "algemene sponsoring"
        End If

        Dim autcol_date As Date = QuerySQL("SELECT " & dtp & " FROM relation WHERE id=" & rel_id)

        If autcol_date > Date.Now Then
            MsgBox("De sponsor heeft nog geen geldige incassomachtiging voor " & ttype &
                   "; Automatische incasso kan (nog) niet geactiveerd worden voor dit contract.", vbCritical)
            Chx_00_contract__autcol.Checked = False

        Else
            RunSQL($"UPDATE contract SET autcol=True WHERE id={Lbl_Contract_pkid.Text}", "NULL", "")
        End If

    End Sub
    Private Sub Cbx_00_contract__autcol_CheckedChanged(sender As Object, e As EventArgs) Handles Chx_00_contract__autcol.CheckedChanged
        Dim rel_id = Cmx_00_contract__fk_relation_id.SelectedValue
        Dim dtp = IIf(Rbn_00_contract_child.Checked, "date1", IIf(Rbn_00_contract_elder.Checked, "date2", "date3"))
        Lbl_00_contract_autcol.Visible = Chx_00_contract__autcol.Checked
        Lbl_00_contract_autcol.Text = QuerySQL("SELECT reference FROM relation WHERE id=" & rel_id)
        dtp_contract_relation_date.Visible = Chx_00_contract__autcol.Checked
        Lbl_contract_mach_datum.Visible = Chx_00_contract__autcol.Checked
        dtp_contract_relation_date.Value = QuerySQL("SELECT " & dtp & " FROM relation WHERE id=" & rel_id)
        Lbl_contract_macht_kenm.Visible = Chx_00_contract__autcol.Checked
        '@@@ 
    End Sub

    Private Sub Cbx_00_relation__active_Click(sender As Object, e As EventArgs) Handles Cbx_00_relation__active.Click
        CheckActive(Cbx_00_relation__active, Lbl_relation_pkid, "contract")
    End Sub

    Private Sub Cbx_00_target__active_Click(sender As Object, e As EventArgs) Handles Cbx_00_target__active.Click
        CheckActive(Cbx_00_target__active, Lbl_Target_pkid, "contract")
    End Sub

    Private Sub Dtp_30_Contract_Change_ValueChanged(sender As Object, e As EventArgs) Handles Dtp_30_Contract_Change.ValueChanged
        Exit Sub
        If Dtp_30_Contract_Change.Visible Then
            Dim d As DateTime
            d = Me.Dtp_30_Contract_Change.Value
            'Determine enddate previous version
            Me.Dtp_31_contract__enddate.Value = New DateTime(d.Year, d.Month, 1).AddDays(-1)

            Add_Mode = True
        End If
    End Sub

    Sub Manage_Buttons_Target(ByVal _add As Boolean, _searchbox As Boolean, d As Boolean, _menusave As Boolean, _cancel As Boolean, sender As String)
        Exit Sub
        If Cbx_LifeCycle2.Text = "Inactief" And MenuSave.Enabled Then
            MsgBox("Inactieve objecten kunnen niet gewijzigd worden.")
            Exit Sub
        End If
        Lbx_Basis.Enabled = _add
        MenuAdd.Enabled = _add
        MenuDelete.Enabled = _add
        MenuFilter.Enabled = _searchbox

        MenuSave.Enabled = _menusave
        MenuCancel.Enabled = _cancel
    End Sub
    Private Sub Tbx_BankAcc__accountno_TextChanged(sender As Object, e As EventArgs) Handles _
          Tbx_01_BankAcc__accountno.TextChanged, Tbx_01_BankAcc__name.TextChanged, Tbx_01_Accgroup__name.TextChanged, Tbx_01_Target__name.TextChanged, Cmx_01_account__fk_accgroup_id.TextUpdate,
          Tbx_01_Target__name_add.TextChanged, Tbx_01_Account__name.TextChanged, Tbx_01_CP__name_add.TextChanged,
          Tbx_00_Accgroup__subtype.TextChanged, Tbx_00_Accgroup__description.TextChanged, Tbx_01_Accgroup__name.TextChanged, Tbx_01_Accgroup__type.TextChanged,
          Rbtn_accgroup_Income.CheckedChanged, Rbtn_accgroup_expense.CheckedChanged, Rbtn_accgroup_transit.CheckedChanged

        reload = True
    End Sub


    Private Sub Tbx_10_Account__b_jan_TextChanged(sender As Object, e As EventArgs) Handles _
        Tbx_10_Account__b_jan.TextChanged, Tbx_10_Account__b_feb.TextChanged, Tbx_10_Account__b_mar.TextChanged,
        Tbx_10_Account__b_apr.TextChanged, Tbx_10_Account__b_may.TextChanged, Tbx_10_Account__b_jun.TextChanged,
        Tbx_10_Account__b_jul.TextChanged, Tbx_10_Account__b_aug.TextChanged, Tbx_10_Account__b_sep.TextChanged,
        Tbx_10_Account__b_oct.TextChanged, Tbx_10_Account__b_nov.TextChanged, Tbx_10_Account__b_dec.TextChanged

        If MenuSave.Enabled Then
            Calculate_Manual_Budgets()
        End If
    End Sub
    '========================================================================================================
    '======                                                                                            ======
    '======                                         B A N K                                            ======
    '======                                                                                            ======
    '========================================================================================================

    '*******************     Comboboxen ***********************************

    Sub Cmx_Bank_bankacc_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmx_Bank_bankacc.SelectedIndexChanged
        'MsgBox("A:" & Cmx_Bank_bankacc.SelectedIndex)
        If Cmx_Bank_bankacc.SelectedIndex = -1 Then Cmx_Bank_bankacc.SelectedIndex = 0
        Fill_bank_transactions("Cmx_Bank_bankacc.SelectedIndexChanged", 0)

    End Sub

    Private Sub Cmx_Bank_Account_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmx_Bank_Account.SelectedIndexChanged
        Add_Journal_post_to_bank_transaction()
    End Sub

    Sub Dgv_Bank_Click(sender As Object, e As EventArgs) Handles Dgv_Bank.Click, Dgv_Bank.SelectionChanged
        isManualChange = False
        If Dgv_Bank.Rows.Count = 0 Or Dgv_Bank.DataSource Is Nothing Then Exit Sub

        Try
            'Voorkomen dat de gebruiker incassso- of excassojobs gaat editen
            If Not IsDBNull(Dgv_Bank.SelectedCells(3).Value) Then
                If Strings.Left(Dgv_Bank.SelectedCells(3).Value, 16) = "Contract incasso" _
                    Or Strings.Left(Dgv_Bank.SelectedCells(3).Value, 7) = "Excasso" Then
                    Dgv_Bank_Account.EditMode = DataGridViewEditMode.EditProgrammatically
                Else
                    Dgv_Bank_Account.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2
                End If
            End If


            'vullen van niet aanpasbare velden
            Tbx_Bank_Relation.Text = Dgv_Bank.SelectedCells(2).Value
            If Not IsDBNull(Dgv_Bank.SelectedCells(8).Value) Then Tbx_Bank_Relation_account.Text = Dgv_Bank.SelectedCells(8).Value
            If Not IsDBNull(Dgv_Bank.SelectedCells(6).Value) Then Tbx_Bank_Code.Text = Dgv_Bank.SelectedCells(6).Value
            If Not IsDBNull(Dgv_Bank.SelectedCells(9).Value) Then Tbx_Bank_Afschrift.Text = Dgv_Bank.SelectedCells(9).Value
            Tbx_Transactie_totaal.Text = QuerySQL($"Select sum(credit-debit) from bank where seqorder ='{Tbx_Bank_Afschrift.Text}'")

            'Vullen van aanpasbare velden
            Tbx_Bank_Description.Text = Dgv_Bank.SelectedCells(3).Value
            If Chbx_Bank_ExtraInfo_voor.Checked Then
                If Strings.InStr(Tbx_Bank_Description.Text, " | ") > 0 Then
                    Tbx_Bank_Extra_Info.Text = Strings.Left(Tbx_Bank_Description.Text, Strings.InStr(Tbx_Bank_Description.Text, " | ") - 1)
                Else
                    Tbx_Bank_Extra_Info.Text = ""
                End If
            End If

            'Vullen van de datagridviews dgv_bank_account waarin de journaalboekingen per banktransactie staan
            Fill_Journals_by_bank(Dgv_Bank.SelectedCells(0).Value)


            If Dgv_Bank.Rows(Dgv_Bank.SelectedCells(2).RowIndex).DefaultCellStyle.ForeColor = Color.DarkRed And Trim(Tbx_Bank_Code.Text) = "cb" Then

                Dim sqlstr = $"
                Select ac.name From account ac
                Left Join target t on t.id = ac.f_key And source='Doel'
                Left Join contract c on c.fk_target_id = t.id
                Left Join relation r on r.id = c.fk_relation_id
                Where R.iban = '{Tbx_Bank_Relation_account.Text}' 
                And R.active = True limit 1
                "
                Cmx_Bank_Account.Text = QuerySQL(sqlstr)
            Else
                Cmx_Bank_Account.Text = ""
            End If
            Tbx_Bank_Amount.Text = 0

            For x = 0 To Dgv_Bank_Account.Rows.Count - 1
                If Dgv_Bank_Account.Rows(x).Cells(1).Value = "[Niet toegewezen]" Then
                    Tbx_Bank_Amount.Text = Dgv_Bank_Account.Rows(x).Cells(2).Value
                    Exit For
                End If
            Next x
            If Dgv_Bank.Rows(Dgv_Bank.SelectedCells(2).RowIndex).Cells(12).Value = "Auto-cat" Then
                RunSQL($"Update Bank set fk_journal_name='Bank' where id='{Dgv_Bank.SelectedCells(0).Value}'", "NULL", "auto_cat")
                Dgv_Bank.Rows(Dgv_Bank.SelectedCells(2).RowIndex).DefaultCellStyle.ForeColor = Color.DarkGreen
                Dgv_Bank.Rows(Dgv_Bank.SelectedCells(2).RowIndex).Cells(12).Value = "Bank" '
            End If

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
        isManualChange = True
        Enable_Buttons(False, False)
        Dgv_Bank.Enabled = True

    End Sub

    Private Sub Btn_Bank_Add_Journal_Click(sender As Object, e As EventArgs) Handles Btn_Bank_Add_Journal.Click ', Cmx_Bank_Account.SelectedValueChanged
        Add_Journal_post_to_bank_transaction()
    End Sub



    Private Function CalculateColumnSum(dgv As DataGridView, columnIndex As Integer) As Double
        Dim sum As Double = 0

        For Each row As DataGridViewRow In dgv.Rows
            ' Skip the new row (for adding new entries)
            If Not row.IsNewRow Then
                ' Check for null or empty values to avoid errors
                Dim cellValue = row.Cells(columnIndex).Value
                Dim accountnr = row.Cells(0).Value
                If cellValue IsNot Nothing AndAlso IsNumeric(cellValue) Then

                    sum += Convert.ToDouble(cellValue)

                End If
            End If
        Next
        Return sum

    End Function


    Private Sub Dgv_Test_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles _
        Dgv_Bank_Account.CellValueChanged

        isManualChange = True
        If Dgv_Bank_Account.Rows.Count = 0 Then  'dit kan alleen voorkomen als er een error is opgetreden. 
            MsgBox("Er is een fout opgetreden, u kunt wel doorgaan")
            Exit Sub
        End If

        Try
            If IsDBNull(Dgv_Bank_Account.CurrentCell.Value) Then
                MsgBox("Ongeldige invoer")
                Exit Sub
            End If
        Catch
            Exit Sub
        End Try

        If Not IsNumeric(Dgv_Bank_Account.CurrentCell.Value) Then
            MsgBox("Ongeldige invoer")
            Exit Sub
        End If

        If Check_Change_Bank_Categories(True) = False Then Exit Sub

        Calculate_Total_Booked("Dgv_Test_CellValueChanged")

        Dgv_Bank_Account.Rows(e.RowIndex).Tag = "Modified"
    End Sub



    Private Sub Tbx_Bank_Search_TextChanged(sender As Object, e As EventArgs) Handles Tbx_Bank_Search.TextChanged
        Fill_bank_transactions("Tbx_Bank_Search.TextChanged", 0)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        RunSQL("TRUNCATE TABLE bank", "NULL", "")
        RunSQL("Delete From journal WHERE source='Bank'", "NULL", "")
    End Sub

    Private Sub Rbn_Relation_1_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Relation_1.Click
        If Rbn_Relation_1.Checked Then Tbx_01_Relation__title.Text = Rbn_Relation_1.Text
    End Sub

    Private Sub Rbn_Relation_2_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Relation_2.Click
        If Rbn_Relation_2.Checked Then Tbx_01_Relation__title.Text = Rbn_Relation_2.Text
    End Sub

    Private Sub Rbn_Relation_3_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Relation_3.Click
        If Rbn_Relation_3.Checked Then Tbx_01_Relation__title.Text = Rbn_Relation_3.Text
    End Sub

    Private Sub Rbn_Relation_4_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Relation_4.Click
        If Rbn_Relation_4.Checked Then Tbx_01_Relation__title.Text = Rbn_Relation_4.Text
    End Sub
    Private Sub Rbn_Relation_5_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Relation_5.Click
        If Rbn_Relation_5.Checked Then Tbx_01_Relation__title.Text = Rbn_Relation_5.Text
    End Sub
    Private Sub Rbn_Relation_6_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Relation_6.Click
        If Rbn_Relation_6.Checked Then Tbx_01_Relation__title.Text = Rbn_Relation_6.Text
    End Sub

    Private Sub Tbx_01_Relation__title_TextChanged(sender As Object, e As EventArgs) Handles Tbx_01_Relation__title.TextChanged
        Rbn_Relation_1.Checked = Strings.Trim(Tbx_01_Relation__title.Text) = Rbn_Relation_1.Text
        Rbn_Relation_2.Checked = Strings.Trim(Tbx_01_Relation__title.Text) = Rbn_Relation_2.Text
        Rbn_Relation_3.Checked = Strings.Trim(Tbx_01_Relation__title.Text) = Rbn_Relation_3.Text
        Rbn_Relation_4.Checked = Strings.Trim(Tbx_01_Relation__title.Text) = ""
        Rbn_Relation_5.Checked = Strings.Trim(Tbx_01_Relation__title.Text) = Rbn_Relation_5.Text
        Rbn_Relation_6.Checked = Strings.Trim(Tbx_01_Relation__title.Text) = Rbn_Relation_6.Text

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles Tbx_Contract_ttype.TextChanged

        Dim rel_id = Cmx_00_contract__fk_relation_id.SelectedValue
        Dim dtp = IIf(Tbx_Contract_ttype.Text = "Kind", "date1",
                     IIf(Tbx_Contract_ttype.Text = "Oudere", "date2", "date3"))

        If Rbn_00_contract_child.Checked Then
            dtp = "date1"
        ElseIf Rbn_00_contract_elder.Checked Then
            dtp = "date2"
        Else
            dtp = "date3"
        End If

        dtp_contract_relation_date.Value = QuerySQL("SELECT " & dtp & " FROM relation WHERE id=" & rel_id)

    End Sub

    Private Sub Dtp_Incasso_start_ValueChanged(sender As Object, e As EventArgs) Handles Dtp_Incasso_start.ValueChanged
        If TC_Main.SelectedIndex <> 2 Then Exit Sub
        Create_Incassolist()
        If Rbn_Incasso_SEPA.Checked Then
            Format_Datagridview2(Dgv_Incasso, Nothing, {"TZ205", "NG080", "TZ160", "TZ080", "TZ090", "DZ090"})
        Else
            Format_Datagridview2(Dgv_Incasso, Nothing, {"TZ210", "TZ210", "TZ070", "TZ070", "NG080", "NG080", "HZ080", "HZ080"})
        End If

        Rbn_Incasso_SEPA.Checked = True
    End Sub

    Private Sub Rbn_Incasso_SEPA_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Incasso_SEPA.CheckedChanged _
        , Rbn_Incasso_journal.Click, Rbn_Incasso_Verschillen.Click

        If TC_Main.SelectedIndex <> 2 Then Exit Sub
        If Rbn_Incasso_SEPA.Checked Then
            'Load_Datagridview(Me.Dgv_Incasso, Create_Incasso(Dtp_Incasso_start.Value), "Dtp_Incasso_start.ValueChanged")
            Format_Datagridview2(Dgv_Incasso, Create_Incasso(Dtp_Incasso_start.Value), {"TZ205", "NG080", "TZ160", "TZ080", "TZ090", "DZ090"})
        ElseIf Rbn_Incasso_journal.Checked Then
            'Load_Datagridview(Me.Dgv_Incasso, Create_Incasso_Bookings(Dtp_Incasso_start.Value), "Dtp_Incasso_start.ValueChanged")
            Format_Datagridview2(Dgv_Incasso, Create_Incasso_Bookings(Dtp_Incasso_start.Value), {"TZ210", "TZ210", "TZ070", "TZ070", "NG080", "NG080", "HZ080", "HZ080"})
        Else
            Dim arr_format() As String = Nothing
            Dim sql = QuerySQL($"select sql from query where name='Check_incasso'")
            If IsNothing(sql) Then Exit Sub
            Dim formatting = QuerySQL($"select sql from query where name='Check_incasso'")
            If Not IsNothing(formatting) Then arr_format = formatting.Split(",")
            sql = sql.replace("[date]", $"'{Year(Me.Dtp_Incasso_start.Value)}-{Month(Me.Dtp_Incasso_start.Value)}-01'")
            'Load_Datagridview(Me.Dgv_Incasso, sql, "Dtp_Incasso_verschillen.ValueChanged")
            Format_Datagridview2(Dgv_Incasso, sql, {"TZ350", "TZ200", "NZ080", "NZ080"})

        End If
    End Sub

    Private Sub Cbx_Uitkering_Kind_Click(sender As Object, e As EventArgs) Handles Cbx_Uitkering_Kind.Click,
            Cbx_Uitkering_Oudere.Click, Cbx_Uitkering_Overig.Click

        If Not Cbx_Uitkering_Oudere.Checked And Not Cbx_Uitkering_Kind.Checked And Not Cbx_Uitkering_Overig.Checked Then
            Empty_Excasso_Window()
        Else
            Call_Excasso_form(sender)
            Calculate_CP_Allowance()
        End If

    End Sub

    Private Sub Dtp_Excasso_Start_ValueChanged(sender As Object, e As EventArgs) Handles Dtp_Excasso_Start.ValueChanged
        Dtp_Excasso_Start.MaxDate = Date.Today
    End Sub

    Private Sub Dgv_Excasso2_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_Excasso2.CellEndEdit

        'checks of ingevoerde waarden ook beschikbaar zijn
        Dim i As Integer = Me.Dgv_Excasso2.CurrentCell.RowIndex  'Me.Dgv_Excasso2.CurrentRow.Index
        Dim j As Decimal = Me.Dgv_Excasso2.CurrentCell.ColumnIndex
        'Dim fin As VariantType
        Dim ruimte_contract As Integer = Math.Max(Me.Dgv_Excasso2.Rows(i).Cells(2).Value, Me.Dgv_Excasso2.Rows(i).Cells(3).Value)
        Dim bedrag As Integer = Me.Dgv_Excasso2.CurrentCell.Value

        Dim int As Integer
        'If Not Integer.TryParse(bedrag, int) Then GoTo fin
        On Error GoTo fin
        Select Case j
            Case 6
                If Me.Dgv_Excasso2.Rows(i).Cells(6).Value > ruimte_contract Then
                    MsgBox("Uitkering is maximaal het beschikbare contractbedrag")
                    Me.Dgv_Excasso2.Rows(i).Cells(6).Value = ruimte_contract
                End If

            Case 7
                If Me.Dgv_Excasso2.Rows(i).Cells(7).Value > Me.Dgv_Excasso2.Rows(i).Cells(4).Value Then
                    MsgBox("Extra gift is hoger dan binnengekomen extra gift")
                    Me.Dgv_Excasso2.Rows(i).Cells(7).Value = Me.Dgv_Excasso2.Rows(i).Cells(4).Value
                End If
            Case 8
                If Me.Dgv_Excasso2.Rows(i).Cells(8).Value > Me.Dgv_Excasso2.Rows(i).Cells(5).Value Then
                    MsgBox("Interne gift is hoger dan interne boeking")
                    Me.Dgv_Excasso2.Rows(i).Cells(8).Value = Me.Dgv_Excasso2.Rows(i).Cells(5).Value
                End If
        End Select
        Calculate_Excasso_Totals2()

        Exit Sub
fin:
        MsgBox("Het formulier accepteert alleen uitkeringen in hele euro's")
    End Sub
    Private Sub Dgv_Excasso2_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) _
    Handles Dgv_Excasso2.DataError, Dgv_Bank_Account.DataError, Dgv_Bank_Account.DataError

        MsgBox("Ongeldige invoer")
        e.ThrowException = False

    End Sub

    Private Sub Tbx_Excasso_CP2_TextChanged(sender As Object, e As EventArgs) Handles Tbx_Excasso_CP2.TextChanged,
        Tbx_Excasso_CP3.TextChanged, Tbx_Excasso_CP1.TextChanged

        Try
            Me.Lbl_Excasso_CP_Totaal.Text = Tbx2Int(GetDouble(Me.Tbx_Excasso_CP1.Text) _
            + GetDouble(Me.Tbx_Excasso_CP2.Text) + GetDouble(Me.Tbx_Excasso_CP3.Text))
            Me.Lbl_Excasso_CP_Totaal_MDL.Text = (Tbx2Int(GetDouble(Me.Tbx_Excasso_CP1.Text) _
            + GetDouble(Me.Tbx_Excasso_CP2.Text) + GetDouble(Me.Tbx_Excasso_CP3.Text)) * Tbx2Dec(Tbx_Excasso_Exchange_rate.Text))
            Me.Lbl_Excasso_Tot_Gen.Text = CInt(Me.Lbl_Excasso_CP_Totaal.Text) + CInt(Lbl_Excasso_Totaal.Text)
            Lbl_Excasso_Tot_Gen_MLD.Text = Math.Round(CInt(Me.Lbl_Excasso_Tot_Gen.Text) * Tbx2Dec(Tbx_Excasso_Exchange_rate.Text), 2)
        Catch
            MsgBox("Geen geldige invoer.")
        End Try
    End Sub

    Private Sub GroupBox5_Leave(sender As Object, e As EventArgs)
        If IsNumeric(Tbx_Excasso_Exchange_rate.Text) Then

        Else
            MsgBox("Ongeldige inhoud")
        End If
    End Sub
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Exchrate.Click

        Btn_Excasso_Exchrate.Enabled = False
        Calculate_Excasso_Totals2()
    End Sub
    Private Sub Btn_Excasso_Print_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Print.Click
        If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
        Print_Excasso_form()
    End Sub

    Private Sub Btn_Excasso_Delete_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Delete.Click
        MenuExcassoDelete()
    End Sub
    Sub MenuExcassoDelete()
        If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
        If MsgBox("Wilt u de uitkeringslijst verwijderen?", vbYesNo) = vbYes Then
            RunSQL("DELETE FROM journal WHERE name ilike '%" & Me.Cmx_Excasso_Select.SelectedItem & "'", "NULL", "Delete_Excasso_Job")
            Fill_Cmx_Excasso_Select_Combined()
            Empty_Excasso_Window()
        End If

    End Sub

    Private Sub Btn_Excasso_CP_Calculate_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_CP_Calculate.Click
        Calculate_CP_Allowance()
    End Sub

    Private Sub Btn_Excasso_Save_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Save.Click
        If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
        Save_Excasso_job()
    End Sub
    Private Sub Tbx_Excasso_Norm1_Enter(sender As Object, e As EventArgs) Handles _
        Tbx_Excasso_Norm1.Enter, Tbx_Excasso_Norm2.Enter, Tbx_Excasso_Norm3.Enter
        Btn_Excasso_CP_Calculate.Enabled = True
    End Sub
    Private Sub Tbx_Excasso_Exchange_rate_Enter(sender As Object, e As EventArgs) Handles Tbx_Excasso_Exchange_rate.Enter
        Btn_Excasso_Exchrate.Enabled = True
    End Sub

    Private Sub Tbx_10_Account__b_jan_Leave(sender As Object, e As EventArgs) Handles _
            Tbx_10_Account__b_jan.Leave, Tbx_10_Account__b_feb.Leave, Tbx_10_Account__b_mar.Leave,
            Tbx_10_Account__b_apr.Leave, Tbx_10_Account__b_may.Leave, Tbx_10_Account__b_jun.Leave,
            Tbx_10_Account__b_jul.Leave, Tbx_10_Account__b_aug.Leave, Tbx_10_Account__b_sep.Leave,
            Tbx_10_Account__b_oct.Leave, Tbx_10_Account__b_nov.Leave, Tbx_10_Account__b_dec.Leave
        Calculate_Manual_Budgets()
    End Sub

    Private Sub Tbx_Journal_Source_Amt_TextChanged(sender As Object, e As EventArgs) Handles Tbx_Journal_Source_Amt.TextChanged
        Dim s As Decimal = Tbx2Dec(Me.Tbx_Journal_Source_Amt.Text)
        Dim m As Decimal = Tbx2Dec(Me.Lbl_Journal_Source_Saldo.Text)
        If (s <= 0 Or s > m) And (Tbx2Dec(Lbl_Journal_Source_Saldo.Text) <> 0) Then
            MsgBox("Bedrag (" & s & ") moet groter zijn dan nul en kleiner dan het saldo van de bronaccount (" & m & ")")
            Tbx_Journal_Source_Amt.Text = Tbx2Dec(m)
            Lbl_Journal_Source_Restamt.Text = Tbx_Journal_Source_Amt.Text
        End If
    End Sub

    Private Sub Tbx_Journal_Source_Amt_Leave(sender As Object, e As EventArgs) Handles Tbx_Journal_Source_Amt.Leave
        Calculate_Journal_Booking_Data()
    End Sub

    Private Sub Dgv_Journal_Intern_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_Journal_Intern.CellEndEdit
        Dim i As Integer = Me.Dgv_Journal_Intern.CurrentRow.Index
        Dim s As Decimal = Me.Dgv_Journal_Intern.Rows(i).Cells(2).Value

        If s < 0 Then
            MsgBox("Doelbedrag mag niet negatief zijn.")
            Me.Dgv_Journal_Intern.Rows(i).Cells(2).Value = 0
        End If
        Calculate_Journal_Booking_Data()
    End Sub

    Sub Btn_Journals_Cancel_Click(sender As Object, e As EventArgs) Handles Btn_Journals_Cancel.Click
        Lbl_Journal_Source_Saldo.Text = 0
        Lbl_Journal_Source_Name.Text = ""
        Tbx_Journal_Source_Amt.Text = 0
        Dgv_Journal_Intern.Rows.Clear()
        Lbl_Journal_Source_Restamt.Text = 0

    End Sub

    Private Sub Btn_Journal_Recalculate_Click(sender As Object, e As EventArgs) Handles Btn_Journal_Recalculate.Click
        Divide_among_targets()
    End Sub
    Private Sub Btn_Journal_Intern_Save_Click(sender As Object, e As EventArgs) Handles Btn_Journal_Intern_Save.Click
        Save_Internal_Booking()
    End Sub

    Sub Btn_Account_Budget_Id_Click(sender As Object, e As EventArgs) Handles Btn_Account_Budget_Id.Click
        Calculate_Budget(Lbl_00_pkid.Text)
        Select_Obj2("Btn_Account_Budget_Id_Click")
    End Sub

    Private Sub Btn_Account_Budget_All_Click(sender As Object, e As EventArgs) Handles Btn_Account_Budget_All.Click
        Calculate_Budget("")
        Select_Obj2("Btn_Account_Budget_All_Click")
    End Sub

    Private Sub Cmx_Excasso_Select_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmx_Excasso_Select.SelectedIndexChanged
        Load_Excasso_Form()
        Call_Excasso_form(sender)

    End Sub

    Sub Load_Excasso_Form()
        If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
        'check of de budgetbedragen nog geldig zijn
        If QuerySQL("select extract (year from min(date)) from journal") < Now.Year Then Calculate_Budget("")



        Gbx_Excasso_Calculate.Enabled = True
        If Strings.Left(Cmx_Excasso_Select.SelectedItem, 5) = "Nieuw" Then

            '=================nieuwe incasso ===============================================
            'determine CP id
            Btn_Excasso_Delete.Enabled = False
            Btn_Excasso_Print.Enabled = False
            Dim pos1 As Integer = Strings.InStr(Me.Cmx_Excasso_Select.SelectedItem, "[")

            Me.Lbl_Excasso_CPid.Text = Strings.Mid(Me.Cmx_Excasso_Select.SelectedItem, pos1 + 1,
                                       Len(Me.Cmx_Excasso_Select.SelectedItem) - pos1 - 1)

            Dtp_Excasso_Start.MaxDate = Date.Today
            Dtp_Excasso_Start.Value = Date.Today
            Dtp_Excasso_Start.Enabled = False
            Tbx_Excasso_Exchange_rate.Text = Tbx2Dec(My.Settings._exrate)
            Cbx_Uitkering_Kind.Enabled = True
            Cbx_Uitkering_Oudere.Enabled = True
            Cbx_Uitkering_Overig.Enabled = True
            Cbx_Uitkering_Kind.Checked = False
            Cbx_Uitkering_Oudere.Checked = False
            Cbx_Uitkering_Overig.Checked = False
            Dtp_Excasso_Start.Enabled = True
            Tbx_Excasso_CP1.Text = ""
            Tbx_Excasso_CP2.Text = ""
            Tbx_Excasso_CP3.Text = ""
            Load_Excasso_Balances()
            Lbl_Excasso_CP_Totaal.Text = 0
            Lbl_Excasso_CP_Totaal_MDL.Text = 0
            Calculate_CP_Allowance()


        Else  '=============================existing excasso===============================
            Btn_Excasso_Delete.Enabled = True
            Btn_Excasso_Print.Enabled = True
            Dtp_Excasso_Start.Enabled = False
            'determine CP id

            Dim str1() As String = Split(QuerySQL($"SELECT cpinfo FROM journal WHERE name ='{Cmx_Excasso_Select.SelectedItem}'"), "-")
            'cpinfo: cpid-Tbx_Excasso_Norm1- ..2-..3-Tbx_Excasso_CP1-..2-..3
            Lbl_Excasso_CPid.Text = str1(0)
            Tbx_Excasso_Norm1.Text = str1(1)
            Tbx_Excasso_Norm2.Text = str1(2)
            Tbx_Excasso_Norm3.Text = str1(3)
            Tbx_Excasso_CP1.Text = str1(4)
            Tbx_Excasso_CP2.Text = str1(5)
            Tbx_Excasso_CP3.Text = str1(6)

            Btn_Excasso_Base1.Text = IIf(str1(7) = "1", "€", "%")
            Btn_Excasso_Base2.Text = IIf(str1(8) = "1", "€", "%")
            Btn_Excasso_Base3.Text = IIf(str1(9) = "1", "€", "%")


            'calculate actual exchange rate
            Dim exr = QuerySQL($"SELECT sum(amt2)/sum(amt1) FROM journal WHERE name ='{Cmx_Excasso_Select.SelectedItem}'")
            If IsDBNull(exr) Then exr = 0
            Tbx_Excasso_Exchange_rate.Text = Math.Round(GetDouble(exr), 2)
            ' determine date
            Dtp_Excasso_Start.Value = CDate(QuerySQL($"SELECT date FROM journal WHERE name='{Cmx_Excasso_Select.SelectedItem}'"))
            Dtp_Excasso_Start.Enabled = False
            'determine target type
            Cbx_Uitkering_Kind.Enabled = False
            Cbx_Uitkering_Oudere.Enabled = False
            Cbx_Uitkering_Overig.Enabled = False

            Dim str2() As String = Split(Cmx_Excasso_Select.SelectedItem, "-")
            Cbx_Uitkering_Kind.Checked = InStr(str2(1), "K") > 0
            Cbx_Uitkering_Oudere.Checked = InStr(str2(1), "O") > 0
            Cbx_Uitkering_Overig.Checked = InStr(str2(1), "V") > 0

            Dim cp_amount = QuerySQL($"Select sum(amt1) FROM journal WHERE name ='{Cmx_Excasso_Select.SelectedItem}' AND type='CP' AND amt1<='0.00'")

            If IsNumeric(cp_amount) Then
                Lbl_Excasso_CP_Totaal.Text = CInt(cp_amount * -1)
                Lbl_Excasso_CP_Totaal_MDL.Text = Tbx2Int(CInt(Lbl_Excasso_CP_Totaal.Text) * Tbx2Dec(Tbx_Excasso_Exchange_rate.Text))
            Else
                Lbl_Excasso_CP_Totaal.Text = 0
                Lbl_Excasso_CP_Totaal_MDL.Text = 0
            End If

        End If
    End Sub


    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Base1.Click
        If Btn_Excasso_Base1.Text = "%" Then Btn_Excasso_Base1.Text = "€" Else Btn_Excasso_Base1.Text = "%"
        Calculate_CP_Allowance()
    End Sub

    Private Sub Btn_Excasso_Base2_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Base2.Click
        If Btn_Excasso_Base2.Text = "%" Then Btn_Excasso_Base2.Text = "€" Else Btn_Excasso_Base2.Text = "%"
        Calculate_CP_Allowance()
    End Sub

    Private Sub Btn_Excasso_Base3_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Base3.Click
        If Btn_Excasso_Base3.Text = "%" Then Btn_Excasso_Base3.Text = "€" Else Btn_Excasso_Base3.Text = "%"
        Calculate_CP_Allowance()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Process.Start("https://www.xe.com/currencyconverter/convert/?Amount=1&From=EUR&To=MDL")

    End Sub

    Private Sub Tbx_Excasso_Exchange_rate_Leave(sender As Object, e As EventArgs) Handles Tbx_Excasso_Exchange_rate.Leave
        My.Settings._exrate = Tbx2Dec(Tbx_Excasso_Exchange_rate.Text)
    End Sub

    Private Sub Btn_Excasso_Copy_to_clipboard_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Copy_to_clipboard.Click

        If Strings.Left(Cmx_Excasso_Select.SelectedItem, 6) = "Nieuwe" Then
            MsgBox("Bewaar deze uitkeringslijst eerst s.v.p.")
        Else
            If IsDBNull(Cmx_Excasso_Select.SelectedItem) Or Cmx_Excasso_Select.SelectedItem = "" Then Exit Sub
            Clipboard.Clear()
            Clipboard.SetText(Cmx_Excasso_Select.SelectedItem)

        End If

    End Sub


    Private Sub Cmx_00_contract__fk_relation_id_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmx_00_contract__fk_relation_id.SelectedIndexChanged
        If Not Add_Mode Then Exit Sub
        Dim int = QuerySQL("
                                        SELECT ba.id
                                        FROM relation r
                                        LEFT join bankacc ba ON ba.accountno = r.iban 
                                        WHERE r.id ='" & Cmx_00_contract__fk_relation_id.SelectedValue & "'
                                        ")

        Me.Lbl_Contract_Bronaccount.Visible = Not IsDBNull(int)
        Me.Cmx_00_Contract__fk_account_id.Visible = Not IsDBNull(int)
        Chx_00_contract__autcol.Enabled = IsDBNull(int)
        Lbl_Rel_id.Text = Cmx_00_contract__fk_relation_id.SelectedValue
    End Sub


    Private Sub Cbx_00_cp__active_Click(sender As Object, e As EventArgs) Handles Cbx_00_cp__active.Click
        CheckActive(Cbx_00_cp__active, Lbl_CP_pkid, "target")
    End Sub

    Sub Format_dvg_bank()


        Dim seq As String = ""

        For x As Integer = 0 To Dgv_Bank.Rows.Count - 1
            Dim cnt As Integer = Dgv_Bank.Rows(x).Cells(17).Value
            Dim col As Color

            Dgv_Bank.Rows(x).DefaultCellStyle.ForeColor = IIf(cnt > 0, Color.DarkRed, Color.DarkGreen)
            If Dgv_Bank.Rows(x).Cells(12).Value = "Auto-cat" Then Dgv_Bank.Rows(x).DefaultCellStyle.ForeColor = Color.DarkGoldenrod

            If x > 0 Then

                seq = Dgv_Bank.Rows(x).Cells(9).Value
                col = Color.White

                If seq = Dgv_Bank.Rows(x - 1).Cells(9).Value Then
                    Dgv_Bank.Rows(x).DefaultCellStyle.BackColor = Dgv_Bank.Rows(x - 1).DefaultCellStyle.BackColor
                Else
                    col = IIf(Dgv_Bank.Rows(x - 1).DefaultCellStyle.BackColor = Color.LightSteelBlue, Color.White, Color.LightSteelBlue)
                    Dgv_Bank.Rows(x).DefaultCellStyle.BackColor = col
                End If
            End If
        Next



        Try
            With Me.Dgv_Bank_Account

                '.Columns(0).HeaderText = "Id"
                .Columns(1).HeaderText = "Account"
                .Columns(2).HeaderText = "Bedrag"

                .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(2).DefaultCellStyle.Format = "N2"
                .Columns(2).DefaultCellStyle.ForeColor = Color.Blue

                .Columns(0).Visible = False
                .Columns(1).Width = 200
                .Columns(2).Width = 95
                .Columns(3).Visible = False

                .Columns(0).ReadOnly = True
                .Columns(1).ReadOnly = True
                .Columns(2).ReadOnly = False

            End With

        Catch
        End Try

    End Sub

    Sub Fill_bank_transactions(sender, rowindex)

        isManualChange = False
        If Cmx_Bank_bankacc.SelectedIndex = -1 Then Cmx_Bank_bankacc.SelectedIndex = 0
        Calculate_Bank_Balance()
        If Strings.InStr(Me.Cmx_Bank_bankacc.Text, "NL") = 0 Then Exit Sub

        Dim bankacc = Strings.Right(Me.Cmx_Bank_bankacc.Text, 18)

        'Dim sv As String = Me.Searchbox.Text '  Me.Tbx_Bank_Search.Text

        Dim SQLstr = $"SELECT id, date As Datum, name As Naam, description As Omschrijving, 
                      credit As bij, debit as Af, code As cod, exch_rate, iban2, seqorder As Afschrift,
                      batchid, amt_cur, fk_journal_name As Journaallabel,filename,cost,iban, id,
                      (select count(j.id) from journal j left join bank b2 on b2.id=j.fk_bank where j.fk_account='" & nocat & "' and b.id = b2.id)
                      FROM bank b WHERE iban ='" & bankacc & "' ORDER BY seqorder DESC, date DESC"


        'Load_Datagridview(Me.Dgv_Bank, SQLstr, "fill bank transactions")

        Format_Datagridview2(Dgv_Bank, SQLstr, {"HZ010", "FZ075", "TZ150", "TZ300", "NZ070", "NZ070", "TZ030", "HZ010", "HZ010", "TZ040", "HZ010", "HZ010", "TZ100", "HZ010", "HZ010", "HZ010", "TZ040", "HZ010"})
        Format_dvg_bank()
        With Me.Dgv_Bank
            '.Columns(1).HeaderText = "Datum"
            '.Columns(2).HeaderText = "Naam"
            '.Columns(3).HeaderText = "Omschrijving"
            '.Columns(4).HeaderText = "Bij"
            '.Columns(5).HeaderText = "Af"
            '.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            '.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            '.Columns(1).Width = 75
            '.Columns(2).Width = 150
            '.Columns(3).Width = 300
            '.Columns(4).Width = 70
            '.Columns(5).Width = 70
            '.Columns(0).Visible = False

        End With




        If rowindex = Nothing Then rowindex = 0
        If Me.Dgv_Bank.RowCount > 0 Then Me.Dgv_Bank.Rows(rowindex).Selected = True
        Dgv_Bank.Enabled = True
        isManualChange = True

    End Sub

    Private Sub NieuwToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Login.Text = "Inloggen in productieomgeving"
        Login.Cmx_Login_Database.Text = "Productie"
        Login.Show()

    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Login.Text = "Inloggen in testomgeving"
        Login.Cmx_Login_Database.Text = "Acceptatie"
        Login.Show()
    End Sub

    Sub Basis_Delete()
        Dim id As Integer
        Dim sqlstr As String = ""
        Dim t As Integer = TC_Object.SelectedIndex
        If Lbx_Basis.SelectedIndex <> -1 Then id = Lbx_Basis.SelectedItem(Me.Lbx_Basis.ValueMember) Else Exit Sub

        Select Case t
            Case 0
                If Me.Dtp_31_contract__startdate.Value <= Date.Today Then
                    MsgBox("Alleen contracten die nog niet zijn ingegaan kunnen verwijderd worden.")
                    Exit Sub
                Else
                    If MsgBox("Weet u zeker dat u dit contract wilt verwijderen (vergeet niet eventueel de einddatum van eerdere versie van dit contract terug te zetten)?", vbYesNo) = vbNo Then
                        Exit Sub
                    Else

                        QuerySQL("Update account set b_jan=0, b_feb=0, b_mar=0, b_apr=0, b_may=0, b_jun=0, b_jul=0, b_aug=0, b_sep=0, b_oct=0, b_nov=0, b_dec=0 
                        where source ilike 'Doel' and f_key=" & Cmx_01_contract__fk_target_id.SelectedValue)

                        sqlstr = "DELETE FROM contract WHERE id=" & id

                    End If
                End If

            Case 1
                Dim targetdata = Collect_data2("SELECT t.id, t.name, t.active, ac.name, ac.id, j.id As journal, c.id As Contract
                                From target t
                                LEFT join account ac on t.id= ac.f_key
                                LEFT join journal j on j.fk_account = ac.id
                                LEFT join contract c on c.fk_target_id = t.id
                                WHERE (j.id is null or c.id is null)
                                AND t.id =" & id)
                If targetdata.Rows.Count = 0 Then
                    MsgBox("Dit doel maakt nog onderdeel uit van een contract waarop transacties hebben plaatsgevonden." & vbCrLf &
                           "U kunt het niet verwijderen, maar wel inactief maken zodat er geen contract meer voor kan worden afgesloten of giften aan gegeven.")
                    Exit Sub
                End If
                Dim account_id = targetdata.Rows(0)(4)
                Dim journal_id = targetdata.Rows(0)(5)
                Dim contract_id = targetdata.Rows(0)(6)

                Dim Msg As String = "Dit doel: "
                If Not IsDBNull(contract_id) Then Msg &= vbCrLf & "- maakt onderdeel uit van contract " & contract_id
                If Not IsDBNull(journal_id) Then Msg &= vbCrLf & "- komt voor in journaalposten"
                If Len(Msg) > 10 Then
                    Msg &= vbCrLf & "en kan daarom niet verwijderd worden. U kunt het wel als [inactief] markeren."
                    MsgBox(Msg)
                Else
                    If MsgBox("Weet u zeker dat u het doel " & Tbx_01_Target__name.Text & "," & Tbx_01_Target__name_add.Text &
                        " wilt verwijderen?") Then
                        sqlstr = "Delete from target where id=" & id
                        'verwijderd totdat er ook in journal_archive een check plaatsvindt'  [;  'DELETE from account WHERE id=" & account_id]
                    End If

                End If

            Case 2
                If QuerySQL("select count(id) from contract where fk_relation_id = " & id) > 0 Then
                    MsgBox("Deze relatie staat geregistreerd bij contracten; deze moeten eerst verwijderd worden")
                Else
                    If MsgBox("Weet u zeker dat u deze relatie wilt verwijderen?", vbYesNo) = vbNo Then
                        Exit Sub
                    Else
                        sqlstr = "delete from relation where id = " & id
                    End If
                End If
            Case 3
                Dim cpdata = Collect_data2("SELECT cp.name, ac.name, j.name As journal, t.name FROM CP
                                LEFT join account ac on cp.id = ac.f_key
                                LEFT JOIN journal j on ac.id = j.fk_account
                                LEFT JOIN target t on t.fk_cp_id = cp.id 
                                WHERE ac.id is not distinct from null or j.id is not distinct from null 
                                or cp.id is not distinct from null AND cp.id =" & id)
                Dim account_id = cpdata.Rows(0)(1)
                If cpdata.Rows.Count = 0 Then
                    MsgBox("Deze staat nog geregistreerd bij doel(en) en/of journaalposten." & vbCrLf &
                           "U kunt het niet verwijderen, maar wel inactief maken zodat deze niet mmer gebruikt kan worden.")
                    Exit Sub
                Else
                    sqlstr = "Delete from cp where id=" & id & ";DELETE from account WHERE id=" & account_id
                End If
            Case Else
                MsgBox("Deze functie Is nog niet voor dit object gedefinieerd")

        End Select

        If sqlstr <> "" Then
            RunSQL(sqlstr, "NULL", "Menu_Delete_Click")
            Load_Table()
            MsgBox("Het object is verwijderd.")
        End If

    End Sub

    Private Sub Btn_Excasso_Calculate_Exchrate_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Calculate_Exchrate.Click
        MsgBox("Deze functie is niet langer beschikbaar")
        Exit Sub
        Dim LocalFilePath As String = "C:\temp\lcal.html"
        Dim objWebClient As New System.Net.WebClient
        'objWebClient.DownloadFile("https://www.google.com/search?newwindow=1&sxsrf=ALeKk00tqujhzWGn2oO1UiVUC8hWGsGjvw%3A1596922685176&ei=PRsvX5KlCoHisAfjxqjQAQ&q=exchange+rate+eur+mdl&oq=exchange+ra&gs_lcp=CgZwc3ktYWIQARgAMgYIIxAnEBMyBQgAELEDMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIADICCAA6BAgjECc6AgguOggIABCxAxCDAToECAAQAzoECAAQQzoHCAAQsQMQQzoICC4QsQMQgwFQ8f8YWIORGWCLnxloAHAAeACAAdoBiAGVCJIBBjExLjAuMZgBAKABAaoBB2d3cy13aXrAAQE&sclient=psy-ab", LocalFilePath)
        objWebClient.DownloadFile("https://eur.fxexchangerate.com/mdl-exchange-rates-history.html", LocalFilePath)

        Dim text As String = File.ReadAllText("C:\Temp\lcal.html")
        Dim index As Integer = text.IndexOf("<td>1 EUR =</td>")
        If index >= 0 Then
            Tbx_Excasso_Exchange_rate.Text = Math.Round(CDbl(Replace((Strings.Mid(text, index + 22, 8)), ".", ",")), 1)

        Else
            MsgBox("Wisselkoers niet gevonden.")
        End If
    End Sub

    Private Sub TestToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Login.Text = "Inloggen in productieomgeving"
        Login.Cmx_Login_Database.Text = "Test"
        Login.Show()
    End Sub

    Private Sub Btn_Excasso_Cancel_Click(sender As Object, e As EventArgs) Handles Btn_Excasso_Cancel.Click
        If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
    End Sub


    Private Sub Btn_Bank_Split_Click(sender As Object, e As EventArgs) Handles Btn_Bank_Split.Click, Dgv_Bank.DoubleClick

        Banksplit.Lbl_Split_Description.Text = Dgv_Bank.SelectedCells(3).Value
        Banksplit.Lbl_Split_seqorder.Text = Dgv_Bank.SelectedCells(9).Value
        Banksplit.Lbl_Split_Bank_id.Text = Dgv_Bank.SelectedCells(0).Value
        Banksplit.Lbl_SplitBank_journal_name.Text = Dgv_Bank.SelectedCells(12).Value

        Banksplit.Lbl_Split_Amount.Text = QuerySQL("Select sum(credit) - sum(debit) from bank where seqorder = '" & Banksplit.Lbl_Split_seqorder.Text & "';")

        If Not Check_Change_Bank_Categories(False) Then Exit Sub
        Dim cnt = QuerySQL("select count(j.fk_account) from bank b left join journal j on j.fk_bank = b.id where b.id=" & Banksplit.Lbl_Split_Bank_id.Text)
        If cnt <> 1 Then
            MsgBox("Splitsen van een banktransactie met meerdere categoriëen is niet mogelijk")
            Exit Sub
        End If

        Banksplit.Lbl_SplitBank_Accountnr.Text = QuerySQL("select j.fk_account||' ['||a.name||']' from bank b left join journal j on j.fk_bank = b.id 
            left join account a on a.id = j.fk_account where b.id=" & Banksplit.Lbl_Split_Bank_id.Text)
        Dim jtype = QuerySQL("select j.type from bank b left join journal j on j.fk_bank = b.id 
            left join account a on a.id = j.fk_account where b.id=" & Banksplit.Lbl_Split_Bank_id.Text)
        If Not IsDBNull(jtype) Then Banksplit.Lbl_SplitBank_Type.Text = jtype

        Banksplit.Show()

    End Sub


    Private Sub Rbn_00_contract_child_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_00_contract_child.CheckedChanged
        Tbx_Contract_ttype.Text = "Kind"
    End Sub

    Private Sub Rbn_00_contract_elder_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_00_contract_elder.CheckedChanged
        Tbx_Contract_ttype.Text = "Oudere"
    End Sub

    Private Sub Rbn_00_contract_other_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_00_contract_other.CheckedChanged
        Tbx_Contract_ttype.Text = "Overig"
    End Sub

    Private Sub Btn_Settings_Cancel_Click(sender As Object, e As EventArgs)
        Load_Account_Settings()
    End Sub


    Private Sub Dgv_Excasso2_Click(sender As Object, e As EventArgs) Handles Dgv_Excasso2.Click
        'If Dgv_Excasso2.CurrentCell.ColumnIndex <> 1 Then Exit Sub

        Dim i As Integer = Me.Dgv_Excasso2.CurrentRow.Index

        Dim name As String = Me.Dgv_Excasso2.Rows(i).Cells(1).Value
        Dim id = Me.Dgv_Excasso2.Rows(i).Cells(0).Value



        Dim sql As String = $"
         Select j.date As dat, j.name As Journaalnaam, amt1 As Bedr, j.description As Omschrijving from journal j
         where j.fk_account = '{id}'
         order by j.date desc, abs(amt1::decimal) 
"
        Format_Datagridview2(Dgv_Uitkering_Account_Details, sql, {"FZ048", "TZ190", "NZ056", "TZ250"})

        With Dgv_Uitkering_Account_Details

            For Each row As DataGridViewRow In .Rows
                Dim cellValue As Object = row.Cells(2).Value ' Assuming you want to check column 1
                If IsNumeric(cellValue) Then
                    Dim value As Double = Convert.ToDouble(cellValue)
                    If value < 0 Then
                        row.Cells(1).Style.ForeColor = Color.DarkRed
                        row.Cells(2).Style.ForeColor = Color.DarkRed
                    ElseIf value > 0 Then
                        row.Cells(1).Style.ForeColor = Color.Green
                        row.Cells(2).Style.ForeColor = Color.Green
                    Else
                        row.Cells(1).Style.ForeColor = Color.Black ' Default color for zero
                        row.Cells(2).Style.ForeColor = Color.Black
                    End If
                End If
            Next

        End With
    End Sub

    Private Sub Lbl_Excasso_Items_Contract_TextChanged(sender As Object, e As EventArgs) Handles Lbl_Excasso_Items_Contract.TextChanged,
            Lbl_Excasso_Items_Extra.TextChanged, Lbl_Excasso_Items_Intern.TextChanged, Lbl_Excasso_Contractwaarde.TextChanged,
            Lbl_Excasso_Extra.TextChanged, Lbl_Excasso_Intern.TextChanged
        Lbl_Excasso_Contract.Text = Lbl_Excasso_Items_Contract.Text & " gepland, €" _
        & Lbl_Excasso_Contractwaarde.Text & " à"
        Lbl_Excasso_Extr.Text = Lbl_Excasso_Items_Extra.Text & " extra, €" _
        & Lbl_Excasso_Extra.Text & " à"
        Lbl_Excasso_Internal.Text = Lbl_Excasso_Items_Intern.Text & " intern, €" _
        & Lbl_Excasso_Intern.Text & " à"
    End Sub


    Private Sub ToolStripTextBox1_TextChanged(sender As Object, e As EventArgs) Handles Searchbox2.TextChanged
        'Dim dt As New DataTable()
        Select Case TC_Main.SelectedIndex
            Case 0
                Load_Table()
            Case 1
                'Fill_bank_transactions("Searchbox.TextChanged")
                If Dgv_Bank.DataSource IsNot Nothing Then
                    ApplyFilter(Dgv_Bank.DataSource)
                    Format_dvg_bank()
                End If

            Case 4
                Select Case TC_Boeking.SelectedIndex
                    Case 1
                        Fill_Cmx_Journal_List()
                End Select

            Case 5

                ' dt = Dgv_Rapportage_Overzicht.DataSource
                If Dgv_Rapportage_Overzicht.DataSource IsNot Nothing Then
                    ApplyFilter(Dgv_Rapportage_Overzicht.DataSource)
                    Format_Datagridview(Dgv_Rapportage_Overzicht, LbL_Formatting.Text.Split(","c), False)
                End If
        End Select


    End Sub

    Sub ApplyFilter(ByVal dt As DataTable)
        If String.IsNullOrWhiteSpace(Searchbox2.Text) Then
            dt.DefaultView.RowFilter = "" ' Clear filter if search box is empty
            Return
        End If

        ' Split search terms by spaces
        Dim searchTerms As String() = Searchbox2.Text.Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)

        Dim filterParts As New List(Of String)

        For Each term As String In searchTerms
            Dim termFilter As String = ""
            For Each col As DataColumn In dt.Columns
                If Not String.IsNullOrEmpty(col.ColumnName) Then
                    If termFilter.Length > 0 Then termFilter &= " OR "
                    termFilter &= $"CONVERT([{col.ColumnName}], 'System.String') LIKE '%{term}%'"
                End If
            Next
            ' Wrap each term's filter in parentheses and add to the list
            filterParts.Add($"({termFilter})")
        Next

        ' Combine all term filters with AND
        dt.DefaultView.RowFilter = String.Join(" AND ", filterParts)
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles MenuFilter.Click
        Searchbox2.Text = ""
    End Sub

    Private Sub Lv_Journal_List_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lv_Journal_List.SelectedIndexChanged
        Fill_Journal_List_journaalposten()
    End Sub

    Private Sub Cbx_LifeCycle_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cbx_LifeCycle2.SelectedIndexChanged

        Select Case TC_Main.SelectedIndex
            Case 0
                Try
                    MenuDelete.Enabled = (Cbx_LifeCycle2.Text = "Inactief") Or Dtp_31_contract__startdate.Value > Date.Today
                    Load_Table()
                Catch ex As Exception
                End Try
            Case 1
                'Fill_bank_transactions()
            Case 4
                Fill_Cmx_Journal_List()
        End Select
    End Sub


    Private Sub MenuSave_Click(sender As Object, e As EventArgs) Handles MenuSave.Click
        Select Case TC_Main.SelectedIndex
            Case 0 'basisadministratie
                Basis_Save()
                Lbx_Basis.Enabled = True
            Case 1 'Bank
                Save_Banktransaction_Accounts()
                Dgv_Bank.Enabled = True
            Case 2 'Incasso
                Create_Incasso_Journals()
                Create_SEPA_XML()
                Me.Lbl_Incasso_Status.Text = "Open"
                Menu_Print.Enabled = True

            Case 3 'Uitkeringen
                If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
                Save_Excasso_job()
            Case 4
                Select Case TC_Boeking.SelectedIndex
                    Case 0
                        Save_Internal_Booking()
                    Case 1
                        Save_modified_journaalposts()
                End Select
                Load_Cmx_Bank_Account()
        End Select
        Enable_Buttons(False, True)

        'isManualChange = False
    End Sub

    Sub Leeg_overboeking_scherm()
        If TC_Boeking.SelectedIndex = 0 Then
            Lbl_Journal_Source_Saldo.Text = 0
            Lbl_Journal_Source_Name.Text = ""
            Tbx_Journal_Source_Amt.Text = 0
            Dgv_Journal_Intern.Rows.Clear()
            Lbl_Journal_Source_Restamt.Text = 0
            Cmbx_Overboeking_Bron.SelectedIndex = -1
            Cmbx_Overboeking_Target.SelectedIndex = -1
            Tbx_Journal_Description.Text = ""
            Dtp_Journal_intern.Value = Date.Today
            Tbx_Journal_Name.Text = ""
        End If
    End Sub


    Private Sub MenuAdd_Click(sender As Object, e As EventArgs) Handles MenuAdd.Click
        Select Case TC_Main.SelectedIndex
            Case 0
                Basis_Add()
            Case 3
        End Select
        Enable_Buttons(True, False)
        Lbx_Basis.Enabled = False

    End Sub

    Private Sub MenuCancel_Click(sender As Object, e As EventArgs) Handles MenuCancel.Click
        'isManualChange = False
        Select Case TC_Main.SelectedIndex
            Case 0
                Cancel()
            Case 1
                'Dgv_Bank.Click()
                Fill_bank_transactions("MenuCancel_Click", Me.Dgv_Bank.SelectedCells(3).RowIndex)
                Fill_Journals_by_bank(Me.Dgv_Bank.SelectedCells(0).Value)


                'If .Dgv_Bank.RowCount > 0 Then SPAS.Dgv_Bank.Rows(.Dgv_Bank.SelectedCells(3).RowIndex).Selected = True
                SelectRowById(Dgv_Bank, Dgv_Bank.SelectedCells(0).Value)
                'If Me.Dgv_Bank.RowCount > 0 Then Me.Dgv_Bank.Rows(Me.Dgv_Bank.SelectedCells(3).RowIndex).Selected = True
                'StoreInitialValues(Me.Controls)
            Case 3
                If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
            Case 4
                Leeg_overboeking_scherm()
            Case 6
                Load_Account_Settings()
        End Select
        Enable_Buttons(False, True)
        Lbx_Basis.Enabled = True
        Dgv_Bank.Enabled = True

        'isManualChange = True
    End Sub

    Private Sub MenuDelete_Click(sender As Object, e As EventArgs) Handles MenuDelete.Click


        Select Case TC_Main.SelectedIndex
            Case 0
                Basis_Delete()
            Case 2
                RunSQL("Delete From Journal where name ='" &
                Me.Lbl_Incasso_job_name.Text & "'", "NULL", "Btn_Incasso_Delete_Click")
                Me.Lbl_Incasso_Status.Text = "Nieuw"
                Menu_Print.Enabled = False

                Me.Lbl_Incasso_Error.Visible = False
            Case 3
                MenuExcassoDelete()
        End Select
        Enable_Buttons(False, True)
    End Sub

    Private Sub MenuBanktransactie_Click(sender As Object, e As EventArgs) Handles MenuBanktransactie.Click
        Download_Bank_Transactions()
    End Sub

    Private Sub MenuUploadAlles_Click(sender As Object, e As EventArgs) Handles MenuUploadAlles.Click
        Load_Bank_csv_from_folder()
    End Sub

    Private Sub MenuCategoriseer_Click(sender As Object, e As EventArgs) Handles MenuCategoriseer.Click
        Categorize_Bank_Transactions(True, True, True, True, True, True, True)
        Fill_bank_transactions("MenuCategoriseer", Me.Dgv_Bank.SelectedCells(3).RowIndex)
    End Sub

    Private Sub Menu_Print_Click(sender As Object, e As EventArgs) Handles Menu_Print.Click
        Select Case TC_Main.SelectedIndex
            Case 2
                Create_SEPA_XML()
            Case 3
                If Cmx_Excasso_Select.SelectedIndex = -1 Then Exit Sub
                Save_Excasso_job()
                Print_Excasso_form()
        End Select
    End Sub

    Private Sub TC_Main_Click(sender As Object, e As EventArgs) Handles TC_Main.SelectedIndexChanged
        'MsgBox($" begin TC_Main.Selectedindechanged: {isManualChange}")
        Enable_Buttons(False, True)
        Select Case TC_Main.SelectedIndex

            Case 0
                isManualChange = True
                If Searchbox2.Text <> "" Then Load_Table()

            Case 1  'bank
                isManualChange = True
                Searchbox2.Text = ""


                'only load the bank data if datagridview is still empty
                If Dgv_Bank.Rows.Count = 0 Or Dgv_Bank.DataSource Is Nothing Then
                    If Me.Dgv_Mgnt_Tables.Rows(1).Cells(1).Value > 0 Then
                        Fill_bank_transactions("Cmx_Bank_bankacc.SelectedIndexChanged", 0)
                    End If
                End If

                Enable_Buttons(False, False)
            Case 2 'incasso
                isManualChange = False
                If Me.Dgv_Mgnt_Tables.Rows(3).Cells(1).Value > 0 And
                    Me.Dgv_Mgnt_Tables.Rows(5).Cells(1).Value > 0 And
                    Me.Dgv_Mgnt_Tables.Rows(8).Cells(1).Value > 0 Then
                    Create_Incassolist()
                    Dtp_Incasso_start.Format = DateTimePickerFormat.Custom
                    Dtp_Incasso_start.CustomFormat = "MMMM yyyy"
                    Dtp_Incasso_start.ShowUpDown = True
                    Format_Datagridview2(Dgv_Incasso, Nothing, {"TZ205", "NG080", "TZ160", "TZ080", "TZ090", "DZ090"})
                End If
                isManualChange = True
            Case 3 'uitkering
                isManualChange = False
                Enable_Buttons((Dgv_Excasso2.Rows.Count > 0), (Dgv_Excasso2.Rows.Count = 0))

                MenuBanktransactie.Visible = False '
                MenuUploadAlles.Visible = False
                MenuBanktransactie.Visible = False
                MenuCategoriseer.Visible = False

                If Me.Dgv_Mgnt_Tables.Rows(3).Cells(1).Value > 0 And
                    Me.Dgv_Mgnt_Tables.Rows(5).Cells(1).Value > 0 And
                    Me.Dgv_Mgnt_Tables.Rows(8).Cells(1).Value > 0 And
                    Me.Cmx_Excasso_Select.SelectedItem = "" Then

                    Dtp_Excasso_Start.ShowUpDown = False
                    Dtp_Excasso_Start.Value = CDate(Date.Today.Year & "-" & Date.Today.Month & "-" & Date.Today.Day)
                    Dtp_Excasso_Start.MaxDate = CDate(Date.Today.Year & "-" & Date.Today.Month & "-" & Date.Today.Day)
                    Fill_Cmx_Excasso_Select_Combined()
                End If
                isManualChange = True
            Case 4
                isManualChange = False
                Enable_Buttons(False, False)
                Menu_Export.Enabled = True


                Me.Dtp_Journal_intern.Value = CDate(Date.Today.Year & "-" & Date.Today.Month & "-" & Date.Today.Day)
                Dim sql As String = "update journal j set name = 
                (select left(replace(replace(replace(replace(replace(replace(replace(b.name,' van der',''),' van de',''),'Hr ',''),'Mw ',''),' de ',''),' van ',''),'.',''),14) 
                from bank b where b.id = j.fk_bank)||'/'||(select a.name from account a where a.id = j.fk_account)
                where name='nog te bepalen' and fk_account != (select value::integer from settings where label='nocat') and source = 'Bank'"
                RunSQL(sql, "NULL", "TC_Main_Click")
                isManualChange = True
            Case 5
                isManualChange = False
                'Enable_Buttons(False, False)

            Case 6
                isManualChange = False
                Load_Account_Settings()
                isManualChange = True
        End Select

        Show_buttons()

    End Sub
    Private Sub TC_Boeking_Click(sender As Object, e As EventArgs) Handles TC_Boeking.Click

        Enable_Buttons(False, False)
        Menu_Export.Enabled = True

        Searchbox2.Text = ""
        If Lbl_Journal_Source_Name.Text = "" Then
            Tbx_Journal_Name.Text = ""
            Rbn_Journal_Intern.Checked = True
        End If
        Select Case TC_Boeking.SelectedIndex
            Case 2
                Report_Closing()
        End Select
        Show_buttons()

    End Sub

    Private Sub Dgv_Bank_Account_Leave(sender As Object, e As EventArgs) Handles Dgv_Bank_Account.Leave
        Calculate_Total_Booked("Dgv_Bank_Account_Leave")
    End Sub

    Private Sub Menu_Export_Click_1(sender As Object, e As EventArgs) Handles Menu_Export.Click
        Export2Excel()
    End Sub


    Private Sub Rbn_uitkering_saldo_Click(sender As Object, e As EventArgs) Handles Rbn_uitkering_saldo.Click
        Prefill_Excasso_Form()
        Calculate_Excasso_Totals2()

        'Call_Excasso_form("saldo")
    End Sub

    Private Sub Rbn_uitkering_budget_Click(sender As Object, e As EventArgs) Handles Rbn_uitkering_budget.Click
        Prefill_Excasso_Form()
        Calculate_Excasso_Totals2()
        'Call_Excasso_form("budget")
    End Sub

    Private Sub Rbn_uitkering_nul_Click(sender As Object, e As EventArgs) Handles Rbn_uitkering_nul.Click
        Set_Excasso_Nullvalues2()
    End Sub

    Sub Set_Excasso_Nullvalues2()
        If Dgv_Excasso2.Rows.Count > 0 Then
            'Convert_Null_to_0()
            For x As Integer = 0 To Dgv_Excasso2.Rows.Count - 1
                For y = 6 To 10
                    Dgv_Excasso2.Rows(x).Cells(y).Value = 0
                Next
            Next
            Lbl_Excasso_Items_Totaal.Text = 0
            Lbl_Excasso_Items_Contract.Text = 0
            Lbl_Excasso_Items_Extra.Text = 0
            Lbl_Excasso_Items_Intern.Text = 0
            Lbl_Excasso_Contractwaarde.Text = 0
            Lbl_Excasso_Extra.Text = 0
            Lbl_Excasso_Intern.Text = 0
            Lbl_Excasso_Totaal.Text = 0
            Lbl_Excasso_Tot_Gen_MLD.Text = 0
            Lbl_Excasso_Tot_Gen.Text = 0
            Lbl_Excasso_Totaal_MDL.Text = 0
            Calculate_CP_Allowance()
        End If
    End Sub
    Sub Prefill_Excasso_Form()

        Dim r = IIf(Rbn_uitkering_budget.Checked, 2, 3)

        For x As Integer = 0 To Dgv_Excasso2.Rows.Count - 1
            Dgv_Excasso2.Rows(x).Cells(6).Value = IIf(Dgv_Excasso2.Rows(x).Cells(r).Value > 0, Dgv_Excasso2.Rows(x).Cells(r).Value, 0)
            Dgv_Excasso2.Rows(x).Cells(7).Value = Dgv_Excasso2.Rows(x).Cells(4).Value
            Dgv_Excasso2.Rows(x).Cells(8).Value = Dgv_Excasso2.Rows(x).Cells(5).Value

        Next x

    End Sub

    Sub Empty_Excasso_Window()

        Dgv_Excasso2.DataSource = Nothing
        Dgv_Excasso2.Rows.Clear()
        Me.Dgv_Excasso2.Columns.Clear()
        Lbl_Excasso_Items_Contract.Text = 0
        Lbl_Excasso_Items_Extra.Text = 0
        Lbl_Excasso_Items_Intern.Text = 0
        Lbl_Excasso_Extra.Text = 0
        Lbl_Excasso_Contractwaarde.Text = 0
        Lbl_Excasso_Intern.Text = 0
        Lbl_Excasso_Totaal.Text = 0
        Lbl_Excasso_Items_Totaal.Text = 0
        Lbl_Excasso_Totaal_MDL.Text = 0
        Lbl_Excasso_Tot_Gen_MLD.Text = 0
        Lbl_Excasso_Tot_Gen.Text = 0
        Cbx_Uitkering_Kind.Checked = False
        Cbx_Uitkering_Oudere.Checked = False
        Cbx_Uitkering_Overig.Checked = False
        Tbx_Excasso_CP1.Text = 0
        Tbx_Excasso_CP2.Text = 0
        Tbx_Excasso_CP3.Text = 0
    End Sub

    Private Sub Button1_Click_2(sender As Object, e As EventArgs)
        MsgBox("Dit is een handmatige activiteit die door de databasebeheerder moet worden uitgevoerd")
    End Sub

    Private Sub Btn_Report_YearEnd_Post_Click(sender As Object, e As EventArgs) Handles Btn_Report_YearEnd_Post.Click
        Close_Year()
    End Sub

    Private Sub Tbx_Bank_Description_TextChanged(sender As Object, e As EventArgs) Handles Tbx_Bank_Description.TextChanged
        Dgv_Bank.SelectedCells(3).Value = Tbx_Bank_Description.Text
    End Sub
    Private Sub Tbx_01_Accgroup__type_TextChanged(sender As Object, e As EventArgs) Handles Tbx_01_Accgroup__type.TextChanged
        Rbtn_accgroup_Income.Checked = Strings.Trim(Tbx_01_Accgroup__type.Text) = "Inkomsten"
        Rbtn_accgroup_expense.Checked = Strings.Trim(Tbx_01_Accgroup__type.Text) = "Uitgaven"
        Rbtn_accgroup_transit.Checked = Strings.Trim(Tbx_01_Accgroup__type.Text) = "Transit"
        '@@@ hard value vervangen door tt_type.Text
    End Sub

    Private Sub Rbtn_accgroup_Income_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_accgroup_Income.Click
        If MenuSave.Enabled Then Tbx_01_Accgroup__type.Text = Rbtn_accgroup_Income.Text
    End Sub

    Private Sub Rbtn_accgroup_expense_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_accgroup_expense.Click
        If MenuSave.Enabled Then Tbx_01_Accgroup__type.Text = Rbtn_accgroup_expense.Text
    End Sub

    Private Sub Rbtn_accgroup_transit_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_accgroup_transit.Click
        If MenuSave.Enabled Then Tbx_01_Accgroup__type.Text = Rbtn_accgroup_transit.Text
    End Sub


    Sub Format_Datagridview(dgv As DataGridView, arr As Array, Editable As Boolean)

        'formatarray
        '[datatypeletter(1)][kleurletter(1)][widthnumber(3)]'
        '*** datatype

        'T = Standaardformaat
        'U = Standaardformaat editable (blauw)
        'N = Numeriek / 2 cijfers achter de komma
        'M = Numeriek / Editable (blauw)
        'H = Verberg kolom
        'D = Datum
        'Getallen: kolombreedte
        'Rijen: Tota betekent totaalkolom

        Dim c As Integer
        Dim f As String
        Dim tstr1, tstr2 As String

        Try
            With dgv
                ' ================ formatteer kolommen ================

                For x = 0 To UBound(arr)
                    c = CInt(Mid(arr(x), 2))
                    f = Strings.Left(arr(x), 1)

                    .Columns(x).ReadOnly = Not Editable
                    .Columns(x).Width = c
                    .Columns(x).HeaderText = Strings.Left(.Columns(x).HeaderText, 1).ToUpper & Strings.Mid(.Columns(x).HeaderText, 2).ToLower

                    If f = "N" Then
                        .Columns(x).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(x).DefaultCellStyle.Format = "N2"
                    ElseIf f = "M" Then
                        .Columns(x).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        .Columns(x).DefaultCellStyle.Format = "N2"
                        .Columns(x).DefaultCellStyle.ForeColor = Color.Blue
                        .Columns(x).ReadOnly = Editable
                        'blauwe kleur
                    ElseIf f = "H" Then : .Columns(x).Visible = False
                    ElseIf f = "D" Then : .Columns(0).DefaultCellStyle.Format = "dd-MM"
                    ElseIf f = "E" Then : .Columns(0).DefaultCellStyle.Format = "dd-MM-yy"
                    ElseIf f = "U" Then
                        .Columns(x).DefaultCellStyle.ForeColor = Color.Blue
                        .Columns(x).ReadOnly = Editable
                    End If
                Next

                ' ==================formatter rijen =================

                For r As Integer = 0 To .Rows.Count - 1

                    For x = 0 To UBound(arr)
                        'Hide_Zero_values(dgv.Rows(r).Cells(x).Value)
                        If IsDBNull(.Rows(r).Cells(x).Value) Then .Rows(r).Cells(x).Value = 0
                        If .Rows(r).Cells(x).Value IsNot Nothing Then
                            If .Rows(r).Cells(x).Value.ToString = "0,00" Or .Rows(r).Cells(x).Value.ToString = "0" Then
                                .Rows(r).Cells(x).Style.ForeColor = Color.LightGray
                            End If
                        End If

                        tstr1 = CStr(.Rows(r).Cells(x).Value)
                        tstr2 = Strings.Mid(CStr(.Rows(r).Cells(x).Value), 6)


                        If InStr(tstr1, "Tota") > 0 Then
                            .Rows(r).DefaultCellStyle.BackColor = Color.Khaki

                        ElseIf InStr(tstr1, "Afschrift") > 0 Then : .Rows(r).DefaultCellStyle.BackColor = Color.DarkSeaGreen
                        ElseIf InStr(tstr1, "(Excasso)") > 0 Then : .Rows(r).DefaultCellStyle.BackColor = Color.White
                        ElseIf InStr(tstr1, "(Tussenrekening)") > 0 Then : .Rows(r).DefaultCellStyle.BackColor = Color.Gainsboro
                        ElseIf InStr(tstr1, "#") > 0 Then : .Rows(r).DefaultCellStyle.BackColor = Color.DarkSeaGreen
                        End If

                        'extra formatting 
                        If InStr(tstr1, "generaal") > 0 Then
                            .Rows(r).DefaultCellStyle.Font = New Font("Calibri", 12, FontStyle.Bold)
                            .Rows(r).DefaultCellStyle.ForeColor = Color.Blue
                        End If
                        If InStr(tstr1, "Vergelijking") > 0 Then
                            .Rows(r).DefaultCellStyle.Font = New Font("Calibri", 10, FontStyle.Italic)
                            .Rows(r).DefaultCellStyle.ForeColor = Color.Blue
                        End If

                    Next x
                Next r
            End With
        Catch ex As Exception
            MsgBox($"Formatting failure {vbCr}{ex.ToString}")
        End Try

    End Sub

    Sub Format_Datagridview2(dgv As DataGridView, sql As String, arr As Array)

        If sql IsNot Nothing Then dgv.DataSource = Collect_data2(sql)

        'formatarray
        '[datatypeletter(1)][kleurletter(1)][kolombreedte(3)]'
        '*** datatype ***
        'T = Standaardformaat
        'N = Numeriek / 2 cijfers achter de komma
        'I = Integer /Rechts uitgelijnd
        'J = Integer /Rechts gecentreerd
        'H = Verberg kolom
        'D = Datum

        '*** kleur ***
        'Z = Black
        'B = Blue = Editable
        'G = Green
        'R = DarkRed

        For i As Integer = 0 To Math.Min(arr.Length, dgv.Columns.Count) - 1
            Dim formatStr As String = arr(i).ToString()
            'column formatting
            If formatStr.Length >= 5 Then
                ' Extract components from format string
                Dim dataType As Char = formatStr(0) ' First character (Data Type)
                Dim colorCode As Char = formatStr(1) ' Second character (Color)
                Dim columnWidth As Integer

                ' Extract and convert column width (last 3 characters)
                If Integer.TryParse(formatStr.Substring(2, 3), columnWidth) Then dgv.Columns(i).Width = columnWidth

                ' Set column data type (Example: Making column read-only for certain types)
                dgv.Columns(i).HeaderText = Strings.Left(dgv.Columns(i).HeaderText, 1).ToUpper & Strings.Mid(dgv.Columns(i).HeaderText, 2).ToLower
                Select Case dataType
                    Case "D"c : dgv.Columns(i).DefaultCellStyle.Format = "dd-MM-yyyy"
                    Case "E"c : dgv.Columns(i).DefaultCellStyle.Format = "MM-yy"
                    Case "F"c : dgv.Columns(i).DefaultCellStyle.Format = "dd-MM"
                    Case "N"c
                        dgv.Columns(i).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        dgv.Columns(i).DefaultCellStyle.Format = "N2"
                    Case "I"c
                        dgv.Columns(i).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                        dgv.Columns(i).DefaultCellStyle.Format = "N0"
                    Case "J"c
                        dgv.Columns(i).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                        dgv.Columns(i).DefaultCellStyle.Format = "N0"
                    Case "H"c : dgv.Columns(i).Visible = False
                    Case Else : dgv.Columns(i).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
                End Select

                Select Case colorCode
                    Case "R"c : dgv.Columns(i).DefaultCellStyle.ForeColor = Color.DarkRed
                    Case "G"c : dgv.Columns(i).DefaultCellStyle.ForeColor = Color.Green
                    Case "B"c
                        dgv.Columns(i).DefaultCellStyle.ForeColor = Color.Blue
                        dgv.Columns(i).ReadOnly = False
                End Select
            End If
            'row formatting
            For r As Integer = 0 To dgv.Rows.Count - 1
                ' (1) Set row background color based on first column text
                If dgv.Columns.Count > 0 Then
                    Dim firstColValue As String = dgv.Rows(r).Cells(0).Value?.ToString()

                    If Not String.IsNullOrEmpty(firstColValue) Then
                        If firstColValue.Contains("Total") Then : dgv.Rows(r).DefaultCellStyle.BackColor = Color.Khaki
                        ElseIf firstColValue.Contains("#") Then : dgv.Rows(r).DefaultCellStyle.BackColor = Color.DarkSeaGreen
                        ElseIf firstColValue.Contains("Afschrift") Then : dgv.Rows(r).DefaultCellStyle.BackColor = Color.DarkSeaGreen
                        ElseIf firstColValue.Contains("(Excasso)") Then : dgv.Rows(r).DefaultCellStyle.BackColor = Color.White
                        ElseIf firstColValue.Contains("Tussenrekening") Then : dgv.Rows(r).DefaultCellStyle.BackColor = Color.Gainsboro
                        ElseIf firstColValue.Contains("generaal") Then
                            dgv.Rows(r).DefaultCellStyle.BackColor = Color.DarkSeaGreen
                            dgv.Rows(r).DefaultCellStyle.ForeColor = Color.Blue
                        ElseIf firstColValue.Contains("vergelijking") Then
                            dgv.Rows(r).DefaultCellStyle.BackColor = Color.DarkSeaGreen
                            dgv.Rows(r).DefaultCellStyle.ForeColor = Color.Blue
                        End If
                    End If
                End If

                ' (2) Zero Value Coloring (for numeric columns)

                If IsDBNull(dgv.Rows(r).Cells(i).Value) Then dgv.Rows(r).Cells(i).Value = 0
                If dgv.Rows(r).Cells(i).Value IsNot Nothing Then
                    If dgv.Rows(r).Cells(i).Value.ToString = "0,00" Or dgv.Rows(r).Cells(i).Value.ToString = "0" Then
                        dgv.Rows(r).Cells(i).Style.ForeColor = Color.LightGray 'dgv.Rows(r).DefaultCellStyle.BackColor ' Make it blend
                    End If
                End If

            Next
        Next
    End Sub


    Private Sub Rbn_Bank_jtype_con_CheckedChanged(sender As Object, e As EventArgs) Handles Rbn_Bank_jtype_con.CheckedChanged, Rbn_Bank_jtype_ext.CheckedChanged, Rbn_Bank_jtype_int.CheckedChanged
        Btn_Bank_Add_Journal.Enabled = True
    End Sub


    Private Sub Btn_Report_YearEnd_Check_Click(sender As Object, e As EventArgs) Handles Btn_Report_YearEnd_Check.Click
        Dim ans = Check_administratie()
    End Sub

    Private Sub Btn_Query_Test_Click(sender As Object, e As EventArgs)

        If UCase(Strings.Left(Tbx_Query_SQL.Text, 6)) <> "SELECT" Then
            MsgBox("Alleen select-statements zijn toegestaan")
        Else
            Load_Datagridview(Dgv_Query_Test, Tbx_Query_SQL.Text, "Btn_Query_Test.Click")
            'MsgBox("Query is niet correct")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim p1 = InputBox("maand:")
        Dim sql = QuerySQL("Select sql from query where category ilike 'Transaction' and name='Verwijder maand'")
        sql = sql.Replace("p1", p1)
        ToClipboard(sql, True)
        RunSQL(sql, "NULL", "Testbutton verwijder maand")
        Fill_bank_transactions("Button1", 0)
    End Sub


    Private Sub Tbx_Extra_Info_TextChanged(sender As Object, e As EventArgs) Handles Tbx_Bank_Extra_Info.TextChanged
        Dim des As String = Tbx_Bank_Description.Text
        If Chbx_Bank_ExtraInfo_voor.Checked Then
            If Strings.InStr(des, " | ") = 0 And Tbx_Bank_Extra_Info.Text <> "" Then des = " | " & des
            Try
                des = Tbx_Bank_Extra_Info.Text & Strings.Mid(des, Strings.InStr(des, " | "))
            Catch
            End Try
        End If
        If Tbx_Bank_Extra_Info.Text = "" And Strings.InStr(des, " | ") > 0 Then des = Mid(des, Strings.InStr(des, " | ") + 3)
        Tbx_Bank_Description.Text = des
    End Sub

    Private Sub Menu_Help_Click(sender As Object, e As EventArgs) Handles Menu_Help.Click
        Process.Start("https://github.com/Erthengs/SPAS2025/wiki/Stappenplan-(Maandelijks)")
    End Sub
    '========================================================================================================
    '======                                                                                            ======
    '======                                B O E K I N G E N                                           ======
    '======                                                                                            ======
    '========================================================================================================

    Sub Lv_Journal_List_Click(sender As Object, e As EventArgs) Handles Lv_Journal_List.Click

        Try
            Dim selectedItem As ListViewItem = Lv_Journal_List.SelectedItems(0)
            Dim journaaldata = Collect_data2(Create_Journal_SQL)

            Me.Lbl_Journaalposten_datum.Text = IIf(IsDBNull(journaaldata.Rows(0)(0)), "", journaaldata.Rows(0)(0))
            Me.Lbl_Journaalposten_header.Text = IIf(IsDBNull(journaaldata.Rows(0)(1)), "", journaaldata.Rows(0)(1))
            'Me.Tbx_journaalposten_omschr.Text = IIf(IsDBNull(journaaldata.Rows(0)(4)), "", journaaldata.Rows(0)(4))
            Me.Lbl_journaalposten_status.Text = IIf(IsDBNull(journaaldata.Rows(0)(6)), "", journaaldata.Rows(0)(6))
            Me.Lbl_Journaalposten_bron.Text = IIf(IsDBNull(journaaldata.Rows(0)(7)), "", journaaldata.Rows(0)(7))
            Me.Lbl_journaalposten_iban.Text = IIf(IsDBNull(journaaldata.Rows(0)(8)), "", journaaldata.Rows(0)(8))
            Me.Lbl_journaalposten_type.Text = IIf(IsDBNull(journaaldata.Rows(0)(9)), "", journaaldata.Rows(0)(9))
            Me.Lbl_journaalposten_cpinfo.Text = IIf(IsDBNull(journaaldata.Rows(0)(14)), "", journaaldata.Rows(0)(14))
            Me.Lbl_journaalposten_wisselkoers.Text = IIf(IsDBNull(journaaldata.Rows(0)(15)), "", journaaldata.Rows(0)(15))
            Me.Banklink.Text = IIf(IsDBNull(journaaldata.Rows(0)(16)), 0, journaaldata.Rows(0)(16).ToString)               'Me.Cmbx_journaalposten_relatie.SelectedIndex = -1

            Fill_Journal_List_journaalposten()

            If Dgv_journaalposten.Rows.Count > 0 Then
                ' Clear any previous selection
                Dgv_journaalposten.ClearSelection()
                Dgv_journaalposten.Rows(0).Selected = True
                Dgv_journaalposten_Click("a", e)
                ' Optionally, scroll to the first row if it is out of view
                Dgv_journaalposten.FirstDisplayedScrollingRowIndex = 0
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    '========================================================================================================
    '======                                                                                            ======
    '======                B O E K I N G E N   - J O U R N A A L P O S T E N                           ======
    '======                                                                                            ======
    '========================================================================================================

    Sub Dgv_journaalposten_Click(sender As Object, e As EventArgs) Handles Dgv_journaalposten.Click

        Try
            Dim selectedRow As DataGridViewRow = Dgv_journaalposten.CurrentRow
            If selectedRow Is Nothing Then selectedRow = Dgv_journaalposten.Rows(0)

            Me.Cmbx_journaalposten_account.SelectedValue = selectedRow.Cells("Accountnr").Value
            Me.Tbx_journaalposten_omschr.Text =
                If(IsDBNull(selectedRow.Cells("Omschrijving").Value), "", selectedRow.Cells("Omschrijving").Value)
            If Not IsDBNull(Me.Dgv_journaalposten.Rows(0).Cells(13).Value) Then
                Me.Cmbx_journaalposten_relatie.SelectedValue = selectedRow.Cells("relatie").Value
            Else
                Me.Cmbx_journaalposten_relatie.SelectedIndex = -1
            End If
        Catch ex As Exception

            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Dgv_journaalposten_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_journaalposten.CellValueChanged
        Try
            If Not Dgv_journaalposten.Rows(e.RowIndex).IsNewRow Then
                Dgv_journaalposten.Rows(e.RowIndex).Tag = "Modified"
                Calculate_Journaalposten_totalen(Dgv_journaalposten)
            End If
        Catch ex As Exception
        End Try
    End Sub



    Private Sub Dgv_journaalposten_UserAddedRow(sender As Object, e2 As DataGridViewRowEventArgs) Handles Dgv_journaalposten.UserAddedRow

        Dgv_journaalposten.Rows(Dgv_journaalposten.RowCount - 2).Cells(2).Value = 0
        Dgv_journaalposten.Rows(Dgv_journaalposten.RowCount - 2).Cells(3).Value = 0
        Dgv_journaalposten.Rows(Dgv_journaalposten.RowCount - 2).Cells(4).Value = "handmatig toegevoegde journaalpost"

    End Sub

    Sub Mark_dgv_changes(dgv)


    End Sub

    Private Sub Cmbx_journaalposten_account_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmbx_journaalposten_account.SelectedIndexChanged
        If Cmbx_journaalposten_account.SelectedIndex = -1 Or
            TC_Boeking.SelectedIndex <> 1 Or Dgv_journaalposten.RowCount = 0 Then Exit Sub
        Try
            Dgv_journaalposten.SelectedCells(11).Value = Cmbx_journaalposten_account.SelectedValue
            Dgv_journaalposten.SelectedCells(5).Value = Cmbx_journaalposten_account.Text

        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Cmbx_journaalposten_relatie_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmbx_journaalposten_relatie.SelectedIndexChanged
        If Cmbx_journaalposten_relatie.SelectedIndex = -1 Then Exit Sub
        Try
            Dgv_journaalposten.SelectedCells(13).Value = Cmbx_journaalposten_relatie.SelectedValue
            Dgv_journaalposten.SelectedCells(17).Value = Cmbx_journaalposten_relatie.Text
        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Tbx_journaalposten_omschr_TextChanged(sender As Object, e As EventArgs) Handles Tbx_journaalposten_omschr.TextChanged
        Try
            Dgv_journaalposten.SelectedCells(4).Value = Tbx_journaalposten_omschr.Text
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Dgv_journaalposten_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_journaalposten.CellClick
        Dim selectedRowIndex As Integer = Dgv_journaalposten.CurrentCell.RowIndex
        With Dgv_journaalposten
            If .CurrentCell.ColumnIndex = 5 Or .CurrentCell.ColumnIndex = 17 Then
                .Rows(selectedRowIndex).Selected = True
            End If
        End With
    End Sub

    Private Sub Banklink_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles Banklink.LinkClicked
        Dim bankid As Integer = Integer.Parse(Banklink.Text)
        If bankid = 0 Or Len(bankid) = 0 Then Exit Sub
        TC_Main.SelectedIndex = 1
        Fill_bank_transactions("TC_Main.SelectedIndex", 0)

        SelectRowById(Dgv_Bank, bankid)


    End Sub

    Private Sub Overboekingen_Click(sender As Object, e As EventArgs) Handles Overboekingen.Click
        With Dgv_Journal_Intern
            .Columns(0).Visible = False
            .Columns(1).Width = 160
            .Columns(1).ReadOnly = True
            .Columns(2).Width = 70
            .Columns(2).DefaultCellStyle.Format = "N2"
            .Columns(2).DefaultCellStyle.ForeColor = Color.Blue
            .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        End With
    End Sub


    Private Sub Cmbx_Overboeking_Bron_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmbx_Overboeking_Bron.SelectedIndexChanged
        If TC_Boeking.SelectedTab.Text <> "Overboekingen" Or Cmbx_Overboeking_Bron.SelectedIndex = -1 Then Exit Sub
        Try
            Dim selectedItem As ComboBoxItem = TryCast(Cmbx_Overboeking_Bron.SelectedItem, ComboBoxItem)

            If selectedItem IsNot Nothing Then
                Tbx_Journal_Source_Amt.Text = selectedItem.Column3
                Calculate_Journal_Booking_Data()
            End If
        Catch
        End Try


    End Sub
    Private Sub Cmbx_Overboeking_Bron_TextChanged(sender As Object, e As EventArgs) Handles Cmbx_Overboeking_Bron.TextChanged
        If Cmbx_Overboeking_Bron.SelectedIndex = -1 Then Tbx_Journal_Source_Amt.Text = "0"
    End Sub
    Private Sub Cmbx_Overboeking_Target_Changed(sender As Object, e As EventArgs) Handles Cmbx_Overboeking_Target.SelectedIndexChanged

        If isProgrammaticChange Then Exit Sub
        If Cmbx_Overboeking_Target.SelectedIndex = -1 Then Exit Sub

        If Cmbx_Overboeking_Bron.SelectedIndex = -1 And TC_Boeking.SelectedTab.Text <> "Overboekingen" Then
            If Tbx2Dec(Lbl_Journal_Source_Restamt.Text) <= 0 Then
                MsgBox($"Selecteer eerst een bronaccount.", vbInformation)
                Exit Sub
            End If
        End If
        Dim selectedItem As ComboBoxItem = TryCast(Cmbx_Overboeking_Target.SelectedItem, ComboBoxItem)
        Dim tgt_tot As Decimal = 0

        If selectedItem IsNot Nothing Then
            If Cmbx_Overboeking_Bron.SelectedIndex > -1 Then
                'MsgBox($"1) {selectedItem.Column2}{vbCr} 2) {selectedItem.Column2}{vbCr} 3) {selectedItem.Column3}")
                With Dgv_Journal_Intern
                    .Rows.Add(selectedItem.Column1)
                    .Rows(.Rows.Count - 1).Cells(1).Value = selectedItem.Column2
                    .Rows(.Rows.Count - 1).Cells(2).Value = Tbx2Dec(Lbl_Journal_Source_Restamt.Text)

                    'calculation of rest amount
                    For i = 0 To .Rows.Count - 1
                        tgt_tot = tgt_tot + .Rows(i).Cells(2).Value
                    Next
                End With
            End If

        End If
        With Dgv_Journal_Intern
            .Columns(0).Visible = False
            .Columns(1).Width = 160
            .Columns(1).ReadOnly = True
            .Columns(2).Width = 70
            .Columns(2).DefaultCellStyle.Format = "N2"
            .Columns(2).DefaultCellStyle.ForeColor = Color.Blue
            .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        End With
        Calculate_Journal_Booking_Data()
        isProgrammaticChange = True
    End Sub


    Private Sub Cmbx_Overboeking_Target_Enter(sender As Object, e As EventArgs) Handles Cmbx_Overboeking_Target.Enter, Cmbx_Overboeking_Target.Click
        isProgrammaticChange = False
    End Sub

    Private Sub Rbtn_Overboekingen_Kind_CheckedChanged(sender As Object, e As EventArgs) Handles Rbtn_Overboekingen_Kind.CheckedChanged,
        Rbtn_Overboekingen_Oudere.CheckedChanged, Rbtn_Overboekingen_alles.CheckedChanged
        If isProgrammaticChange = True Then Exit Sub
        Dim sql As String = "select a.id, a.name, sum(j.amt1), a.id from journal j left join account a on a.id=j.fk_account left join accgroup g on g.id= a.fk_accgroup_id  
        WHERE a.active=True group by a.id, a.name ORDER BY a.name"
        If Rbtn_Overboekingen_Kind.Checked Then
            sql = sql.Replace("True", "True and g.name = 'Kindersponsoring'")
        ElseIf Rbtn_Overboekingen_Oudere.Checked Then
            sql = sql.Replace("True", "True and g.name = 'Ouderensponsoring'")
        End If
        isProgrammaticChange = True
        Populate_Combobox(Cmbx_Overboeking_Target, sql)

    End Sub

    Private Sub Rbtn_Overboekingen_Oudere_Click(sender As Object, e As EventArgs) Handles Rbtn_Overboekingen_Oudere.Click,
            Rbtn_Overboekingen_Oudere.Click, Rbtn_Overboekingen_alles.Click
        isProgrammaticChange = False
    End Sub

    Private Sub Btn_Boeking_Expand_Collapse_Click(sender As Object, e As EventArgs) Handles Btn_Boeking_Expand_Collapse.Click
        If Btn_Boeking_Expand_Collapse.Text = "Alles uitklappen" Then
            AccountTree.ExpandAll()
            Btn_Boeking_Expand_Collapse.Text = "Alles inklappen"
        Else
            AccountTree.CollapseAll()
            Btn_Boeking_Expand_Collapse.Text = "Alles uitklappen"
        End If
    End Sub
    '========================================================================================================
    '======                                                                                            ======
    '======                               R A P P O R T A G E                                          ======
    '======                                                                                            ======
    '========================================================================================================

    Sub ReportTree_NodeMouseClick(sender As Object, e As TreeNodeMouseClickEventArgs) Handles ReportTree.NodeMouseClick

        Dim rep As String = ""
        report_year = Cmbx_Reporting_Year.SelectedItem

        If e.Node.Level = 1 Then
            rep = e.Node.Text
            Lbl_Rapportage.Text = rep
            Run_ReportTree(rep)
        End If

    End Sub

    Private Sub Btn_Rap_Expand_Collapse_Click(sender As Object, e As EventArgs) Handles Btn_Rap_Expand_Collapse.Click
        If Btn_Rap_Expand_Collapse.Text = "Alles uitklappen" Then
            ReportTree.ExpandAll()
            Btn_Rap_Expand_Collapse.Text = "Alles inklappen"
        Else
            ReportTree.CollapseAll()
            Btn_Rap_Expand_Collapse.Text = "Alles uitklappen"
        End If
    End Sub

    Private Sub Cmbx_Reporting_Year_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Cmbx_Reporting_Year.SelectedIndexChanged
        Try
            report_year = Cmbx_Reporting_Year.SelectedItem
            Run_ReportTree(Lbl_Rapportage.Text)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Dgv_Report_6_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_Report_6.CellContentClick
        Dim columnName As String = Dgv_Report_6.Columns(e.ColumnIndex).HeaderText
        If columnName = "Journaalnaam" Then

            SelectNodeByName(ReportTree, "Posten per boeking")
            With Dgv_Report_6
                Searchbox2.Text = $"{ .CurrentCell.Value} { .Rows(.CurrentCell.RowIndex).Cells(0).Value}"
            End With
        End If
    End Sub

    Private Sub dgv_1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_Rapportage_Overzicht.CellContentClick
        Dim selectedNode As TreeNode = ReportTree.SelectedNode

        Select Case selectedNode.Text
            Case "Jaaroverzicht Bank"
                'If Dgv_Rapportage_Overzicht.CurrentCell.ColumnIndex = 1 Then
                'Else
                Drill_down_Bank_overview(Me.Dgv_Rapportage_Overzicht.CurrentCell.RowIndex, Me.Dgv_Rapportage_Overzicht.CurrentCell.ColumnIndex)
                'End If
            Case "Jaarrapportage"
                Drill_down_Report_overview(Dgv_Rapportage_Overzicht.CurrentCell.RowIndex, Dgv_Rapportage_Overzicht.CurrentCell.ColumnIndex)
            Case Else
                Dim columnName As String = Dgv_Rapportage_Overzicht.Columns(e.ColumnIndex).HeaderText
                Dim formatting As String = Nothing
                Dim arr_format() As String = Nothing
                formatting = QuerySQL($"Select formatting from query where category = 'Transaction' and name='Detail journaalposten'")
                If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 AndAlso
                    (columnName = "Accountnaam" Or columnName = "Journaalnaam" Or columnName = "Accountgroep" Or columnName = "Relatienaam") Then
                    ' Get the column header text
                    Dim sql As String = QuerySQL("SELECT sql from query where name = 'Detail journaalposten';")

                    If Not IsNothing(LbL_Formatting.Text) Then arr_format = LbL_Formatting.Text.Split(","c)


                    Select Case columnName
                        Case "Accountnaam"
                            sql = sql.Replace("a.name like '%%'", $"a.name like '{Dgv_Rapportage_Overzicht.CurrentCell.Value}'")
                            formatting = formatting.Replace("T150", "H150")
                        Case "Journaalnaam"
                            sql = sql.Replace("j.name like '%%'", $"j.name like '{Dgv_Rapportage_Overzicht.CurrentCell.Value}'")
                            formatting = formatting.Replace("T250", "H250")
                        Case "Accountgroep"
                            sql = sql.Replace("c.name like '%%'", $"c.name like '{Dgv_Rapportage_Overzicht.CurrentCell.Value}'")
                            formatting = formatting.Replace("T149", "H149")
                        Case "Relatienaam"
                            sql = sql.Replace("concat(r.name||','||r.name_add) like'%%'", $"concat(r.name||','||r.name_add) like '{Dgv_Rapportage_Overzicht.CurrentCell.Value}'")
                            formatting = formatting.Replace("T151", "H151")
                        Case Else
                            'Do nothing
                    End Select
                    Load_Datagridview(Dgv_Report_6, sql, "Dgv_Rapportage_Overzicht.DoubleClick")
                    'MsgBox(formatting)
                    If Not IsNothing(formatting) Then Format_Datagridview(Dgv_Report_6, formatting.Split(","), False)
                    Lbl_Rapportage_Detail.Text = $"Details {Dgv_Rapportage_Overzicht.CurrentCell.Value}"
                End If

        End Select

    End Sub


End Class
