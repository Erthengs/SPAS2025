﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SPAS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SPAS))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuCancel = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuDelete = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Print = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Export = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuBanktransactie = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuCategoriseer = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuUploadAlles = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Back = New System.Windows.Forms.ToolStripMenuItem()
        Me.Menu_Help = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.MenuFilter = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.Tbx_Bank_Description = New System.Windows.Forms.TextBox()
        Me.Instellingen = New System.Windows.Forms.TabPage()
        Me.TC_Management = New System.Windows.Forms.TabControl()
        Me.Settings = New System.Windows.Forms.TabPage()
        Me.Dgv_Settings = New System.Windows.Forms.DataGridView()
        Me.AVG = New System.Windows.Forms.TabPage()
        Me.QueryBuilder = New System.Windows.Forms.TabPage()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Btn_Query_Test = New System.Windows.Forms.Button()
        Me.Tbx_Query_SQL = New System.Windows.Forms.TextBox()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Tbx_Query_Formattering = New System.Windows.Forms.TextBox()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Tbx_Query_Naam = New System.Windows.Forms.TextBox()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Cmbx_Query_Select = New System.Windows.Forms.ComboBox()
        Me.Dgv_Query_Test = New System.Windows.Forms.DataGridView()
        Me.TP_Test = New System.Windows.Forms.TabPage()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Pan_Test = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Chbx_test = New System.Windows.Forms.CheckBox()
        Me.Dgv_Mgnt_Tables = New System.Windows.Forms.DataGridView()
        Me.Tab_Rapportage = New System.Windows.Forms.TabPage()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.Splitter_left = New System.Windows.Forms.Splitter()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Lbl_Rapportage_Detail = New System.Windows.Forms.Label()
        Me.Dgv_Report_6 = New System.Windows.Forms.DataGridView()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Lbl_Rapportage = New System.Windows.Forms.Label()
        Me.Dgv_Rapportage_Overzicht = New System.Windows.Forms.DataGridView()
        Me.LbL_Formatting = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.ReportTree = New System.Windows.Forms.TreeView()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Btn_Rap_Expand_Collapse = New System.Windows.Forms.Button()
        Me.Cmbx_Reporting_Year = New System.Windows.Forms.ComboBox()
        Me.Intern = New System.Windows.Forms.TabPage()
        Me.TC_Boeking = New System.Windows.Forms.TabControl()
        Me.Overboekingen = New System.Windows.Forms.TabPage()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Rbtn_Overboekingen_alles = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Overboekingen_Oudere = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Overboekingen_Kind = New System.Windows.Forms.RadioButton()
        Me.Cmbx_Overboeking_Target = New System.Windows.Forms.ComboBox()
        Me.Rbn_Journal_Extra = New System.Windows.Forms.RadioButton()
        Me.Tbx_Journal_Name = New System.Windows.Forms.TextBox()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Rbn_Journal_Contract = New System.Windows.Forms.RadioButton()
        Me.Rbn_Journal_Intern = New System.Windows.Forms.RadioButton()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Btn_Journal_Intern_Save = New System.Windows.Forms.Button()
        Me.Btn_Journal_Recalculate = New System.Windows.Forms.Button()
        Me.Btn_Journals_Cancel = New System.Windows.Forms.Button()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Dtp_Journal_intern = New System.Windows.Forms.DateTimePicker()
        Me.Dgv_Journal_Intern = New System.Windows.Forms.DataGridView()
        Me.id1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Accnt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amt1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Tbx_Journal_Description = New System.Windows.Forms.TextBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Cmbx_Overboeking_Bron = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Lbl_Journal_Source_Name = New System.Windows.Forms.Label()
        Me.Tbx_Journal_Source_Amt = New System.Windows.Forms.TextBox()
        Me.Lbl_Journal_Source_Saldo = New System.Windows.Forms.Label()
        Me.Lbl_Journal_Source_Restamt = New System.Windows.Forms.Label()
        Me.Lbl_Journal_Source_id = New System.Windows.Forms.Label()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Journaalposten = New System.Windows.Forms.TabPage()
        Me.Splitter4 = New System.Windows.Forms.Splitter()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Dgv_journaalposten = New System.Windows.Forms.DataGridView()
        Me.Lbl_accountname = New System.Windows.Forms.Label()
        Me.Tbx_ = New System.Windows.Forms.TextBox()
        Me.journalid2 = New System.Windows.Forms.Label()
        Me.Tbx_Journal_Saldo = New System.Windows.Forms.TextBox()
        Me.Lbl_Journaalposten_header = New System.Windows.Forms.Label()
        Me.Grp_Journaalposten = New System.Windows.Forms.GroupBox()
        Me.Banklink = New System.Windows.Forms.LinkLabel()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Label144 = New System.Windows.Forms.Label()
        Me.Label146 = New System.Windows.Forms.Label()
        Me.Label143 = New System.Windows.Forms.Label()
        Me.Label142 = New System.Windows.Forms.Label()
        Me.Label141 = New System.Windows.Forms.Label()
        Me.Label140 = New System.Windows.Forms.Label()
        Me.Label138 = New System.Windows.Forms.Label()
        Me.Lbl_journaalposten_iban = New System.Windows.Forms.Label()
        Me.Lbl_journaalposten_cpinfo = New System.Windows.Forms.Label()
        Me.Lbl_journaalposten_wisselkoers = New System.Windows.Forms.Label()
        Me.Lbl_journaalposten_type = New System.Windows.Forms.Label()
        Me.Lbl_journaalposten_status = New System.Windows.Forms.Label()
        Me.Lbl_Journaalposten_bron = New System.Windows.Forms.Label()
        Me.Lbl_Journaalposten_datum = New System.Windows.Forms.Label()
        Me.Tbx_Journal_Debit = New System.Windows.Forms.TextBox()
        Me.GRP_journaalposten_edit = New System.Windows.Forms.GroupBox()
        Me.Label147 = New System.Windows.Forms.Label()
        Me.Btn_journaalposten_Save = New System.Windows.Forms.Button()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Tbx_journaalposten_omschr = New System.Windows.Forms.TextBox()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.Cmbx_journaalposten_relatie = New System.Windows.Forms.ComboBox()
        Me.Lbl00x = New System.Windows.Forms.Label()
        Me.Cmbx_journaalposten_account = New System.Windows.Forms.ComboBox()
        Me.Tbx_Journal_Credit = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Cbx_Journal_Status_Verwerkt = New System.Windows.Forms.CheckBox()
        Me.Lbl_Journal_Status = New System.Windows.Forms.Label()
        Me.Cbx_Journal_Status_Open = New System.Windows.Forms.CheckBox()
        Me.Tbx_Journal_Filter = New System.Windows.Forms.TextBox()
        Me.Lv_Journal_List = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Accounts = New System.Windows.Forms.TabPage()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Btn_Boeking_Expand_Collapse = New System.Windows.Forms.Button()
        Me.AccountTree = New System.Windows.Forms.TreeView()
        Me.Jaarafsluiting = New System.Windows.Forms.TabPage()
        Me.Dgv_Report_Year_Closing = New System.Windows.Forms.DataGridView()
        Me.Btn_Report_YearEnd_Check = New System.Windows.Forms.Button()
        Me.Lbl_Report_total = New System.Windows.Forms.Label()
        Me.Btn_Report_YearEnd_Post = New System.Windows.Forms.Button()
        Me.Uitkering = New System.Windows.Forms.TabPage()
        Me.Splitter3 = New System.Windows.Forms.Splitter()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Dgv_Uitkering_Account_Details = New System.Windows.Forms.DataGridView()
        Me.Splitter2 = New System.Windows.Forms.Splitter()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Dgv_Excasso2 = New System.Windows.Forms.DataGridView()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Gbx_Excasso_Doeltype = New System.Windows.Forms.GroupBox()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Dtp_Excasso_Start = New System.Windows.Forms.DateTimePicker()
        Me.Btn_Excasso_Exchrate = New System.Windows.Forms.Button()
        Me.Tbx_Excasso_Exchange_rate = New System.Windows.Forms.TextBox()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Lbl_Excasso_LastCalc = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_CPid = New System.Windows.Forms.Label()
        Me.Btn_Excasso_Copy_to_clipboard = New System.Windows.Forms.Button()
        Me.Btn_Excasso_Calculate_Exchrate = New System.Windows.Forms.Button()
        Me.Cbx_Uitkering_Kind = New System.Windows.Forms.CheckBox()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Cbx_Uitkering_Oudere = New System.Windows.Forms.CheckBox()
        Me.Cbx_Uitkering_Overig = New System.Windows.Forms.CheckBox()
        Me.Cmx_Excasso_Select = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Pan_Excasso_preset = New System.Windows.Forms.Panel()
        Me.Rbn_uitkering_budget = New System.Windows.Forms.RadioButton()
        Me.Rbn_uitkering_saldo = New System.Windows.Forms.RadioButton()
        Me.Rbn_uitkering_nul = New System.Windows.Forms.RadioButton()
        Me.Gbx_Excasso_Calculate = New System.Windows.Forms.GroupBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Items_Contract = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Items_Intern = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Intern = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Extra = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Items_Extra = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Totalen = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Tot_Gen = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_CP_Totaal = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Contractwaarde = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Tot_Gen_MLD = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_CP_Totaal_MDL = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Totaal_MDL = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Totaal = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Contract = New System.Windows.Forms.Label()
        Me.Tbx_Excasso_CP1 = New System.Windows.Forms.TextBox()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Tbx_Excasso_Norm1 = New System.Windows.Forms.TextBox()
        Me.Btn_Excasso_CP_Calculate = New System.Windows.Forms.Button()
        Me.Tbx_Excasso_CP2 = New System.Windows.Forms.TextBox()
        Me.Btn_Excasso_Base1 = New System.Windows.Forms.Button()
        Me.Btn_Excasso_Base2 = New System.Windows.Forms.Button()
        Me.Btn_Excasso_Base3 = New System.Windows.Forms.Button()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Items_Totaal = New System.Windows.Forms.Label()
        Me.Lbl_Excasso_Extr = New System.Windows.Forms.Label()
        Me.Label139 = New System.Windows.Forms.Label()
        Me.Tbx_Excasso_Norm3 = New System.Windows.Forms.TextBox()
        Me.Tbx_Excasso_Norm2 = New System.Windows.Forms.TextBox()
        Me.Tbx_Excasso_CP3 = New System.Windows.Forms.TextBox()
        Me.Lbl_Excasso_Internal = New System.Windows.Forms.Label()
        Me.Btn_Excasso_Save = New System.Windows.Forms.Button()
        Me.Btn_Excasso_Print = New System.Windows.Forms.Button()
        Me.Btn_Excasso_Cancel = New System.Windows.Forms.Button()
        Me.Btn_Excasso_Delete = New System.Windows.Forms.Button()
        Me.Incasso = New System.Windows.Forms.TabPage()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Dgv_incasso_totals = New System.Windows.Forms.DataGridView()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Lbl_Incasso_Error = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Rbn_Incasso_Verschillen = New System.Windows.Forms.RadioButton()
        Me.Dtp_Incasso_start = New System.Windows.Forms.DateTimePicker()
        Me.Cmx_Incasso_Bankaccount = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Rbn_Incasso_SEPA = New System.Windows.Forms.RadioButton()
        Me.Label145 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Rbn_Incasso_journal = New System.Windows.Forms.RadioButton()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Lbl_Incasso_Status = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Lbl_Incasso_job_name = New System.Windows.Forms.Label()
        Me.Dtp_Incasso_end = New System.Windows.Forms.DateTimePicker()
        Me.Dgv_Incasso = New System.Windows.Forms.DataGridView()
        Me.Tab_Bank = New System.Windows.Forms.TabPage()
        Me.Pan_Bank2 = New System.Windows.Forms.Panel()
        Me.Dgv_Bank = New System.Windows.Forms.DataGridView()
        Me.Pan_Bank = New System.Windows.Forms.Panel()
        Me.Chbx_Bank_ExtraInfo_achter = New System.Windows.Forms.RadioButton()
        Me.Chbx_Bank_ExtraInfo_voor = New System.Windows.Forms.RadioButton()
        Me.Lbl_Bank_Extra_Info = New System.Windows.Forms.Label()
        Me.Tbx_Bank_Extra_Info = New System.Windows.Forms.TextBox()
        Me.Cmx_Bank_bankacc = New System.Windows.Forms.ComboBox()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Dgv_Bank_Account = New System.Windows.Forms.DataGridView()
        Me.Tbx_Bank_Search = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Dgv_Bank_Account2 = New System.Windows.Forms.DataGridView()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Cmx_Bank_Account = New System.Windows.Forms.ComboBox()
        Me.Btn_Bank_Add_Journal = New System.Windows.Forms.Button()
        Me.Tbx_Bank_Amount = New System.Windows.Forms.TextBox()
        Me.Lbl_Bank_Saldo = New System.Windows.Forms.Label()
        Me.Btn_Bank_Split = New System.Windows.Forms.Button()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Pan_Bank_jtype = New System.Windows.Forms.Panel()
        Me.Label150 = New System.Windows.Forms.Label()
        Me.Rbn_Bank_jtype_con = New System.Windows.Forms.RadioButton()
        Me.Rbn_Bank_jtype_int = New System.Windows.Forms.RadioButton()
        Me.Rbn_Bank_jtype_ext = New System.Windows.Forms.RadioButton()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Lbx_Basis = New System.Windows.Forms.ListBox()
        Me.TC_Object = New System.Windows.Forms.TabControl()
        Me.Contract = New System.Windows.Forms.TabPage()
        Me.Lbl_Rel_id = New System.Windows.Forms.Label()
        Me.Lbl_Contract_tgt = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Lbl_Contract_Bronaccount = New System.Windows.Forms.Label()
        Me.Cmx_00_Contract__fk_account_id = New System.Windows.Forms.ComboBox()
        Me.Tbx_Contract_ttype = New System.Windows.Forms.TextBox()
        Me.Cbx_00_contract__active = New System.Windows.Forms.CheckBox()
        Me.Lbl_contract_mach_datum = New System.Windows.Forms.Label()
        Me.Lbl_contract_macht_kenm = New System.Windows.Forms.Label()
        Me.Pan_Contract_Date_New = New System.Windows.Forms.Panel()
        Me.Dtp_30_Contract_Change = New System.Windows.Forms.DateTimePicker()
        Me.Lbl_contract_new_date = New System.Windows.Forms.Label()
        Me.Lbl_00_contract_doeltype = New System.Windows.Forms.Label()
        Me.Pan_contract_select_target = New System.Windows.Forms.Panel()
        Me.Rbn_00_contract_child = New System.Windows.Forms.RadioButton()
        Me.Rbn_00_contract_elder = New System.Windows.Forms.RadioButton()
        Me.Rbn_00_contract_other = New System.Windows.Forms.RadioButton()
        Me.Lbl_00_contract_autcol = New System.Windows.Forms.Label()
        Me.Pic_Contract_Target_photo = New System.Windows.Forms.PictureBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.dtp_contract_relation_date = New System.Windows.Forms.DateTimePicker()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Lbl_00_Contract__name = New System.Windows.Forms.Label()
        Me.Lbl_Contract_pkid = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Cmx_00_contract__fk_relation_id = New System.Windows.Forms.ComboBox()
        Me.Cmx_01_contract__fk_target_id = New System.Windows.Forms.ComboBox()
        Me.Cmx_02_Contract__term = New System.Windows.Forms.ComboBox()
        Me.Dtp_31_contract__enddate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Dtp_31_contract__startdate = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Tbx_00_contract__description = New System.Windows.Forms.TextBox()
        Me.Chx_00_contract__autcol = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Tbx_11_contract__overhead = New System.Windows.Forms.TextBox()
        Me.Lbl_Basis_Startdatum = New System.Windows.Forms.Label()
        Me.Tbx_contract_period_amt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Tbx_11_Contract__donation = New System.Windows.Forms.TextBox()
        Me.Tbx_01_contract_yeartotal = New System.Windows.Forms.TextBox()
        Me.target = New System.Windows.Forms.TabPage()
        Me.Tbx_20_Target__childnearby = New System.Windows.Forms.TextBox()
        Me.Tbx_20_Target__children = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Rbtn_Target_Alone = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Target_Institution = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Target_OtherHousing = New System.Windows.Forms.RadioButton()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Cmx_01_Target__fk_cp_id = New System.Windows.Forms.ComboBox()
        Me.Pan_Target = New System.Windows.Forms.Panel()
        Me.Rbtn_Target_Child = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Target_Elder = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Target_Other = New System.Windows.Forms.RadioButton()
        Me.Cbx_00_target__active = New System.Windows.Forms.CheckBox()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Lbl_CP = New System.Windows.Forms.Label()
        Me.Lbl_Target_Total_Expenses = New System.Windows.Forms.Label()
        Me.Lbl_Target_NameAdd = New System.Windows.Forms.Label()
        Me.Tbx_00_Target__living = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Target__water = New System.Windows.Forms.TextBox()
        Me.Tbx_01_Target__name_add = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Lbl_Target_Name = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__benefit = New System.Windows.Forms.TextBox()
        Me.Dtp_00_Target__birthday = New System.Windows.Forms.DateTimePicker()
        Me.Lbl_Target_Total_Income = New System.Windows.Forms.Label()
        Me.Tbx_01_Target__name = New System.Windows.Forms.TextBox()
        Me.Lbl_Target_BirthDay = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__otherincome = New System.Windows.Forms.TextBox()
        Me.Tbx_01_Target__ttype = New System.Windows.Forms.TextBox()
        Me.Lbl_Target_Pension = New System.Windows.Forms.Label()
        Me.Lbl_Target_Description = New System.Windows.Forms.Label()
        Me.Lbl_Target_Type = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__pension = New System.Windows.Forms.TextBox()
        Me.Lbl_00_Target__reference = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Lbl_Target_Extra = New System.Windows.Forms.Label()
        Me.Lbl_Target_pkid = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Tbx_00_Target__description = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Target__allowance = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Lbl_Target_Salary = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__income = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Lbl_Target_Income = New System.Windows.Forms.Label()
        Me.Tbx_00_Target__zip = New System.Windows.Forms.TextBox()
        Me.Lbl_Target_Benefit = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Tbx_00_Target__country = New System.Windows.Forms.TextBox()
        Me.Lbl_Target_Otherincome = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__rent = New System.Windows.Forms.TextBox()
        Me.Lbl_Target_Address = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__medicine = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Tbx_00_Target__address = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Tbx_10_Target__food = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Target__heating = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Target__city = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Target__gaselectra = New System.Windows.Forms.TextBox()
        Me.Pic_Target__photo = New System.Windows.Forms.PictureBox()
        Me.Relation = New System.Windows.Forms.TabPage()
        Me.Dgv_relation_giften = New System.Windows.Forms.DataGridView()
        Me.Lbl_Overzicht_Giften = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Tbx_00_Relation__city = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Relation__zip = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Relation__phone = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Relation__address = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Relation__email = New System.Windows.Forms.TextBox()
        Me.Tbx_01_relation__name = New System.Windows.Forms.TextBox()
        Me.Tbx_01_Relation__name_add = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Relation__description = New System.Windows.Forms.TextBox()
        Me.Rbn_Relation_6 = New System.Windows.Forms.RadioButton()
        Me.Rbn_Relation_5 = New System.Windows.Forms.RadioButton()
        Me.Tbx_01_Relation__title = New System.Windows.Forms.TextBox()
        Me.Rbn_Relation_4 = New System.Windows.Forms.RadioButton()
        Me.Rbn_Relation_3 = New System.Windows.Forms.RadioButton()
        Me.Rbn_Relation_2 = New System.Windows.Forms.RadioButton()
        Me.Rbn_Relation_1 = New System.Windows.Forms.RadioButton()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Cbx_00_relation__active = New System.Windows.Forms.CheckBox()
        Me.Dtp_00_relation__date3 = New System.Windows.Forms.DateTimePicker()
        Me.Dtp_00_relation__date2 = New System.Windows.Forms.DateTimePicker()
        Me.Dtp_00_relation__date1 = New System.Windows.Forms.DateTimePicker()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Lbl_00_relation__reference = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Lbl_relation_pkid = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Tbx_00_Relation__iban = New System.Windows.Forms.TextBox()
        Me.CP = New System.Windows.Forms.TabPage()
        Me.Cbx_00_cp__active = New System.Windows.Forms.CheckBox()
        Me.Tbx_00_cp__description = New System.Windows.Forms.TextBox()
        Me.Cmx_01_cp__fk_bankacc_id = New System.Windows.Forms.ComboBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Lbl_CP_pkid = New System.Windows.Forms.Label()
        Me.Tbx_00_CP__telephone = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Tbx_01_CP__name = New System.Windows.Forms.TextBox()
        Me.Tbx_00_CP__zip = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Tbx_00_CP__country = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Tbx_00_CP__email = New System.Windows.Forms.TextBox()
        Me.Tbx_00_CP__address = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Tbx_00_CP__city = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Tbx_01_CP__name_add = New System.Windows.Forms.TextBox()
        Me.Pic_cp__photo = New System.Windows.Forms.PictureBox()
        Me.Account = New System.Windows.Forms.TabPage()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Cmx_01_account__fk_accgroup_id = New System.Windows.Forms.ComboBox()
        Me.Lbl_Account_Doeltype = New System.Windows.Forms.Label()
        Me.Lbl_20_Account__f_key = New System.Windows.Forms.Label()
        Me.Lbl_Account_Budget_Difference = New System.Windows.Forms.Label()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Tbx_10_Account__b_nov = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Account__b_dec = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Account__bankcode = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Account__b_oct = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Account__b_aug = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Account__b_sep = New System.Windows.Forms.TextBox()
        Me.Pan_account = New System.Windows.Forms.Panel()
        Me.Rbtn_Account_Income = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Account_Transit = New System.Windows.Forms.RadioButton()
        Me.Rbtn_Account_Expense = New System.Windows.Forms.RadioButton()
        Me.Tbx_10_Account__b_jul = New System.Windows.Forms.TextBox()
        Me.Cbx_00_Account__active = New System.Windows.Forms.CheckBox()
        Me.Tbx_10_Account__b_may = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Account__b_jun = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Tbx_10_Account__b_apr = New System.Windows.Forms.TextBox()
        Me.Tbx_00_Account__searchword = New System.Windows.Forms.TextBox()
        Me.Tbx_10_Account__b_feb = New System.Windows.Forms.TextBox()
        Me.Lbl_00_pkid = New System.Windows.Forms.Label()
        Me.Tbx_10_Account__b_mar = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Tbx_10_Account__b_jan = New System.Windows.Forms.TextBox()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Tbx_00_Account__description = New System.Windows.Forms.TextBox()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Tbx_01_Account__name = New System.Windows.Forms.TextBox()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Tbx_10_Account__b_year = New System.Windows.Forms.TextBox()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Tbx_00_Account__type = New System.Windows.Forms.TextBox()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Lbl_00_Account__source = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Btn_Account_Budget_All = New System.Windows.Forms.Button()
        Me.Btn_Account_Budget_Id = New System.Windows.Forms.Button()
        Me.Accgroup = New System.Windows.Forms.TabPage()
        Me.Tbx_00_Accgroup__description = New System.Windows.Forms.TextBox()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Tbx_00_Accgroup__subtype = New System.Windows.Forms.TextBox()
        Me.Label137 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Rbtn_accgroup_Income = New System.Windows.Forms.RadioButton()
        Me.Rbtn_accgroup_transit = New System.Windows.Forms.RadioButton()
        Me.Rbtn_accgroup_expense = New System.Windows.Forms.RadioButton()
        Me.Cbx_00_accgroup__active = New System.Windows.Forms.CheckBox()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.Lbl_accgroup_pkid = New System.Windows.Forms.Label()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.Tbx_01_Accgroup__name = New System.Windows.Forms.TextBox()
        Me.Tbx_01_Accgroup__type = New System.Windows.Forms.TextBox()
        Me.BankAcc = New System.Windows.Forms.TabPage()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Cbx_00_BankAcc__active = New System.Windows.Forms.CheckBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Cmx_01_BankAcc__currency = New System.Windows.Forms.ComboBox()
        Me.Tbx_00_BankAcc__bic = New System.Windows.Forms.TextBox()
        Me.Tbx_01_BankAcc__name = New System.Windows.Forms.TextBox()
        Me.Tbx_00_BankAcc__id2 = New System.Windows.Forms.TextBox()
        Me.Lbl_BankAcc_pkid = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Chx_00_BankAcc__expense = New System.Windows.Forms.CheckBox()
        Me.Tbx_01_BankAcc__owner = New System.Windows.Forms.TextBox()
        Me.Cbx_00_BankAcc__income = New System.Windows.Forms.CheckBox()
        Me.Tbx_00_BankAcc__description = New System.Windows.Forms.TextBox()
        Me.Tbx_01_BankAcc__accountno = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Tbx_BankAcc_startbalance = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.TC_Main = New System.Windows.Forms.TabControl()
        Me.Searchbox2 = New System.Windows.Forms.TextBox()
        Me.Zoeken = New System.Windows.Forms.Label()
        Me.Testpanel = New System.Windows.Forms.Panel()
        Me.Cbx_LifeCycle2 = New System.Windows.Forms.ComboBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Tbx_Transactie_totaal = New System.Windows.Forms.TextBox()
        Me.Tbx_Bank_Afschrift = New System.Windows.Forms.TextBox()
        Me.Tbx_Bank_Code = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Tbx_Bank_Relation_account = New System.Windows.Forms.TextBox()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Tbx_Bank_Relation = New System.Windows.Forms.TextBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout
        Me.Instellingen.SuspendLayout
        Me.TC_Management.SuspendLayout
        Me.Settings.SuspendLayout
        CType(Me.Dgv_Settings, System.ComponentModel.ISupportInitialize).BeginInit
        Me.QueryBuilder.SuspendLayout
        CType(Me.Dgv_Query_Test, System.ComponentModel.ISupportInitialize).BeginInit
        Me.TP_Test.SuspendLayout
        Me.Pan_Test.SuspendLayout
        CType(Me.Dgv_Mgnt_Tables, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Tab_Rapportage.SuspendLayout
        Me.Panel13.SuspendLayout
        CType(Me.Dgv_Report_6, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel12.SuspendLayout
        CType(Me.Dgv_Rapportage_Overzicht, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel11.SuspendLayout
        Me.Intern.SuspendLayout
        Me.TC_Boeking.SuspendLayout
        Me.Overboekingen.SuspendLayout
        Me.Panel8.SuspendLayout
        CType(Me.Dgv_Journal_Intern, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel7.SuspendLayout
        Me.Journaalposten.SuspendLayout
        Me.Panel16.SuspendLayout
        CType(Me.Dgv_journaalposten, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Grp_Journaalposten.SuspendLayout
        Me.GRP_journaalposten_edit.SuspendLayout
        Me.Panel2.SuspendLayout
        Me.Accounts.SuspendLayout
        Me.Panel17.SuspendLayout
        Me.Jaarafsluiting.SuspendLayout
        CType(Me.Dgv_Report_Year_Closing, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Uitkering.SuspendLayout
        Me.Panel15.SuspendLayout
        CType(Me.Dgv_Uitkering_Account_Details, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel14.SuspendLayout
        CType(Me.Dgv_Excasso2, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel4.SuspendLayout
        Me.Gbx_Excasso_Doeltype.SuspendLayout
        Me.GroupBox1.SuspendLayout
        Me.Pan_Excasso_preset.SuspendLayout
        Me.Gbx_Excasso_Calculate.SuspendLayout
        Me.GroupBox4.SuspendLayout
        Me.Incasso.SuspendLayout
        Me.Panel3.SuspendLayout
        Me.Panel10.SuspendLayout
        CType(Me.Dgv_incasso_totals, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Panel5.SuspendLayout
        CType(Me.Dgv_Incasso, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Tab_Bank.SuspendLayout
        Me.Pan_Bank2.SuspendLayout
        CType(Me.Dgv_Bank, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Pan_Bank.SuspendLayout
        CType(Me.Dgv_Bank_Account, System.ComponentModel.ISupportInitialize).BeginInit
        CType(Me.Dgv_Bank_Account2, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Pan_Bank_jtype.SuspendLayout
        Me.TabPage1.SuspendLayout
        Me.Panel1.SuspendLayout
        Me.TC_Object.SuspendLayout
        Me.Contract.SuspendLayout
        Me.Pan_Contract_Date_New.SuspendLayout
        Me.Pan_contract_select_target.SuspendLayout
        CType(Me.Pic_Contract_Target_photo, System.ComponentModel.ISupportInitialize).BeginInit
        Me.target.SuspendLayout
        Me.Pan_Target.SuspendLayout
        CType(Me.Pic_Target__photo, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Relation.SuspendLayout
        CType(Me.Dgv_relation_giften, System.ComponentModel.ISupportInitialize).BeginInit
        Me.CP.SuspendLayout
        CType(Me.Pic_cp__photo, System.ComponentModel.ISupportInitialize).BeginInit
        Me.Account.SuspendLayout
        Me.Pan_account.SuspendLayout
        Me.Accgroup.SuspendLayout
        Me.Panel9.SuspendLayout
        Me.BankAcc.SuspendLayout
        Me.TC_Main.SuspendLayout
        Me.Testpanel.SuspendLayout
        Me.Panel6.SuspendLayout
        Me.SuspendLayout
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.MediumAquamarine
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuAdd, Me.MenuSave, Me.MenuCancel, Me.MenuDelete, Me.Menu_Print, Me.Menu_Export, Me.MenuBanktransactie, Me.MenuCategoriseer, Me.MenuUploadAlles, Me.Menu_Back, Me.Menu_Help, Me.ToolStripTextBox1, Me.MenuFilter})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.ShowItemToolTips = True
        Me.MenuStrip1.Size = New System.Drawing.Size(1638, 36)
        Me.MenuStrip1.Stretch = False
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuAdd
        '
        Me.MenuAdd.Image = CType(resources.GetObject("MenuAdd.Image"), System.Drawing.Image)
        Me.MenuAdd.Name = "MenuAdd"
        Me.MenuAdd.Size = New System.Drawing.Size(36, 32)
        '
        'MenuSave
        '
        Me.MenuSave.Enabled = False
        Me.MenuSave.Image = CType(resources.GetObject("MenuSave.Image"), System.Drawing.Image)
        Me.MenuSave.Name = "MenuSave"
        Me.MenuSave.Size = New System.Drawing.Size(36, 32)
        '
        'MenuCancel
        '
        Me.MenuCancel.Enabled = False
        Me.MenuCancel.Image = CType(resources.GetObject("MenuCancel.Image"), System.Drawing.Image)
        Me.MenuCancel.Name = "MenuCancel"
        Me.MenuCancel.Size = New System.Drawing.Size(36, 32)
        '
        'MenuDelete
        '
        Me.MenuDelete.Image = CType(resources.GetObject("MenuDelete.Image"), System.Drawing.Image)
        Me.MenuDelete.Name = "MenuDelete"
        Me.MenuDelete.Size = New System.Drawing.Size(36, 32)
        '
        'Menu_Print
        '
        Me.Menu_Print.Image = CType(resources.GetObject("Menu_Print.Image"), System.Drawing.Image)
        Me.Menu_Print.Name = "Menu_Print"
        Me.Menu_Print.Size = New System.Drawing.Size(36, 24)
        Me.Menu_Print.Visible = False
        '
        'Menu_Export
        '
        Me.Menu_Export.Image = CType(resources.GetObject("Menu_Export.Image"), System.Drawing.Image)
        Me.Menu_Export.Name = "Menu_Export"
        Me.Menu_Export.Size = New System.Drawing.Size(36, 32)
        '
        'MenuBanktransactie
        '
        Me.MenuBanktransactie.Image = CType(resources.GetObject("MenuBanktransactie.Image"), System.Drawing.Image)
        Me.MenuBanktransactie.Name = "MenuBanktransactie"
        Me.MenuBanktransactie.Size = New System.Drawing.Size(36, 32)
        '
        'MenuCategoriseer
        '
        Me.MenuCategoriseer.Image = CType(resources.GetObject("MenuCategoriseer.Image"), System.Drawing.Image)
        Me.MenuCategoriseer.Name = "MenuCategoriseer"
        Me.MenuCategoriseer.Size = New System.Drawing.Size(36, 32)
        '
        'MenuUploadAlles
        '
        Me.MenuUploadAlles.Image = CType(resources.GetObject("MenuUploadAlles.Image"), System.Drawing.Image)
        Me.MenuUploadAlles.Name = "MenuUploadAlles"
        Me.MenuUploadAlles.Size = New System.Drawing.Size(36, 24)
        Me.MenuUploadAlles.Visible = False
        '
        'Menu_Back
        '
        Me.Menu_Back.Image = CType(resources.GetObject("Menu_Back.Image"), System.Drawing.Image)
        Me.Menu_Back.Name = "Menu_Back"
        Me.Menu_Back.Size = New System.Drawing.Size(36, 24)
        Me.Menu_Back.Visible = False
        '
        'Menu_Help
        '
        Me.Menu_Help.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Menu_Help.Image = CType(resources.GetObject("Menu_Help.Image"), System.Drawing.Image)
        Me.Menu_Help.Name = "Menu_Help"
        Me.Menu_Help.Size = New System.Drawing.Size(36, 32)
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripTextBox1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.ToolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ToolStripTextBox1.Enabled = False
        Me.ToolStripTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(68, 32)
        Me.ToolStripTextBox1.Text = "Status "
        Me.ToolStripTextBox1.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'MenuFilter
        '
        Me.MenuFilter.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.MenuFilter.Image = CType(resources.GetObject("MenuFilter.Image"), System.Drawing.Image)
        Me.MenuFilter.Name = "MenuFilter"
        Me.MenuFilter.Size = New System.Drawing.Size(36, 32)
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "pdf"
        Me.SaveFileDialog1.Title = "Kies locatie pdf-bestand"
        '
        'ToolTip1
        '
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Werner\Dropbox\0-HOET\Hulpbestanden\SPAS_help.chm"
        '
        'Tbx_Bank_Description
        '
        Me.Tbx_Bank_Description.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Bank_Description.Enabled = False
        Me.Tbx_Bank_Description.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Bank_Description.ForeColor = System.Drawing.Color.Blue
        Me.HelpProvider1.SetHelpKeyword(Me.Tbx_Bank_Description, "Bankomschrijving")
        Me.HelpProvider1.SetHelpNavigator(Me.Tbx_Bank_Description, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.HelpProvider1.SetHelpString(Me.Tbx_Bank_Description, "Hulp bij omschrijving")
        Me.Tbx_Bank_Description.Location = New System.Drawing.Point(5, 341)
        Me.Tbx_Bank_Description.Multiline = True
        Me.Tbx_Bank_Description.Name = "Tbx_Bank_Description"
        Me.Tbx_Bank_Description.ReadOnly = True
        Me.Tbx_Bank_Description.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.HelpProvider1.SetShowHelp(Me.Tbx_Bank_Description, True)
        Me.Tbx_Bank_Description.Size = New System.Drawing.Size(444, 83)
        Me.Tbx_Bank_Description.TabIndex = 15
        '
        'Instellingen
        '
        Me.Instellingen.BackColor = System.Drawing.Color.Transparent
        Me.Instellingen.Controls.Add(Me.TC_Management)
        Me.Instellingen.Location = New System.Drawing.Point(4, 38)
        Me.Instellingen.Name = "Instellingen"
        Me.Instellingen.Padding = New System.Windows.Forms.Padding(3)
        Me.Instellingen.Size = New System.Drawing.Size(1618, 889)
        Me.Instellingen.TabIndex = 6
        Me.Instellingen.Text = "Beheer   "
        '
        'TC_Management
        '
        Me.TC_Management.Controls.Add(Me.Settings)
        Me.TC_Management.Controls.Add(Me.AVG)
        Me.TC_Management.Controls.Add(Me.QueryBuilder)
        Me.TC_Management.Controls.Add(Me.TP_Test)
        Me.TC_Management.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TC_Management.Location = New System.Drawing.Point(12, 8)
        Me.TC_Management.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TC_Management.Name = "TC_Management"
        Me.TC_Management.SelectedIndex = 0
        Me.TC_Management.Size = New System.Drawing.Size(1516, 860)
        Me.TC_Management.TabIndex = 5
        '
        'Settings
        '
        Me.Settings.Controls.Add(Me.Dgv_Settings)
        Me.Settings.Location = New System.Drawing.Point(4, 38)
        Me.Settings.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Settings.Name = "Settings"
        Me.Settings.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Settings.Size = New System.Drawing.Size(1508, 818)
        Me.Settings.TabIndex = 0
        Me.Settings.Text = "Settings"
        Me.Settings.UseVisualStyleBackColor = True
        '
        'Dgv_Settings
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Settings.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_Settings.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Dgv_Settings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Settings.Location = New System.Drawing.Point(9, -12)
        Me.Dgv_Settings.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_Settings.Name = "Dgv_Settings"
        Me.Dgv_Settings.RowHeadersVisible = False
        Me.Dgv_Settings.RowHeadersWidth = 82
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Settings.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv_Settings.RowTemplate.Height = 20
        Me.Dgv_Settings.Size = New System.Drawing.Size(1486, 792)
        Me.Dgv_Settings.TabIndex = 5
        '
        'AVG
        '
        Me.AVG.Location = New System.Drawing.Point(4, 38)
        Me.AVG.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.AVG.Name = "AVG"
        Me.AVG.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.AVG.Size = New System.Drawing.Size(1508, 818)
        Me.AVG.TabIndex = 1
        Me.AVG.Text = "AVG"
        Me.AVG.UseVisualStyleBackColor = True
        '
        'QueryBuilder
        '
        Me.QueryBuilder.Controls.Add(Me.Button1)
        Me.QueryBuilder.Controls.Add(Me.Btn_Query_Test)
        Me.QueryBuilder.Controls.Add(Me.Tbx_Query_SQL)
        Me.QueryBuilder.Controls.Add(Me.Label117)
        Me.QueryBuilder.Controls.Add(Me.Tbx_Query_Formattering)
        Me.QueryBuilder.Controls.Add(Me.Label116)
        Me.QueryBuilder.Controls.Add(Me.Tbx_Query_Naam)
        Me.QueryBuilder.Controls.Add(Me.Label108)
        Me.QueryBuilder.Controls.Add(Me.RadioButton2)
        Me.QueryBuilder.Controls.Add(Me.RadioButton1)
        Me.QueryBuilder.Controls.Add(Me.Label102)
        Me.QueryBuilder.Controls.Add(Me.Label97)
        Me.QueryBuilder.Controls.Add(Me.Cmbx_Query_Select)
        Me.QueryBuilder.Controls.Add(Me.Dgv_Query_Test)
        Me.QueryBuilder.Location = New System.Drawing.Point(4, 38)
        Me.QueryBuilder.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QueryBuilder.Name = "QueryBuilder"
        Me.QueryBuilder.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.QueryBuilder.Size = New System.Drawing.Size(1508, 818)
        Me.QueryBuilder.TabIndex = 2
        Me.QueryBuilder.Text = "QueryBuilder"
        Me.QueryBuilder.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(78, 246)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(190, 52)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "Verwijder maand"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Btn_Query_Test
        '
        Me.Btn_Query_Test.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Query_Test.Location = New System.Drawing.Point(570, 78)
        Me.Btn_Query_Test.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Query_Test.Name = "Btn_Query_Test"
        Me.Btn_Query_Test.Size = New System.Drawing.Size(112, 35)
        Me.Btn_Query_Test.TabIndex = 30
        Me.Btn_Query_Test.Text = "Test"
        Me.Btn_Query_Test.UseVisualStyleBackColor = True
        '
        'Tbx_Query_SQL
        '
        Me.Tbx_Query_SQL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tbx_Query_SQL.Font = New System.Drawing.Font("Gill Sans MT", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Query_SQL.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Tbx_Query_SQL.Location = New System.Drawing.Point(692, 25)
        Me.Tbx_Query_SQL.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Query_SQL.Multiline = True
        Me.Tbx_Query_SQL.Name = "Tbx_Query_SQL"
        Me.Tbx_Query_SQL.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_Query_SQL.Size = New System.Drawing.Size(773, 311)
        Me.Tbx_Query_SQL.TabIndex = 29
        Me.Tbx_Query_SQL.Text = "select * from table"
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.Location = New System.Drawing.Point(600, 29)
        Me.Label117.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(68, 28)
        Me.Label117.TabIndex = 28
        Me.Label117.Text = "Query"
        '
        'Tbx_Query_Formattering
        '
        Me.Tbx_Query_Formattering.AccessibleRole = System.Windows.Forms.AccessibleRole.Chart
        Me.Tbx_Query_Formattering.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Query_Formattering.Location = New System.Drawing.Point(159, 166)
        Me.Tbx_Query_Formattering.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Query_Formattering.Name = "Tbx_Query_Formattering"
        Me.Tbx_Query_Formattering.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_Query_Formattering.TabIndex = 27
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.Location = New System.Drawing.Point(18, 171)
        Me.Label116.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(134, 28)
        Me.Label116.TabIndex = 26
        Me.Label116.Text = "Formattering"
        '
        'Tbx_Query_Naam
        '
        Me.Tbx_Query_Naam.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Query_Naam.Location = New System.Drawing.Point(156, 74)
        Me.Tbx_Query_Naam.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Query_Naam.Name = "Tbx_Query_Naam"
        Me.Tbx_Query_Naam.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_Query_Naam.TabIndex = 25
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.Location = New System.Drawing.Point(20, 78)
        Me.Label108.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(67, 28)
        Me.Label108.TabIndex = 24
        Me.Label108.Text = "Naam"
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton2.Location = New System.Drawing.Point(324, 123)
        Me.RadioButton2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(92, 32)
        Me.RadioButton2.TabIndex = 23
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Check"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton1.Location = New System.Drawing.Point(159, 123)
        Me.RadioButton1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(125, 32)
        Me.RadioButton1.TabIndex = 22
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Overzicht"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.Location = New System.Drawing.Point(20, 126)
        Me.Label102.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(55, 28)
        Me.Label102.TabIndex = 21
        Me.Label102.Text = "Type"
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.Location = New System.Drawing.Point(20, 32)
        Me.Label97.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(68, 28)
        Me.Label97.TabIndex = 20
        Me.Label97.Text = "Query"
        '
        'Cmbx_Query_Select
        '
        Me.Cmbx_Query_Select.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmbx_Query_Select.FormattingEnabled = True
        Me.Cmbx_Query_Select.Location = New System.Drawing.Point(156, 25)
        Me.Cmbx_Query_Select.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbx_Query_Select.Name = "Cmbx_Query_Select"
        Me.Cmbx_Query_Select.Size = New System.Drawing.Size(388, 36)
        Me.Cmbx_Query_Select.TabIndex = 19
        '
        'Dgv_Query_Test
        '
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Query_Test.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgv_Query_Test.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Query_Test.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Query_Test.Location = New System.Drawing.Point(24, 346)
        Me.Dgv_Query_Test.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_Query_Test.Name = "Dgv_Query_Test"
        Me.Dgv_Query_Test.RowHeadersVisible = False
        Me.Dgv_Query_Test.RowHeadersWidth = 82
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Query_Test.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgv_Query_Test.RowTemplate.Height = 20
        Me.Dgv_Query_Test.Size = New System.Drawing.Size(1472, 412)
        Me.Dgv_Query_Test.TabIndex = 18
        '
        'TP_Test
        '
        Me.TP_Test.Controls.Add(Me.TreeView1)
        Me.TP_Test.Controls.Add(Me.Button5)
        Me.TP_Test.Controls.Add(Me.Button2)
        Me.TP_Test.Controls.Add(Me.Pan_Test)
        Me.TP_Test.Controls.Add(Me.Dgv_Mgnt_Tables)
        Me.TP_Test.Location = New System.Drawing.Point(4, 38)
        Me.TP_Test.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TP_Test.Name = "TP_Test"
        Me.TP_Test.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TP_Test.Size = New System.Drawing.Size(1508, 818)
        Me.TP_Test.TabIndex = 3
        Me.TP_Test.Text = "Test"
        Me.TP_Test.UseVisualStyleBackColor = True
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(914, 52)
        Me.TreeView1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Size = New System.Drawing.Size(468, 549)
        Me.TreeView1.TabIndex = 43
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(960, 698)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(348, 60)
        Me.Button5.TabIndex = 42
        Me.Button5.Text = "populate tree"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(405, 472)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(177, 65)
        Me.Button2.TabIndex = 41
        Me.Button2.Text = "test"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Pan_Test
        '
        Me.Pan_Test.Controls.Add(Me.Button3)
        Me.Pan_Test.Controls.Add(Me.Button4)
        Me.Pan_Test.Controls.Add(Me.Chbx_test)
        Me.Pan_Test.Font = New System.Drawing.Font("Calibri Light", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pan_Test.Location = New System.Drawing.Point(302, 603)
        Me.Pan_Test.Name = "Pan_Test"
        Me.Pan_Test.Size = New System.Drawing.Size(410, 132)
        Me.Pan_Test.TabIndex = 40
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(234, 62)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(150, 48)
        Me.Button3.TabIndex = 32
        Me.Button3.Text = "Verwijder maand"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(76, 0)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(50, 31)
        Me.Button4.TabIndex = 2
        Me.Button4.Text = "test"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Chbx_test
        '
        Me.Chbx_test.AutoSize = True
        Me.Chbx_test.Location = New System.Drawing.Point(0, 5)
        Me.Chbx_test.Name = "Chbx_test"
        Me.Chbx_test.Size = New System.Drawing.Size(65, 26)
        Me.Chbx_test.TabIndex = 3
        Me.Chbx_test.Text = "Test"
        Me.Chbx_test.UseVisualStyleBackColor = True
        '
        'Dgv_Mgnt_Tables
        '
        Me.Dgv_Mgnt_Tables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Mgnt_Tables.Location = New System.Drawing.Point(9, 9)
        Me.Dgv_Mgnt_Tables.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_Mgnt_Tables.Name = "Dgv_Mgnt_Tables"
        Me.Dgv_Mgnt_Tables.ReadOnly = True
        Me.Dgv_Mgnt_Tables.RowHeadersWidth = 82
        Me.Dgv_Mgnt_Tables.Size = New System.Drawing.Size(300, 351)
        Me.Dgv_Mgnt_Tables.TabIndex = 39
        '
        'Tab_Rapportage
        '
        Me.Tab_Rapportage.Controls.Add(Me.Splitter1)
        Me.Tab_Rapportage.Controls.Add(Me.Splitter_left)
        Me.Tab_Rapportage.Controls.Add(Me.Panel13)
        Me.Tab_Rapportage.Controls.Add(Me.Panel12)
        Me.Tab_Rapportage.Controls.Add(Me.Panel11)
        Me.Tab_Rapportage.Location = New System.Drawing.Point(4, 38)
        Me.Tab_Rapportage.Name = "Tab_Rapportage"
        Me.Tab_Rapportage.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Rapportage.Size = New System.Drawing.Size(1618, 889)
        Me.Tab_Rapportage.TabIndex = 5
        Me.Tab_Rapportage.Text = "Rapportage "
        Me.Tab_Rapportage.UseVisualStyleBackColor = True
        '
        'Splitter1
        '
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Splitter1.Location = New System.Drawing.Point(301, 560)
        Me.Splitter1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(1314, 15)
        Me.Splitter1.TabIndex = 96
        Me.Splitter1.TabStop = False
        '
        'Splitter_left
        '
        Me.Splitter_left.Location = New System.Drawing.Point(297, 560)
        Me.Splitter_left.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Splitter_left.Name = "Splitter_left"
        Me.Splitter_left.Size = New System.Drawing.Size(4, 326)
        Me.Splitter_left.TabIndex = 95
        Me.Splitter_left.TabStop = False
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Lbl_Rapportage_Detail)
        Me.Panel13.Controls.Add(Me.Dgv_Report_6)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel13.Location = New System.Drawing.Point(297, 560)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(1318, 326)
        Me.Panel13.TabIndex = 94
        '
        'Lbl_Rapportage_Detail
        '
        Me.Lbl_Rapportage_Detail.AutoSize = True
        Me.Lbl_Rapportage_Detail.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Rapportage_Detail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lbl_Rapportage_Detail.Location = New System.Drawing.Point(4, 20)
        Me.Lbl_Rapportage_Detail.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Rapportage_Detail.Name = "Lbl_Rapportage_Detail"
        Me.Lbl_Rapportage_Detail.Size = New System.Drawing.Size(82, 29)
        Me.Lbl_Rapportage_Detail.TabIndex = 91
        Me.Lbl_Rapportage_Detail.Text = "Details"
        '
        'Dgv_Report_6
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.LemonChiffon
        Me.Dgv_Report_6.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgv_Report_6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Report_6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Report_6.Location = New System.Drawing.Point(9, 54)
        Me.Dgv_Report_6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_Report_6.Name = "Dgv_Report_6"
        Me.Dgv_Report_6.RowHeadersVisible = False
        Me.Dgv_Report_6.RowHeadersWidth = 82
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Report_6.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgv_Report_6.RowTemplate.Height = 20
        Me.Dgv_Report_6.Size = New System.Drawing.Size(1300, 268)
        Me.Dgv_Report_6.TabIndex = 90
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.Lbl_Rapportage)
        Me.Panel12.Controls.Add(Me.Dgv_Rapportage_Overzicht)
        Me.Panel12.Controls.Add(Me.LbL_Formatting)
        Me.Panel12.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel12.Location = New System.Drawing.Point(297, 3)
        Me.Panel12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(1318, 557)
        Me.Panel12.TabIndex = 0
        '
        'Lbl_Rapportage
        '
        Me.Lbl_Rapportage.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Rapportage.Location = New System.Drawing.Point(4, 0)
        Me.Lbl_Rapportage.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Rapportage.Name = "Lbl_Rapportage"
        Me.Lbl_Rapportage.Size = New System.Drawing.Size(496, 35)
        Me.Lbl_Rapportage.TabIndex = 89
        '
        'Dgv_Rapportage_Overzicht
        '
        Me.Dgv_Rapportage_Overzicht.AllowUserToAddRows = False
        Me.Dgv_Rapportage_Overzicht.AllowUserToDeleteRows = False
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Rapportage_Overzicht.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle7
        Me.Dgv_Rapportage_Overzicht.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Rapportage_Overzicht.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv_Rapportage_Overzicht.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Rapportage_Overzicht.Location = New System.Drawing.Point(8, 38)
        Me.Dgv_Rapportage_Overzicht.Name = "Dgv_Rapportage_Overzicht"
        Me.Dgv_Rapportage_Overzicht.RowHeadersVisible = False
        Me.Dgv_Rapportage_Overzicht.RowHeadersWidth = 50
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Rapportage_Overzicht.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.Dgv_Rapportage_Overzicht.RowTemplate.Height = 20
        Me.Dgv_Rapportage_Overzicht.Size = New System.Drawing.Size(1300, 511)
        Me.Dgv_Rapportage_Overzicht.TabIndex = 76
        '
        'LbL_Formatting
        '
        Me.LbL_Formatting.AutoSize = True
        Me.LbL_Formatting.Location = New System.Drawing.Point(1018, 2)
        Me.LbL_Formatting.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbL_Formatting.Name = "LbL_Formatting"
        Me.LbL_Formatting.Size = New System.Drawing.Size(102, 29)
        Me.LbL_Formatting.TabIndex = 88
        Me.LbL_Formatting.Text = "Label148"
        Me.LbL_Formatting.Visible = False
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.ReportTree)
        Me.Panel11.Controls.Add(Me.Label119)
        Me.Panel11.Controls.Add(Me.Btn_Rap_Expand_Collapse)
        Me.Panel11.Controls.Add(Me.Cmbx_Reporting_Year)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel11.Location = New System.Drawing.Point(3, 3)
        Me.Panel11.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(294, 883)
        Me.Panel11.TabIndex = 91
        '
        'ReportTree
        '
        Me.ReportTree.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ReportTree.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReportTree.Location = New System.Drawing.Point(4, 40)
        Me.ReportTree.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ReportTree.Name = "ReportTree"
        Me.ReportTree.Size = New System.Drawing.Size(283, 789)
        Me.ReportTree.TabIndex = 83
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Location = New System.Drawing.Point(4, 6)
        Me.Label119.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(169, 29)
        Me.Label119.TabIndex = 87
        Me.Label119.Text = "Rapportagejaar"
        '
        'Btn_Rap_Expand_Collapse
        '
        Me.Btn_Rap_Expand_Collapse.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_Rap_Expand_Collapse.Location = New System.Drawing.Point(4, 840)
        Me.Btn_Rap_Expand_Collapse.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Rap_Expand_Collapse.Name = "Btn_Rap_Expand_Collapse"
        Me.Btn_Rap_Expand_Collapse.Size = New System.Drawing.Size(294, 43)
        Me.Btn_Rap_Expand_Collapse.TabIndex = 84
        Me.Btn_Rap_Expand_Collapse.Text = "Alles uitklappen"
        Me.Btn_Rap_Expand_Collapse.UseVisualStyleBackColor = True
        '
        'Cmbx_Reporting_Year
        '
        Me.Cmbx_Reporting_Year.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmbx_Reporting_Year.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmbx_Reporting_Year.FormattingEnabled = True
        Me.Cmbx_Reporting_Year.Location = New System.Drawing.Point(171, 3)
        Me.Cmbx_Reporting_Year.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbx_Reporting_Year.Name = "Cmbx_Reporting_Year"
        Me.Cmbx_Reporting_Year.Size = New System.Drawing.Size(116, 36)
        Me.Cmbx_Reporting_Year.TabIndex = 86
        '
        'Intern
        '
        Me.Intern.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Intern.Controls.Add(Me.TC_Boeking)
        Me.Intern.Location = New System.Drawing.Point(4, 38)
        Me.Intern.Name = "Intern"
        Me.Intern.Padding = New System.Windows.Forms.Padding(3)
        Me.Intern.Size = New System.Drawing.Size(1618, 889)
        Me.Intern.TabIndex = 4
        Me.Intern.Text = "Boekingen"
        '
        'TC_Boeking
        '
        Me.TC_Boeking.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TC_Boeking.Controls.Add(Me.Overboekingen)
        Me.TC_Boeking.Controls.Add(Me.Journaalposten)
        Me.TC_Boeking.Controls.Add(Me.Accounts)
        Me.TC_Boeking.Controls.Add(Me.Jaarafsluiting)
        Me.TC_Boeking.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TC_Boeking.Location = New System.Drawing.Point(3, 6)
        Me.TC_Boeking.Name = "TC_Boeking"
        Me.TC_Boeking.SelectedIndex = 0
        Me.TC_Boeking.Size = New System.Drawing.Size(1612, 877)
        Me.TC_Boeking.TabIndex = 136
        '
        'Overboekingen
        '
        Me.Overboekingen.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Overboekingen.Controls.Add(Me.Panel8)
        Me.Overboekingen.Controls.Add(Me.Panel7)
        Me.Overboekingen.Location = New System.Drawing.Point(4, 38)
        Me.Overboekingen.Name = "Overboekingen"
        Me.Overboekingen.Padding = New System.Windows.Forms.Padding(3)
        Me.Overboekingen.Size = New System.Drawing.Size(1604, 835)
        Me.Overboekingen.TabIndex = 1
        Me.Overboekingen.Text = "Overboekingen"
        '
        'Panel8
        '
        Me.Panel8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel8.Controls.Add(Me.Rbtn_Overboekingen_alles)
        Me.Panel8.Controls.Add(Me.Rbtn_Overboekingen_Oudere)
        Me.Panel8.Controls.Add(Me.Rbtn_Overboekingen_Kind)
        Me.Panel8.Controls.Add(Me.Cmbx_Overboeking_Target)
        Me.Panel8.Controls.Add(Me.Rbn_Journal_Extra)
        Me.Panel8.Controls.Add(Me.Tbx_Journal_Name)
        Me.Panel8.Controls.Add(Me.Label126)
        Me.Panel8.Controls.Add(Me.Rbn_Journal_Contract)
        Me.Panel8.Controls.Add(Me.Rbn_Journal_Intern)
        Me.Panel8.Controls.Add(Me.Label54)
        Me.Panel8.Controls.Add(Me.Btn_Journal_Intern_Save)
        Me.Panel8.Controls.Add(Me.Btn_Journal_Recalculate)
        Me.Panel8.Controls.Add(Me.Btn_Journals_Cancel)
        Me.Panel8.Controls.Add(Me.Label121)
        Me.Panel8.Controls.Add(Me.Dtp_Journal_intern)
        Me.Panel8.Controls.Add(Me.Dgv_Journal_Intern)
        Me.Panel8.Controls.Add(Me.Label128)
        Me.Panel8.Controls.Add(Me.Label125)
        Me.Panel8.Controls.Add(Me.Tbx_Journal_Description)
        Me.Panel8.Location = New System.Drawing.Point(15, 97)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(1459, 696)
        Me.Panel8.TabIndex = 50
        '
        'Rbtn_Overboekingen_alles
        '
        Me.Rbtn_Overboekingen_alles.AutoSize = True
        Me.Rbtn_Overboekingen_alles.Checked = True
        Me.Rbtn_Overboekingen_alles.Location = New System.Drawing.Point(453, 58)
        Me.Rbtn_Overboekingen_alles.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Overboekingen_alles.Name = "Rbtn_Overboekingen_alles"
        Me.Rbtn_Overboekingen_alles.Size = New System.Drawing.Size(85, 33)
        Me.Rbtn_Overboekingen_alles.TabIndex = 141
        Me.Rbtn_Overboekingen_alles.TabStop = True
        Me.Rbtn_Overboekingen_alles.Text = "Alles"
        Me.Rbtn_Overboekingen_alles.UseVisualStyleBackColor = True
        '
        'Rbtn_Overboekingen_Oudere
        '
        Me.Rbtn_Overboekingen_Oudere.AutoSize = True
        Me.Rbtn_Overboekingen_Oudere.Location = New System.Drawing.Point(320, 58)
        Me.Rbtn_Overboekingen_Oudere.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Overboekingen_Oudere.Name = "Rbtn_Overboekingen_Oudere"
        Me.Rbtn_Overboekingen_Oudere.Size = New System.Drawing.Size(125, 33)
        Me.Rbtn_Overboekingen_Oudere.TabIndex = 140
        Me.Rbtn_Overboekingen_Oudere.Text = "Ouderen"
        Me.Rbtn_Overboekingen_Oudere.UseVisualStyleBackColor = True
        '
        'Rbtn_Overboekingen_Kind
        '
        Me.Rbtn_Overboekingen_Kind.AutoSize = True
        Me.Rbtn_Overboekingen_Kind.Location = New System.Drawing.Point(186, 58)
        Me.Rbtn_Overboekingen_Kind.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Overboekingen_Kind.Name = "Rbtn_Overboekingen_Kind"
        Me.Rbtn_Overboekingen_Kind.Size = New System.Drawing.Size(127, 33)
        Me.Rbtn_Overboekingen_Kind.TabIndex = 139
        Me.Rbtn_Overboekingen_Kind.Text = "Kinderen"
        Me.Rbtn_Overboekingen_Kind.UseVisualStyleBackColor = True
        '
        'Cmbx_Overboeking_Target
        '
        Me.Cmbx_Overboeking_Target.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cmbx_Overboeking_Target.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cmbx_Overboeking_Target.FormattingEnabled = True
        Me.Cmbx_Overboeking_Target.Location = New System.Drawing.Point(186, 11)
        Me.Cmbx_Overboeking_Target.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbx_Overboeking_Target.Name = "Cmbx_Overboeking_Target"
        Me.Cmbx_Overboeking_Target.Size = New System.Drawing.Size(354, 37)
        Me.Cmbx_Overboeking_Target.TabIndex = 133
        '
        'Rbn_Journal_Extra
        '
        Me.Rbn_Journal_Extra.AutoSize = True
        Me.Rbn_Journal_Extra.Location = New System.Drawing.Point(928, 118)
        Me.Rbn_Journal_Extra.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Journal_Extra.Name = "Rbn_Journal_Extra"
        Me.Rbn_Journal_Extra.Size = New System.Drawing.Size(183, 33)
        Me.Rbn_Journal_Extra.TabIndex = 138
        Me.Rbn_Journal_Extra.Text = "Extra gift (corr)"
        Me.Rbn_Journal_Extra.UseVisualStyleBackColor = True
        '
        'Tbx_Journal_Name
        '
        Me.Tbx_Journal_Name.Location = New System.Drawing.Point(690, 208)
        Me.Tbx_Journal_Name.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Journal_Name.Name = "Tbx_Journal_Name"
        Me.Tbx_Journal_Name.Size = New System.Drawing.Size(484, 37)
        Me.Tbx_Journal_Name.TabIndex = 137
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label126.Location = New System.Drawing.Point(548, 223)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(51, 27)
        Me.Label126.TabIndex = 136
        Me.Label126.Text = "Titel"
        '
        'Rbn_Journal_Contract
        '
        Me.Rbn_Journal_Contract.AutoSize = True
        Me.Rbn_Journal_Contract.Location = New System.Drawing.Point(796, 118)
        Me.Rbn_Journal_Contract.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Journal_Contract.Name = "Rbn_Journal_Contract"
        Me.Rbn_Journal_Contract.Size = New System.Drawing.Size(123, 33)
        Me.Rbn_Journal_Contract.TabIndex = 135
        Me.Rbn_Journal_Contract.Text = "Contract"
        Me.Rbn_Journal_Contract.UseVisualStyleBackColor = True
        '
        'Rbn_Journal_Intern
        '
        Me.Rbn_Journal_Intern.AutoSize = True
        Me.Rbn_Journal_Intern.Location = New System.Drawing.Point(690, 118)
        Me.Rbn_Journal_Intern.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Journal_Intern.Name = "Rbn_Journal_Intern"
        Me.Rbn_Journal_Intern.Size = New System.Drawing.Size(98, 33)
        Me.Rbn_Journal_Intern.TabIndex = 134
        Me.Rbn_Journal_Intern.Text = "Intern"
        Me.Rbn_Journal_Intern.UseVisualStyleBackColor = True
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.Location = New System.Drawing.Point(548, 125)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(132, 27)
        Me.Label54.TabIndex = 133
        Me.Label54.Text = "Boekingsoort"
        '
        'Btn_Journal_Intern_Save
        '
        Me.Btn_Journal_Intern_Save.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Btn_Journal_Intern_Save.Image = CType(resources.GetObject("Btn_Journal_Intern_Save.Image"), System.Drawing.Image)
        Me.Btn_Journal_Intern_Save.Location = New System.Drawing.Point(1238, 5)
        Me.Btn_Journal_Intern_Save.Name = "Btn_Journal_Intern_Save"
        Me.Btn_Journal_Intern_Save.Size = New System.Drawing.Size(46, 49)
        Me.Btn_Journal_Intern_Save.TabIndex = 46
        Me.Btn_Journal_Intern_Save.UseVisualStyleBackColor = True
        Me.Btn_Journal_Intern_Save.Visible = False
        '
        'Btn_Journal_Recalculate
        '
        Me.Btn_Journal_Recalculate.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Btn_Journal_Recalculate.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Journal_Recalculate.Image = CType(resources.GetObject("Btn_Journal_Recalculate.Image"), System.Drawing.Image)
        Me.Btn_Journal_Recalculate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btn_Journal_Recalculate.Location = New System.Drawing.Point(690, 66)
        Me.Btn_Journal_Recalculate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Journal_Recalculate.Name = "Btn_Journal_Recalculate"
        Me.Btn_Journal_Recalculate.Size = New System.Drawing.Size(474, 54)
        Me.Btn_Journal_Recalculate.TabIndex = 131
        Me.Btn_Journal_Recalculate.Text = "Verdeel bedrag  gelijkelijk over alle doelen"
        Me.Btn_Journal_Recalculate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btn_Journal_Recalculate.UseVisualStyleBackColor = True
        '
        'Btn_Journals_Cancel
        '
        Me.Btn_Journals_Cancel.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Btn_Journals_Cancel.Image = CType(resources.GetObject("Btn_Journals_Cancel.Image"), System.Drawing.Image)
        Me.Btn_Journals_Cancel.Location = New System.Drawing.Point(1287, 5)
        Me.Btn_Journals_Cancel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Journals_Cancel.Name = "Btn_Journals_Cancel"
        Me.Btn_Journals_Cancel.Size = New System.Drawing.Size(46, 49)
        Me.Btn_Journals_Cancel.TabIndex = 43
        Me.Btn_Journals_Cancel.UseVisualStyleBackColor = True
        Me.Btn_Journals_Cancel.Visible = False
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label121.Location = New System.Drawing.Point(16, 18)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(150, 27)
        Me.Label121.TabIndex = 129
        Me.Label121.Text = "Doelaccount(s)"
        '
        'Dtp_Journal_intern
        '
        Me.Dtp_Journal_intern.CalendarFont = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Journal_intern.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Journal_intern.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_Journal_intern.Location = New System.Drawing.Point(690, 162)
        Me.Dtp_Journal_intern.Name = "Dtp_Journal_intern"
        Me.Dtp_Journal_intern.Size = New System.Drawing.Size(163, 34)
        Me.Dtp_Journal_intern.TabIndex = 124
        Me.Dtp_Journal_intern.Value = New Date(2020, 7, 4, 0, 0, 0, 0)
        '
        'Dgv_Journal_Intern
        '
        Me.Dgv_Journal_Intern.AllowUserToAddRows = False
        Me.Dgv_Journal_Intern.AllowUserToDeleteRows = False
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Journal_Intern.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle9
        Me.Dgv_Journal_Intern.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Journal_Intern.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv_Journal_Intern.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Journal_Intern.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id1, Me.Accnt, Me.Amt1})
        Me.Dgv_Journal_Intern.Location = New System.Drawing.Point(186, 102)
        Me.Dgv_Journal_Intern.Name = "Dgv_Journal_Intern"
        Me.Dgv_Journal_Intern.RowHeadersVisible = False
        Me.Dgv_Journal_Intern.RowHeadersWidth = 50
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Journal_Intern.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.Dgv_Journal_Intern.RowTemplate.Height = 20
        Me.Dgv_Journal_Intern.Size = New System.Drawing.Size(354, 552)
        Me.Dgv_Journal_Intern.TabIndex = 45
        '
        'id1
        '
        Me.id1.HeaderText = "Id"
        Me.id1.MinimumWidth = 10
        Me.id1.Name = "id1"
        Me.id1.Width = 200
        '
        'Accnt
        '
        Me.Accnt.HeaderText = "Account"
        Me.Accnt.MinimumWidth = 10
        Me.Accnt.Name = "Accnt"
        Me.Accnt.Width = 200
        '
        'Amt1
        '
        Me.Amt1.HeaderText = "Bedrag"
        Me.Amt1.MinimumWidth = 10
        Me.Amt1.Name = "Amt1"
        Me.Amt1.Width = 200
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label128.Location = New System.Drawing.Point(548, 178)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(74, 27)
        Me.Label128.TabIndex = 124
        Me.Label128.Text = "Datum"
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.Location = New System.Drawing.Point(548, 268)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(109, 27)
        Me.Label125.TabIndex = 52
        Me.Label125.Text = "Toelichting"
        '
        'Tbx_Journal_Description
        '
        Me.Tbx_Journal_Description.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Tbx_Journal_Description.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Journal_Description.Location = New System.Drawing.Point(690, 260)
        Me.Tbx_Journal_Description.Multiline = True
        Me.Tbx_Journal_Description.Name = "Tbx_Journal_Description"
        Me.Tbx_Journal_Description.Size = New System.Drawing.Size(694, 270)
        Me.Tbx_Journal_Description.TabIndex = 52
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel7.Controls.Add(Me.Cmbx_Overboeking_Bron)
        Me.Panel7.Controls.Add(Me.Label26)
        Me.Panel7.Controls.Add(Me.Label95)
        Me.Panel7.Controls.Add(Me.Lbl_Journal_Source_Name)
        Me.Panel7.Controls.Add(Me.Tbx_Journal_Source_Amt)
        Me.Panel7.Controls.Add(Me.Lbl_Journal_Source_Saldo)
        Me.Panel7.Controls.Add(Me.Lbl_Journal_Source_Restamt)
        Me.Panel7.Controls.Add(Me.Lbl_Journal_Source_id)
        Me.Panel7.Controls.Add(Me.Label129)
        Me.Panel7.Location = New System.Drawing.Point(15, 12)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(1459, 76)
        Me.Panel7.TabIndex = 49
        '
        'Cmbx_Overboeking_Bron
        '
        Me.Cmbx_Overboeking_Bron.FormattingEnabled = True
        Me.Cmbx_Overboeking_Bron.Location = New System.Drawing.Point(186, 9)
        Me.Cmbx_Overboeking_Bron.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbx_Overboeking_Bron.Name = "Cmbx_Overboeking_Bron"
        Me.Cmbx_Overboeking_Bron.Size = New System.Drawing.Size(352, 37)
        Me.Cmbx_Overboeking_Bron.TabIndex = 51
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(548, 18)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(76, 27)
        Me.Label26.TabIndex = 131
        Me.Label26.Text = "Bedrag"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.Location = New System.Drawing.Point(16, 18)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(129, 27)
        Me.Label95.TabIndex = 8
        Me.Label95.Text = "Bronaccount"
        '
        'Lbl_Journal_Source_Name
        '
        Me.Lbl_Journal_Source_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Journal_Source_Name.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Journal_Source_Name.Location = New System.Drawing.Point(1210, 14)
        Me.Lbl_Journal_Source_Name.Name = "Lbl_Journal_Source_Name"
        Me.Lbl_Journal_Source_Name.Size = New System.Drawing.Size(154, 36)
        Me.Lbl_Journal_Source_Name.TabIndex = 128
        Me.Lbl_Journal_Source_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Tbx_Journal_Source_Amt
        '
        Me.Tbx_Journal_Source_Amt.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Journal_Source_Amt.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Tbx_Journal_Source_Amt.Location = New System.Drawing.Point(630, 14)
        Me.Tbx_Journal_Source_Amt.Name = "Tbx_Journal_Source_Amt"
        Me.Tbx_Journal_Source_Amt.Size = New System.Drawing.Size(126, 34)
        Me.Tbx_Journal_Source_Amt.TabIndex = 44
        Me.Tbx_Journal_Source_Amt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lbl_Journal_Source_Saldo
        '
        Me.Lbl_Journal_Source_Saldo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Journal_Source_Saldo.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Journal_Source_Saldo.Location = New System.Drawing.Point(1388, 12)
        Me.Lbl_Journal_Source_Saldo.Name = "Lbl_Journal_Source_Saldo"
        Me.Lbl_Journal_Source_Saldo.Size = New System.Drawing.Size(50, 36)
        Me.Lbl_Journal_Source_Saldo.TabIndex = 123
        Me.Lbl_Journal_Source_Saldo.Text = "0"
        Me.Lbl_Journal_Source_Saldo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Lbl_Journal_Source_Saldo.Visible = False
        '
        'Lbl_Journal_Source_Restamt
        '
        Me.Lbl_Journal_Source_Restamt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Journal_Source_Restamt.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Journal_Source_Restamt.Location = New System.Drawing.Point(952, 15)
        Me.Lbl_Journal_Source_Restamt.Name = "Lbl_Journal_Source_Restamt"
        Me.Lbl_Journal_Source_Restamt.Size = New System.Drawing.Size(112, 36)
        Me.Lbl_Journal_Source_Restamt.TabIndex = 132
        Me.Lbl_Journal_Source_Restamt.Text = "0"
        Me.Lbl_Journal_Source_Restamt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Journal_Source_id
        '
        Me.Lbl_Journal_Source_id.AutoSize = True
        Me.Lbl_Journal_Source_id.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Journal_Source_id.Location = New System.Drawing.Point(1107, 22)
        Me.Lbl_Journal_Source_id.Name = "Lbl_Journal_Source_id"
        Me.Lbl_Journal_Source_id.Size = New System.Drawing.Size(55, 27)
        Me.Lbl_Journal_Source_id.TabIndex = 127
        Me.Lbl_Journal_Source_id.Text = "ac.id"
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label129.Location = New System.Drawing.Point(789, 18)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(156, 27)
        Me.Label129.TabIndex = 130
        Me.Label129.Text = "Nog te verdelen"
        '
        'Journaalposten
        '
        Me.Journaalposten.Controls.Add(Me.Splitter4)
        Me.Journaalposten.Controls.Add(Me.Panel16)
        Me.Journaalposten.Controls.Add(Me.Panel2)
        Me.Journaalposten.Location = New System.Drawing.Point(4, 38)
        Me.Journaalposten.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Journaalposten.Name = "Journaalposten"
        Me.Journaalposten.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Journaalposten.Size = New System.Drawing.Size(1604, 835)
        Me.Journaalposten.TabIndex = 2
        Me.Journaalposten.Text = "Journaalposten"
        Me.Journaalposten.UseVisualStyleBackColor = True
        '
        'Splitter4
        '
        Me.Splitter4.Location = New System.Drawing.Point(283, 5)
        Me.Splitter4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Splitter4.Name = "Splitter4"
        Me.Splitter4.Size = New System.Drawing.Size(4, 825)
        Me.Splitter4.TabIndex = 148
        Me.Splitter4.TabStop = False
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.Dgv_journaalposten)
        Me.Panel16.Controls.Add(Me.Lbl_accountname)
        Me.Panel16.Controls.Add(Me.Tbx_)
        Me.Panel16.Controls.Add(Me.journalid2)
        Me.Panel16.Controls.Add(Me.Tbx_Journal_Saldo)
        Me.Panel16.Controls.Add(Me.Lbl_Journaalposten_header)
        Me.Panel16.Controls.Add(Me.Grp_Journaalposten)
        Me.Panel16.Controls.Add(Me.Tbx_Journal_Debit)
        Me.Panel16.Controls.Add(Me.GRP_journaalposten_edit)
        Me.Panel16.Controls.Add(Me.Tbx_Journal_Credit)
        Me.Panel16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel16.Location = New System.Drawing.Point(283, 5)
        Me.Panel16.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(1317, 825)
        Me.Panel16.TabIndex = 147
        '
        'Dgv_journaalposten
        '
        Me.Dgv_journaalposten.AllowUserToDeleteRows = False
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_journaalposten.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle11
        Me.Dgv_journaalposten.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_journaalposten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_journaalposten.Location = New System.Drawing.Point(30, 328)
        Me.Dgv_journaalposten.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_journaalposten.Name = "Dgv_journaalposten"
        Me.Dgv_journaalposten.RowHeadersWidth = 50
        Me.Dgv_journaalposten.Size = New System.Drawing.Size(1274, 467)
        Me.Dgv_journaalposten.TabIndex = 62
        '
        'Lbl_accountname
        '
        Me.Lbl_accountname.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Lbl_accountname.Location = New System.Drawing.Point(450, 282)
        Me.Lbl_accountname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_accountname.Name = "Lbl_accountname"
        Me.Lbl_accountname.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_accountname.TabIndex = 60
        Me.Lbl_accountname.Text = "accountname"
        Me.Lbl_accountname.Visible = False
        '
        'Tbx_
        '
        Me.Tbx_.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Tbx_.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Tbx_.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_.Location = New System.Drawing.Point(178, 306)
        Me.Tbx_.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_.Name = "Tbx_"
        Me.Tbx_.Size = New System.Drawing.Size(136, 35)
        Me.Tbx_.TabIndex = 140
        '
        'journalid2
        '
        Me.journalid2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.journalid2.Location = New System.Drawing.Point(282, 282)
        Me.journalid2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.journalid2.Name = "journalid2"
        Me.journalid2.Size = New System.Drawing.Size(136, 32)
        Me.journalid2.TabIndex = 61
        Me.journalid2.Text = "journalid2"
        Me.journalid2.Visible = False
        '
        'Tbx_Journal_Saldo
        '
        Me.Tbx_Journal_Saldo.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Tbx_Journal_Saldo.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Journal_Saldo.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Tbx_Journal_Saldo.Location = New System.Drawing.Point(1008, 5)
        Me.Tbx_Journal_Saldo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Journal_Saldo.Name = "Tbx_Journal_Saldo"
        Me.Tbx_Journal_Saldo.Size = New System.Drawing.Size(157, 35)
        Me.Tbx_Journal_Saldo.TabIndex = 146
        Me.Tbx_Journal_Saldo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lbl_Journaalposten_header
        '
        Me.Lbl_Journaalposten_header.AutoSize = True
        Me.Lbl_Journaalposten_header.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Journaalposten_header.Location = New System.Drawing.Point(14, 14)
        Me.Lbl_Journaalposten_header.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Journaalposten_header.Name = "Lbl_Journaalposten_header"
        Me.Lbl_Journaalposten_header.Size = New System.Drawing.Size(119, 36)
        Me.Lbl_Journaalposten_header.TabIndex = 76
        Me.Lbl_Journaalposten_header.Text = "(header)"
        '
        'Grp_Journaalposten
        '
        Me.Grp_Journaalposten.Controls.Add(Me.Banklink)
        Me.Grp_Journaalposten.Controls.Add(Me.Label120)
        Me.Grp_Journaalposten.Controls.Add(Me.Label144)
        Me.Grp_Journaalposten.Controls.Add(Me.Label146)
        Me.Grp_Journaalposten.Controls.Add(Me.Label143)
        Me.Grp_Journaalposten.Controls.Add(Me.Label142)
        Me.Grp_Journaalposten.Controls.Add(Me.Label141)
        Me.Grp_Journaalposten.Controls.Add(Me.Label140)
        Me.Grp_Journaalposten.Controls.Add(Me.Label138)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_journaalposten_iban)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_journaalposten_cpinfo)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_journaalposten_wisselkoers)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_journaalposten_type)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_journaalposten_status)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_Journaalposten_bron)
        Me.Grp_Journaalposten.Controls.Add(Me.Lbl_Journaalposten_datum)
        Me.Grp_Journaalposten.Location = New System.Drawing.Point(15, 49)
        Me.Grp_Journaalposten.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Grp_Journaalposten.Name = "Grp_Journaalposten"
        Me.Grp_Journaalposten.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Grp_Journaalposten.Size = New System.Drawing.Size(566, 228)
        Me.Grp_Journaalposten.TabIndex = 65
        Me.Grp_Journaalposten.TabStop = False
        Me.Grp_Journaalposten.Text = "Transactiegegevens (niet aanpasbaar)"
        '
        'Banklink
        '
        Me.Banklink.AutoSize = True
        Me.Banklink.Location = New System.Drawing.Point(398, 185)
        Me.Banklink.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Banklink.Name = "Banklink"
        Me.Banklink.Size = New System.Drawing.Size(25, 29)
        Me.Banklink.TabIndex = 77
        Me.Banklink.TabStop = True
        Me.Banklink.Text = "0"
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Location = New System.Drawing.Point(318, 185)
        Me.Label120.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(86, 29)
        Me.Label120.TabIndex = 80
        Me.Label120.Text = "Bank id"
        '
        'Label144
        '
        Me.Label144.AutoSize = True
        Me.Label144.Location = New System.Drawing.Point(18, 185)
        Me.Label144.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label144.Name = "Label144"
        Me.Label144.Size = New System.Drawing.Size(62, 29)
        Me.Label144.TabIndex = 79
        Me.Label144.Text = "IBAN"
        '
        'Label146
        '
        Me.Label146.AutoSize = True
        Me.Label146.Location = New System.Drawing.Point(318, 45)
        Me.Label146.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label146.Name = "Label146"
        Me.Label146.Size = New System.Drawing.Size(38, 29)
        Me.Label146.TabIndex = 78
        Me.Label146.Text = "CP"
        '
        'Label143
        '
        Me.Label143.AutoSize = True
        Me.Label143.Location = New System.Drawing.Point(318, 92)
        Me.Label143.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label143.Name = "Label143"
        Me.Label143.Size = New System.Drawing.Size(60, 29)
        Me.Label143.TabIndex = 77
        Me.Label143.Text = "Bron"
        '
        'Label142
        '
        Me.Label142.AutoSize = True
        Me.Label142.Location = New System.Drawing.Point(318, 138)
        Me.Label142.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label142.Name = "Label142"
        Me.Label142.Size = New System.Drawing.Size(67, 29)
        Me.Label142.TabIndex = 76
        Me.Label142.Text = "Koers"
        '
        'Label141
        '
        Me.Label141.AutoSize = True
        Me.Label141.Location = New System.Drawing.Point(18, 138)
        Me.Label141.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label141.Name = "Label141"
        Me.Label141.Size = New System.Drawing.Size(60, 29)
        Me.Label141.TabIndex = 75
        Me.Label141.Text = "Type"
        '
        'Label140
        '
        Me.Label140.AutoSize = True
        Me.Label140.Location = New System.Drawing.Point(18, 92)
        Me.Label140.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label140.Name = "Label140"
        Me.Label140.Size = New System.Drawing.Size(74, 29)
        Me.Label140.TabIndex = 74
        Me.Label140.Text = "Status"
        '
        'Label138
        '
        Me.Label138.AutoSize = True
        Me.Label138.Location = New System.Drawing.Point(18, 46)
        Me.Label138.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label138.Name = "Label138"
        Me.Label138.Size = New System.Drawing.Size(80, 29)
        Me.Label138.TabIndex = 73
        Me.Label138.Text = "Datum"
        '
        'Lbl_journaalposten_iban
        '
        Me.Lbl_journaalposten_iban.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_journaalposten_iban.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_journaalposten_iban.ForeColor = System.Drawing.Color.Green
        Me.Lbl_journaalposten_iban.Location = New System.Drawing.Point(105, 185)
        Me.Lbl_journaalposten_iban.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_journaalposten_iban.Name = "Lbl_journaalposten_iban"
        Me.Lbl_journaalposten_iban.Size = New System.Drawing.Size(204, 32)
        Me.Lbl_journaalposten_iban.TabIndex = 72
        Me.Lbl_journaalposten_iban.Text = "NL83ABNA0887281443"
        '
        'Lbl_journaalposten_cpinfo
        '
        Me.Lbl_journaalposten_cpinfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_journaalposten_cpinfo.ForeColor = System.Drawing.Color.Green
        Me.Lbl_journaalposten_cpinfo.Location = New System.Drawing.Point(404, 46)
        Me.Lbl_journaalposten_cpinfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_journaalposten_cpinfo.Name = "Lbl_journaalposten_cpinfo"
        Me.Lbl_journaalposten_cpinfo.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_journaalposten_cpinfo.TabIndex = 71
        Me.Lbl_journaalposten_cpinfo.Tag = "65"
        '
        'Lbl_journaalposten_wisselkoers
        '
        Me.Lbl_journaalposten_wisselkoers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_journaalposten_wisselkoers.ForeColor = System.Drawing.Color.Green
        Me.Lbl_journaalposten_wisselkoers.Location = New System.Drawing.Point(404, 138)
        Me.Lbl_journaalposten_wisselkoers.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_journaalposten_wisselkoers.Name = "Lbl_journaalposten_wisselkoers"
        Me.Lbl_journaalposten_wisselkoers.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_journaalposten_wisselkoers.TabIndex = 70
        Me.Lbl_journaalposten_wisselkoers.Tag = "65"
        '
        'Lbl_journaalposten_type
        '
        Me.Lbl_journaalposten_type.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_journaalposten_type.ForeColor = System.Drawing.Color.Green
        Me.Lbl_journaalposten_type.Location = New System.Drawing.Point(105, 138)
        Me.Lbl_journaalposten_type.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_journaalposten_type.Name = "Lbl_journaalposten_type"
        Me.Lbl_journaalposten_type.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_journaalposten_type.TabIndex = 67
        Me.Lbl_journaalposten_type.Tag = "65"
        '
        'Lbl_journaalposten_status
        '
        Me.Lbl_journaalposten_status.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_journaalposten_status.ForeColor = System.Drawing.Color.Green
        Me.Lbl_journaalposten_status.Location = New System.Drawing.Point(105, 92)
        Me.Lbl_journaalposten_status.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_journaalposten_status.Name = "Lbl_journaalposten_status"
        Me.Lbl_journaalposten_status.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_journaalposten_status.TabIndex = 66
        Me.Lbl_journaalposten_status.Tag = "65"
        '
        'Lbl_Journaalposten_bron
        '
        Me.Lbl_Journaalposten_bron.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Journaalposten_bron.ForeColor = System.Drawing.Color.Green
        Me.Lbl_Journaalposten_bron.Location = New System.Drawing.Point(404, 92)
        Me.Lbl_Journaalposten_bron.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Journaalposten_bron.Name = "Lbl_Journaalposten_bron"
        Me.Lbl_Journaalposten_bron.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_Journaalposten_bron.TabIndex = 65
        Me.Lbl_Journaalposten_bron.Tag = ""
        '
        'Lbl_Journaalposten_datum
        '
        Me.Lbl_Journaalposten_datum.BackColor = System.Drawing.SystemColors.Control
        Me.Lbl_Journaalposten_datum.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Journaalposten_datum.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Lbl_Journaalposten_datum.ForeColor = System.Drawing.Color.Green
        Me.Lbl_Journaalposten_datum.Location = New System.Drawing.Point(105, 46)
        Me.Lbl_Journaalposten_datum.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Journaalposten_datum.Name = "Lbl_Journaalposten_datum"
        Me.Lbl_Journaalposten_datum.Size = New System.Drawing.Size(130, 32)
        Me.Lbl_Journaalposten_datum.TabIndex = 63
        Me.Lbl_Journaalposten_datum.Tag = "65"
        '
        'Tbx_Journal_Debit
        '
        Me.Tbx_Journal_Debit.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Tbx_Journal_Debit.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Journal_Debit.ForeColor = System.Drawing.Color.Red
        Me.Tbx_Journal_Debit.Location = New System.Drawing.Point(849, 5)
        Me.Tbx_Journal_Debit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Journal_Debit.Name = "Tbx_Journal_Debit"
        Me.Tbx_Journal_Debit.Size = New System.Drawing.Size(148, 35)
        Me.Tbx_Journal_Debit.TabIndex = 145
        Me.Tbx_Journal_Debit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GRP_journaalposten_edit
        '
        Me.GRP_journaalposten_edit.Controls.Add(Me.Label147)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Btn_journaalposten_Save)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Label131)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Tbx_journaalposten_omschr)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Label133)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Cmbx_journaalposten_relatie)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Lbl00x)
        Me.GRP_journaalposten_edit.Controls.Add(Me.Cmbx_journaalposten_account)
        Me.GRP_journaalposten_edit.Location = New System.Drawing.Point(630, 49)
        Me.GRP_journaalposten_edit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GRP_journaalposten_edit.Name = "GRP_journaalposten_edit"
        Me.GRP_journaalposten_edit.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GRP_journaalposten_edit.Size = New System.Drawing.Size(674, 265)
        Me.GRP_journaalposten_edit.TabIndex = 75
        Me.GRP_journaalposten_edit.TabStop = False
        Me.GRP_journaalposten_edit.Text = "Transactiepostgegevens (aanpasbaar)"
        '
        'Label147
        '
        Me.Label147.AutoSize = True
        Me.Label147.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label147.ForeColor = System.Drawing.Color.Brown
        Me.Label147.Location = New System.Drawing.Point(9, 222)
        Me.Label147.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label147.Name = "Label147"
        Me.Label147.Size = New System.Drawing.Size(573, 28)
        Me.Label147.TabIndex = 82
        Me.Label147.Text = "Nieuwe post invoeren: voer in op lege regel onderin de tabel "
        '
        'Btn_journaalposten_Save
        '
        Me.Btn_journaalposten_Save.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Btn_journaalposten_Save.Image = CType(resources.GetObject("Btn_journaalposten_Save.Image"), System.Drawing.Image)
        Me.Btn_journaalposten_Save.Location = New System.Drawing.Point(488, 37)
        Me.Btn_journaalposten_Save.Name = "Btn_journaalposten_Save"
        Me.Btn_journaalposten_Save.Size = New System.Drawing.Size(45, 35)
        Me.Btn_journaalposten_Save.TabIndex = 81
        Me.Btn_journaalposten_Save.UseVisualStyleBackColor = True
        Me.Btn_journaalposten_Save.Visible = False
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Location = New System.Drawing.Point(213, 45)
        Me.Label131.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(141, 29)
        Me.Label131.TabIndex = 76
        Me.Label131.Text = "Omschrijving"
        '
        'Tbx_journaalposten_omschr
        '
        Me.Tbx_journaalposten_omschr.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_journaalposten_omschr.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_journaalposten_omschr.Location = New System.Drawing.Point(219, 82)
        Me.Tbx_journaalposten_omschr.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_journaalposten_omschr.Multiline = True
        Me.Tbx_journaalposten_omschr.Name = "Tbx_journaalposten_omschr"
        Me.Tbx_journaalposten_omschr.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_journaalposten_omschr.Size = New System.Drawing.Size(418, 129)
        Me.Tbx_journaalposten_omschr.TabIndex = 75
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Location = New System.Drawing.Point(8, 132)
        Me.Label133.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(81, 29)
        Me.Label133.TabIndex = 74
        Me.Label133.Text = "Relatie"
        '
        'Cmbx_journaalposten_relatie
        '
        Me.Cmbx_journaalposten_relatie.ForeColor = System.Drawing.Color.Blue
        Me.Cmbx_journaalposten_relatie.FormattingEnabled = True
        Me.Cmbx_journaalposten_relatie.Location = New System.Drawing.Point(14, 166)
        Me.Cmbx_journaalposten_relatie.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbx_journaalposten_relatie.Name = "Cmbx_journaalposten_relatie"
        Me.Cmbx_journaalposten_relatie.Size = New System.Drawing.Size(192, 37)
        Me.Cmbx_journaalposten_relatie.TabIndex = 73
        '
        'Lbl00x
        '
        Me.Lbl00x.AutoSize = True
        Me.Lbl00x.Location = New System.Drawing.Point(8, 48)
        Me.Lbl00x.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl00x.Name = "Lbl00x"
        Me.Lbl00x.Size = New System.Drawing.Size(94, 29)
        Me.Lbl00x.TabIndex = 68
        Me.Lbl00x.Text = "Account"
        '
        'Cmbx_journaalposten_account
        '
        Me.Cmbx_journaalposten_account.ForeColor = System.Drawing.Color.Blue
        Me.Cmbx_journaalposten_account.FormattingEnabled = True
        Me.Cmbx_journaalposten_account.Location = New System.Drawing.Point(14, 82)
        Me.Cmbx_journaalposten_account.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmbx_journaalposten_account.Name = "Cmbx_journaalposten_account"
        Me.Cmbx_journaalposten_account.Size = New System.Drawing.Size(192, 37)
        Me.Cmbx_journaalposten_account.TabIndex = 69
        '
        'Tbx_Journal_Credit
        '
        Me.Tbx_Journal_Credit.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Tbx_Journal_Credit.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Journal_Credit.ForeColor = System.Drawing.Color.Green
        Me.Tbx_Journal_Credit.Location = New System.Drawing.Point(690, 9)
        Me.Tbx_Journal_Credit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Journal_Credit.Name = "Tbx_Journal_Credit"
        Me.Tbx_Journal_Credit.Size = New System.Drawing.Size(148, 35)
        Me.Tbx_Journal_Credit.TabIndex = 144
        Me.Tbx_Journal_Credit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Cbx_Journal_Status_Verwerkt)
        Me.Panel2.Controls.Add(Me.Lbl_Journal_Status)
        Me.Panel2.Controls.Add(Me.Cbx_Journal_Status_Open)
        Me.Panel2.Controls.Add(Me.Tbx_Journal_Filter)
        Me.Panel2.Controls.Add(Me.Lv_Journal_List)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(4, 5)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(279, 825)
        Me.Panel2.TabIndex = 134
        '
        'Cbx_Journal_Status_Verwerkt
        '
        Me.Cbx_Journal_Status_Verwerkt.AutoSize = True
        Me.Cbx_Journal_Status_Verwerkt.Checked = True
        Me.Cbx_Journal_Status_Verwerkt.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_Journal_Status_Verwerkt.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cbx_Journal_Status_Verwerkt.Location = New System.Drawing.Point(160, 9)
        Me.Cbx_Journal_Status_Verwerkt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_Journal_Status_Verwerkt.Name = "Cbx_Journal_Status_Verwerkt"
        Me.Cbx_Journal_Status_Verwerkt.Size = New System.Drawing.Size(102, 26)
        Me.Cbx_Journal_Status_Verwerkt.TabIndex = 135
        Me.Cbx_Journal_Status_Verwerkt.Text = "Verwerkt"
        Me.Cbx_Journal_Status_Verwerkt.UseVisualStyleBackColor = True
        '
        'Lbl_Journal_Status
        '
        Me.Lbl_Journal_Status.AutoSize = True
        Me.Lbl_Journal_Status.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Journal_Status.Location = New System.Drawing.Point(9, 14)
        Me.Lbl_Journal_Status.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Journal_Status.Name = "Lbl_Journal_Status"
        Me.Lbl_Journal_Status.Size = New System.Drawing.Size(55, 22)
        Me.Lbl_Journal_Status.TabIndex = 136
        Me.Lbl_Journal_Status.Text = "Status"
        '
        'Cbx_Journal_Status_Open
        '
        Me.Cbx_Journal_Status_Open.AutoSize = True
        Me.Cbx_Journal_Status_Open.Checked = True
        Me.Cbx_Journal_Status_Open.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_Journal_Status_Open.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cbx_Journal_Status_Open.Location = New System.Drawing.Point(80, 9)
        Me.Cbx_Journal_Status_Open.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_Journal_Status_Open.Name = "Cbx_Journal_Status_Open"
        Me.Cbx_Journal_Status_Open.Size = New System.Drawing.Size(75, 26)
        Me.Cbx_Journal_Status_Open.TabIndex = 134
        Me.Cbx_Journal_Status_Open.Text = "Open"
        Me.Cbx_Journal_Status_Open.UseVisualStyleBackColor = True
        '
        'Tbx_Journal_Filter
        '
        Me.Tbx_Journal_Filter.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Journal_Filter.Location = New System.Drawing.Point(3, 3)
        Me.Tbx_Journal_Filter.Name = "Tbx_Journal_Filter"
        Me.Tbx_Journal_Filter.Size = New System.Drawing.Size(25, 34)
        Me.Tbx_Journal_Filter.TabIndex = 57
        Me.Tbx_Journal_Filter.Visible = False
        '
        'Lv_Journal_List
        '
        Me.Lv_Journal_List.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Lv_Journal_List.CheckBoxes = True
        Me.Lv_Journal_List.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.Lv_Journal_List.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lv_Journal_List.FullRowSelect = True
        Me.Lv_Journal_List.HideSelection = False
        Me.Lv_Journal_List.Location = New System.Drawing.Point(3, 49)
        Me.Lv_Journal_List.Name = "Lv_Journal_List"
        Me.Lv_Journal_List.Size = New System.Drawing.Size(271, 771)
        Me.Lv_Journal_List.TabIndex = 54
        Me.Lv_Journal_List.UseCompatibleStateImageBehavior = False
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Width = 0
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Naam"
        Me.ColumnHeader2.Width = 200
        '
        'Accounts
        '
        Me.Accounts.Controls.Add(Me.Panel17)
        Me.Accounts.Location = New System.Drawing.Point(4, 38)
        Me.Accounts.Name = "Accounts"
        Me.Accounts.Padding = New System.Windows.Forms.Padding(3)
        Me.Accounts.Size = New System.Drawing.Size(1604, 835)
        Me.Accounts.TabIndex = 4
        Me.Accounts.Text = "Accounts"
        Me.Accounts.UseVisualStyleBackColor = True
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Btn_Boeking_Expand_Collapse)
        Me.Panel17.Controls.Add(Me.AccountTree)
        Me.Panel17.Location = New System.Drawing.Point(33, 26)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(441, 758)
        Me.Panel17.TabIndex = 1
        '
        'Btn_Boeking_Expand_Collapse
        '
        Me.Btn_Boeking_Expand_Collapse.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Btn_Boeking_Expand_Collapse.Location = New System.Drawing.Point(27, 706)
        Me.Btn_Boeking_Expand_Collapse.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Boeking_Expand_Collapse.Name = "Btn_Boeking_Expand_Collapse"
        Me.Btn_Boeking_Expand_Collapse.Size = New System.Drawing.Size(394, 43)
        Me.Btn_Boeking_Expand_Collapse.TabIndex = 85
        Me.Btn_Boeking_Expand_Collapse.Text = "Alles uitklappen"
        Me.Btn_Boeking_Expand_Collapse.UseVisualStyleBackColor = True
        '
        'AccountTree
        '
        Me.AccountTree.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AccountTree.Location = New System.Drawing.Point(27, 15)
        Me.AccountTree.Name = "AccountTree"
        Me.AccountTree.Size = New System.Drawing.Size(392, 687)
        Me.AccountTree.TabIndex = 0
        '
        'Jaarafsluiting
        '
        Me.Jaarafsluiting.Controls.Add(Me.Dgv_Report_Year_Closing)
        Me.Jaarafsluiting.Controls.Add(Me.Btn_Report_YearEnd_Check)
        Me.Jaarafsluiting.Controls.Add(Me.Lbl_Report_total)
        Me.Jaarafsluiting.Controls.Add(Me.Btn_Report_YearEnd_Post)
        Me.Jaarafsluiting.Location = New System.Drawing.Point(4, 38)
        Me.Jaarafsluiting.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Jaarafsluiting.Name = "Jaarafsluiting"
        Me.Jaarafsluiting.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Jaarafsluiting.Size = New System.Drawing.Size(1604, 835)
        Me.Jaarafsluiting.TabIndex = 3
        Me.Jaarafsluiting.Text = "Jaarafsluiting"
        Me.Jaarafsluiting.UseVisualStyleBackColor = True
        '
        'Dgv_Report_Year_Closing
        '
        Me.Dgv_Report_Year_Closing.AllowUserToAddRows = False
        Me.Dgv_Report_Year_Closing.AllowUserToDeleteRows = False
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Report_Year_Closing.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle12
        Me.Dgv_Report_Year_Closing.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Report_Year_Closing.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv_Report_Year_Closing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Report_Year_Closing.Location = New System.Drawing.Point(8, 60)
        Me.Dgv_Report_Year_Closing.Name = "Dgv_Report_Year_Closing"
        Me.Dgv_Report_Year_Closing.RowHeadersVisible = False
        Me.Dgv_Report_Year_Closing.RowHeadersWidth = 50
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Report_Year_Closing.RowsDefaultCellStyle = DataGridViewCellStyle13
        Me.Dgv_Report_Year_Closing.RowTemplate.Height = 20
        Me.Dgv_Report_Year_Closing.Size = New System.Drawing.Size(1354, 729)
        Me.Dgv_Report_Year_Closing.TabIndex = 89
        '
        'Btn_Report_YearEnd_Check
        '
        Me.Btn_Report_YearEnd_Check.BackColor = System.Drawing.SystemColors.Control
        Me.Btn_Report_YearEnd_Check.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Report_YearEnd_Check.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Report_YearEnd_Check.Name = "Btn_Report_YearEnd_Check"
        Me.Btn_Report_YearEnd_Check.Size = New System.Drawing.Size(270, 51)
        Me.Btn_Report_YearEnd_Check.TabIndex = 88
        Me.Btn_Report_YearEnd_Check.Text = "Controleer administratie"
        Me.Btn_Report_YearEnd_Check.UseVisualStyleBackColor = False
        '
        'Lbl_Report_total
        '
        Me.Lbl_Report_total.AutoSize = True
        Me.Lbl_Report_total.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Report_total.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Lbl_Report_total.Location = New System.Drawing.Point(1046, 3)
        Me.Lbl_Report_total.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Report_total.Name = "Lbl_Report_total"
        Me.Lbl_Report_total.Size = New System.Drawing.Size(104, 31)
        Me.Lbl_Report_total.TabIndex = 87
        Me.Lbl_Report_total.Text = "Label124"
        Me.Lbl_Report_total.Visible = False
        '
        'Btn_Report_YearEnd_Post
        '
        Me.Btn_Report_YearEnd_Post.BackColor = System.Drawing.SystemColors.Control
        Me.Btn_Report_YearEnd_Post.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Report_YearEnd_Post.Location = New System.Drawing.Point(273, 3)
        Me.Btn_Report_YearEnd_Post.Name = "Btn_Report_YearEnd_Post"
        Me.Btn_Report_YearEnd_Post.Size = New System.Drawing.Size(232, 51)
        Me.Btn_Report_YearEnd_Post.TabIndex = 86
        Me.Btn_Report_YearEnd_Post.Text = "Voer jaarafsluiting uit"
        Me.Btn_Report_YearEnd_Post.UseVisualStyleBackColor = False
        '
        'Uitkering
        '
        Me.Uitkering.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Uitkering.Controls.Add(Me.Splitter3)
        Me.Uitkering.Controls.Add(Me.Panel15)
        Me.Uitkering.Controls.Add(Me.Splitter2)
        Me.Uitkering.Controls.Add(Me.Panel14)
        Me.Uitkering.Controls.Add(Me.Panel4)
        Me.Uitkering.Controls.Add(Me.Btn_Excasso_Save)
        Me.Uitkering.Controls.Add(Me.Btn_Excasso_Print)
        Me.Uitkering.Controls.Add(Me.Btn_Excasso_Cancel)
        Me.Uitkering.Controls.Add(Me.Btn_Excasso_Delete)
        Me.Uitkering.Location = New System.Drawing.Point(4, 38)
        Me.Uitkering.Name = "Uitkering"
        Me.Uitkering.Padding = New System.Windows.Forms.Padding(3)
        Me.Uitkering.Size = New System.Drawing.Size(1618, 889)
        Me.Uitkering.TabIndex = 3
        Me.Uitkering.Text = "Uitkering   "
        '
        'Splitter3
        '
        Me.Splitter3.Location = New System.Drawing.Point(941, 212)
        Me.Splitter3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Splitter3.Name = "Splitter3"
        Me.Splitter3.Size = New System.Drawing.Size(4, 674)
        Me.Splitter3.TabIndex = 136
        Me.Splitter3.TabStop = False
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.Dgv_Uitkering_Account_Details)
        Me.Panel15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel15.Location = New System.Drawing.Point(941, 212)
        Me.Panel15.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(674, 674)
        Me.Panel15.TabIndex = 135
        '
        'Dgv_Uitkering_Account_Details
        '
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        Me.Dgv_Uitkering_Account_Details.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle14
        Me.Dgv_Uitkering_Account_Details.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Uitkering_Account_Details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Uitkering_Account_Details.Location = New System.Drawing.Point(9, 8)
        Me.Dgv_Uitkering_Account_Details.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_Uitkering_Account_Details.Name = "Dgv_Uitkering_Account_Details"
        Me.Dgv_Uitkering_Account_Details.RowHeadersVisible = False
        Me.Dgv_Uitkering_Account_Details.RowHeadersWidth = 82
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Uitkering_Account_Details.RowsDefaultCellStyle = DataGridViewCellStyle15
        Me.Dgv_Uitkering_Account_Details.RowTemplate.Height = 20
        Me.Dgv_Uitkering_Account_Details.Size = New System.Drawing.Size(662, 660)
        Me.Dgv_Uitkering_Account_Details.TabIndex = 132
        '
        'Splitter2
        '
        Me.Splitter2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Splitter2.Location = New System.Drawing.Point(941, 209)
        Me.Splitter2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Splitter2.Name = "Splitter2"
        Me.Splitter2.Size = New System.Drawing.Size(674, 3)
        Me.Splitter2.TabIndex = 134
        Me.Splitter2.TabStop = False
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.Dgv_Excasso2)
        Me.Panel14.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel14.Location = New System.Drawing.Point(3, 209)
        Me.Panel14.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(938, 677)
        Me.Panel14.TabIndex = 133
        '
        'Dgv_Excasso2
        '
        Me.Dgv_Excasso2.AllowUserToAddRows = False
        Me.Dgv_Excasso2.AllowUserToDeleteRows = False
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Excasso2.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle16
        Me.Dgv_Excasso2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Excasso2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv_Excasso2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.Format = "#.##"
        DataGridViewCellStyle17.NullValue = """"""
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dgv_Excasso2.DefaultCellStyle = DataGridViewCellStyle17
        Me.Dgv_Excasso2.Location = New System.Drawing.Point(4, 6)
        Me.Dgv_Excasso2.Name = "Dgv_Excasso2"
        Me.Dgv_Excasso2.RowHeadersVisible = False
        Me.Dgv_Excasso2.RowHeadersWidth = 50
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Excasso2.RowsDefaultCellStyle = DataGridViewCellStyle18
        Me.Dgv_Excasso2.RowTemplate.Height = 20
        Me.Dgv_Excasso2.Size = New System.Drawing.Size(926, 665)
        Me.Dgv_Excasso2.TabIndex = 73
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Gbx_Excasso_Doeltype)
        Me.Panel4.Controls.Add(Me.GroupBox1)
        Me.Panel4.Controls.Add(Me.Gbx_Excasso_Calculate)
        Me.Panel4.Controls.Add(Me.GroupBox4)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(3, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1612, 206)
        Me.Panel4.TabIndex = 131
        '
        'Gbx_Excasso_Doeltype
        '
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Label123)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Dtp_Excasso_Start)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Btn_Excasso_Exchrate)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Tbx_Excasso_Exchange_rate)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Label103)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Button8)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Lbl_Excasso_LastCalc)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Lbl_Excasso_CPid)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Btn_Excasso_Copy_to_clipboard)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Btn_Excasso_Calculate_Exchrate)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Cbx_Uitkering_Kind)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Label83)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Cbx_Uitkering_Oudere)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Cbx_Uitkering_Overig)
        Me.Gbx_Excasso_Doeltype.Controls.Add(Me.Cmx_Excasso_Select)
        Me.Gbx_Excasso_Doeltype.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Gbx_Excasso_Doeltype.Location = New System.Drawing.Point(3, 3)
        Me.Gbx_Excasso_Doeltype.Name = "Gbx_Excasso_Doeltype"
        Me.Gbx_Excasso_Doeltype.Size = New System.Drawing.Size(432, 192)
        Me.Gbx_Excasso_Doeltype.TabIndex = 112
        Me.Gbx_Excasso_Doeltype.TabStop = False
        Me.Gbx_Excasso_Doeltype.Text = "Selecteer"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label123.Location = New System.Drawing.Point(2, 71)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(101, 28)
        Me.Label123.TabIndex = 132
        Me.Label123.Text = "Doeltype:"
        '
        'Dtp_Excasso_Start
        '
        Me.Dtp_Excasso_Start.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.Dtp_Excasso_Start.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Excasso_Start.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_Excasso_Start.Location = New System.Drawing.Point(124, 102)
        Me.Dtp_Excasso_Start.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_Excasso_Start.Name = "Dtp_Excasso_Start"
        Me.Dtp_Excasso_Start.Size = New System.Drawing.Size(139, 34)
        Me.Dtp_Excasso_Start.TabIndex = 67
        Me.Dtp_Excasso_Start.Value = New Date(2018, 1, 1, 0, 0, 0, 0)
        '
        'Btn_Excasso_Exchrate
        '
        Me.Btn_Excasso_Exchrate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Excasso_Exchrate.Enabled = False
        Me.Btn_Excasso_Exchrate.Image = CType(resources.GetObject("Btn_Excasso_Exchrate.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Exchrate.Location = New System.Drawing.Point(387, 143)
        Me.Btn_Excasso_Exchrate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Exchrate.Name = "Btn_Excasso_Exchrate"
        Me.Btn_Excasso_Exchrate.Size = New System.Drawing.Size(45, 46)
        Me.Btn_Excasso_Exchrate.TabIndex = 113
        Me.Btn_Excasso_Exchrate.UseVisualStyleBackColor = True
        '
        'Tbx_Excasso_Exchange_rate
        '
        Me.Tbx_Excasso_Exchange_rate.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_Exchange_rate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Tbx_Excasso_Exchange_rate.Location = New System.Drawing.Point(280, 102)
        Me.Tbx_Excasso_Exchange_rate.Name = "Tbx_Excasso_Exchange_rate"
        Me.Tbx_Excasso_Exchange_rate.Size = New System.Drawing.Size(76, 34)
        Me.Tbx_Excasso_Exchange_rate.TabIndex = 104
        Me.Tbx_Excasso_Exchange_rate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.Location = New System.Drawing.Point(276, 71)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(119, 28)
        Me.Label103.TabIndex = 103
        Me.Label103.Text = "Koers MDL:"
        '
        'Button8
        '
        Me.Button8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(334, 148)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(48, 43)
        Me.Button8.TabIndex = 105
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Lbl_Excasso_LastCalc
        '
        Me.Lbl_Excasso_LastCalc.AutoSize = True
        Me.Lbl_Excasso_LastCalc.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_LastCalc.Location = New System.Drawing.Point(178, 0)
        Me.Lbl_Excasso_LastCalc.Name = "Lbl_Excasso_LastCalc"
        Me.Lbl_Excasso_LastCalc.Size = New System.Drawing.Size(24, 28)
        Me.Lbl_Excasso_LastCalc.TabIndex = 130
        Me.Lbl_Excasso_LastCalc.Text = "0"
        Me.Lbl_Excasso_LastCalc.Visible = False
        '
        'Lbl_Excasso_CPid
        '
        Me.Lbl_Excasso_CPid.AutoSize = True
        Me.Lbl_Excasso_CPid.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_CPid.Location = New System.Drawing.Point(120, 0)
        Me.Lbl_Excasso_CPid.Name = "Lbl_Excasso_CPid"
        Me.Lbl_Excasso_CPid.Size = New System.Drawing.Size(58, 28)
        Me.Lbl_Excasso_CPid.TabIndex = 118
        Me.Lbl_Excasso_CPid.Text = "Cp id"
        Me.Lbl_Excasso_CPid.Visible = False
        '
        'Btn_Excasso_Copy_to_clipboard
        '
        Me.Btn_Excasso_Copy_to_clipboard.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Btn_Excasso_Copy_to_clipboard.Image = CType(resources.GetObject("Btn_Excasso_Copy_to_clipboard.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Copy_to_clipboard.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Btn_Excasso_Copy_to_clipboard.Location = New System.Drawing.Point(387, 26)
        Me.Btn_Excasso_Copy_to_clipboard.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Copy_to_clipboard.Name = "Btn_Excasso_Copy_to_clipboard"
        Me.Btn_Excasso_Copy_to_clipboard.Size = New System.Drawing.Size(45, 46)
        Me.Btn_Excasso_Copy_to_clipboard.TabIndex = 131
        Me.Btn_Excasso_Copy_to_clipboard.UseVisualStyleBackColor = True
        '
        'Btn_Excasso_Calculate_Exchrate
        '
        Me.Btn_Excasso_Calculate_Exchrate.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Excasso_Calculate_Exchrate.Enabled = False
        Me.Btn_Excasso_Calculate_Exchrate.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Excasso_Calculate_Exchrate.Image = CType(resources.GetObject("Btn_Excasso_Calculate_Exchrate.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Calculate_Exchrate.Location = New System.Drawing.Point(280, 145)
        Me.Btn_Excasso_Calculate_Exchrate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Calculate_Exchrate.Name = "Btn_Excasso_Calculate_Exchrate"
        Me.Btn_Excasso_Calculate_Exchrate.Size = New System.Drawing.Size(45, 46)
        Me.Btn_Excasso_Calculate_Exchrate.TabIndex = 114
        Me.Btn_Excasso_Calculate_Exchrate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btn_Excasso_Calculate_Exchrate.UseVisualStyleBackColor = True
        '
        'Cbx_Uitkering_Kind
        '
        Me.Cbx_Uitkering_Kind.AutoSize = True
        Me.Cbx_Uitkering_Kind.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cbx_Uitkering_Kind.Location = New System.Drawing.Point(6, 100)
        Me.Cbx_Uitkering_Kind.Name = "Cbx_Uitkering_Kind"
        Me.Cbx_Uitkering_Kind.Size = New System.Drawing.Size(78, 31)
        Me.Cbx_Uitkering_Kind.TabIndex = 70
        Me.Cbx_Uitkering_Kind.Text = "Kind"
        Me.Cbx_Uitkering_Kind.UseVisualStyleBackColor = True
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.Location = New System.Drawing.Point(120, 69)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(86, 28)
        Me.Label83.TabIndex = 68
        Me.Label83.Text = "Datum: "
        '
        'Cbx_Uitkering_Oudere
        '
        Me.Cbx_Uitkering_Oudere.AutoSize = True
        Me.Cbx_Uitkering_Oudere.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cbx_Uitkering_Oudere.Location = New System.Drawing.Point(6, 132)
        Me.Cbx_Uitkering_Oudere.Name = "Cbx_Uitkering_Oudere"
        Me.Cbx_Uitkering_Oudere.Size = New System.Drawing.Size(107, 31)
        Me.Cbx_Uitkering_Oudere.TabIndex = 71
        Me.Cbx_Uitkering_Oudere.Text = "Oudere"
        Me.Cbx_Uitkering_Oudere.UseVisualStyleBackColor = True
        '
        'Cbx_Uitkering_Overig
        '
        Me.Cbx_Uitkering_Overig.AutoSize = True
        Me.Cbx_Uitkering_Overig.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cbx_Uitkering_Overig.Location = New System.Drawing.Point(6, 162)
        Me.Cbx_Uitkering_Overig.Name = "Cbx_Uitkering_Overig"
        Me.Cbx_Uitkering_Overig.Size = New System.Drawing.Size(97, 31)
        Me.Cbx_Uitkering_Overig.TabIndex = 72
        Me.Cbx_Uitkering_Overig.Text = "Overig"
        Me.Cbx_Uitkering_Overig.UseVisualStyleBackColor = True
        '
        'Cmx_Excasso_Select
        '
        Me.Cmx_Excasso_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmx_Excasso_Select.FormattingEnabled = True
        Me.Cmx_Excasso_Select.Location = New System.Drawing.Point(2, 29)
        Me.Cmx_Excasso_Select.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_Excasso_Select.Name = "Cmx_Excasso_Select"
        Me.Cmx_Excasso_Select.Size = New System.Drawing.Size(379, 35)
        Me.Cmx_Excasso_Select.TabIndex = 113
        Me.Cmx_Excasso_Select.Tag = "Contactpersoon"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Pan_Excasso_preset)
        Me.GroupBox1.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(456, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(188, 185)
        Me.GroupBox1.TabIndex = 116
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Vooraf invullen"
        '
        'Pan_Excasso_preset
        '
        Me.Pan_Excasso_preset.Controls.Add(Me.Rbn_uitkering_budget)
        Me.Pan_Excasso_preset.Controls.Add(Me.Rbn_uitkering_saldo)
        Me.Pan_Excasso_preset.Controls.Add(Me.Rbn_uitkering_nul)
        Me.Pan_Excasso_preset.Location = New System.Drawing.Point(14, 35)
        Me.Pan_Excasso_preset.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pan_Excasso_preset.Name = "Pan_Excasso_preset"
        Me.Pan_Excasso_preset.Size = New System.Drawing.Size(174, 106)
        Me.Pan_Excasso_preset.TabIndex = 134
        '
        'Rbn_uitkering_budget
        '
        Me.Rbn_uitkering_budget.AutoSize = True
        Me.Rbn_uitkering_budget.Checked = True
        Me.Rbn_uitkering_budget.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbn_uitkering_budget.Location = New System.Drawing.Point(4, 5)
        Me.Rbn_uitkering_budget.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_uitkering_budget.Name = "Rbn_uitkering_budget"
        Me.Rbn_uitkering_budget.Size = New System.Drawing.Size(77, 32)
        Me.Rbn_uitkering_budget.TabIndex = 132
        Me.Rbn_uitkering_budget.TabStop = True
        Me.Rbn_uitkering_budget.Text = "Plan"
        Me.Rbn_uitkering_budget.UseVisualStyleBackColor = True
        '
        'Rbn_uitkering_saldo
        '
        Me.Rbn_uitkering_saldo.AutoSize = True
        Me.Rbn_uitkering_saldo.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbn_uitkering_saldo.Location = New System.Drawing.Point(4, 34)
        Me.Rbn_uitkering_saldo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_uitkering_saldo.Name = "Rbn_uitkering_saldo"
        Me.Rbn_uitkering_saldo.Size = New System.Drawing.Size(102, 32)
        Me.Rbn_uitkering_saldo.TabIndex = 132
        Me.Rbn_uitkering_saldo.Text = "Saldo's"
        Me.Rbn_uitkering_saldo.UseVisualStyleBackColor = True
        '
        'Rbn_uitkering_nul
        '
        Me.Rbn_uitkering_nul.AutoSize = True
        Me.Rbn_uitkering_nul.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbn_uitkering_nul.Location = New System.Drawing.Point(6, 63)
        Me.Rbn_uitkering_nul.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_uitkering_nul.Name = "Rbn_uitkering_nul"
        Me.Rbn_uitkering_nul.Size = New System.Drawing.Size(150, 32)
        Me.Rbn_uitkering_nul.TabIndex = 132
        Me.Rbn_uitkering_nul.Text = "Nulwaarden"
        Me.Rbn_uitkering_nul.UseVisualStyleBackColor = True
        '
        'Gbx_Excasso_Calculate
        '
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Label106)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Label127)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Items_Contract)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Items_Intern)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Intern)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Label107)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Extra)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Items_Extra)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Totalen)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Tot_Gen)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_CP_Totaal)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Contractwaarde)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Tot_Gen_MLD)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_CP_Totaal_MDL)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Totaal_MDL)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Label89)
        Me.Gbx_Excasso_Calculate.Controls.Add(Me.Lbl_Excasso_Totaal)
        Me.Gbx_Excasso_Calculate.Enabled = False
        Me.Gbx_Excasso_Calculate.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Gbx_Excasso_Calculate.Location = New System.Drawing.Point(1088, 11)
        Me.Gbx_Excasso_Calculate.Name = "Gbx_Excasso_Calculate"
        Me.Gbx_Excasso_Calculate.Size = New System.Drawing.Size(432, 182)
        Me.Gbx_Excasso_Calculate.TabIndex = 117
        Me.Gbx_Excasso_Calculate.TabStop = False
        Me.Gbx_Excasso_Calculate.Text = "Overzicht"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.Location = New System.Drawing.Point(264, 20)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(50, 28)
        Me.Label106.TabIndex = 134
        Me.Label106.Text = "EUR"
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.Location = New System.Drawing.Point(350, 20)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(56, 28)
        Me.Label127.TabIndex = 133
        Me.Label127.Text = "MLD"
        '
        'Lbl_Excasso_Items_Contract
        '
        Me.Lbl_Excasso_Items_Contract.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Items_Contract.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Items_Contract.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lbl_Excasso_Items_Contract.Location = New System.Drawing.Point(190, 117)
        Me.Lbl_Excasso_Items_Contract.Name = "Lbl_Excasso_Items_Contract"
        Me.Lbl_Excasso_Items_Contract.Size = New System.Drawing.Size(39, 25)
        Me.Lbl_Excasso_Items_Contract.TabIndex = 119
        Me.Lbl_Excasso_Items_Contract.Text = "0"
        Me.Lbl_Excasso_Items_Contract.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_Excasso_Items_Contract.Visible = False
        '
        'Lbl_Excasso_Items_Intern
        '
        Me.Lbl_Excasso_Items_Intern.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Items_Intern.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Items_Intern.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lbl_Excasso_Items_Intern.Location = New System.Drawing.Point(170, 18)
        Me.Lbl_Excasso_Items_Intern.Name = "Lbl_Excasso_Items_Intern"
        Me.Lbl_Excasso_Items_Intern.Size = New System.Drawing.Size(60, 25)
        Me.Lbl_Excasso_Items_Intern.TabIndex = 117
        Me.Lbl_Excasso_Items_Intern.Text = "0"
        Me.Lbl_Excasso_Items_Intern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_Excasso_Items_Intern.Visible = False
        '
        'Lbl_Excasso_Intern
        '
        Me.Lbl_Excasso_Intern.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Intern.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Intern.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lbl_Excasso_Intern.Location = New System.Drawing.Point(170, 92)
        Me.Lbl_Excasso_Intern.Name = "Lbl_Excasso_Intern"
        Me.Lbl_Excasso_Intern.Size = New System.Drawing.Size(60, 25)
        Me.Lbl_Excasso_Intern.TabIndex = 76
        Me.Lbl_Excasso_Intern.Text = "0"
        Me.Lbl_Excasso_Intern.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Lbl_Excasso_Intern.Visible = False
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(22, 143)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(198, 28)
        Me.Label107.TabIndex = 132
        Me.Label107.Text = "Eindtotaal formulier"
        '
        'Lbl_Excasso_Extra
        '
        Me.Lbl_Excasso_Extra.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Extra.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Extra.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lbl_Excasso_Extra.Location = New System.Drawing.Point(170, 68)
        Me.Lbl_Excasso_Extra.Name = "Lbl_Excasso_Extra"
        Me.Lbl_Excasso_Extra.Size = New System.Drawing.Size(60, 25)
        Me.Lbl_Excasso_Extra.TabIndex = 76
        Me.Lbl_Excasso_Extra.Text = "0"
        Me.Lbl_Excasso_Extra.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Lbl_Excasso_Extra.Visible = False
        '
        'Lbl_Excasso_Items_Extra
        '
        Me.Lbl_Excasso_Items_Extra.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Items_Extra.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Items_Extra.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lbl_Excasso_Items_Extra.Location = New System.Drawing.Point(124, 18)
        Me.Lbl_Excasso_Items_Extra.Name = "Lbl_Excasso_Items_Extra"
        Me.Lbl_Excasso_Items_Extra.Size = New System.Drawing.Size(39, 29)
        Me.Lbl_Excasso_Items_Extra.TabIndex = 118
        Me.Lbl_Excasso_Items_Extra.Text = "0"
        Me.Lbl_Excasso_Items_Extra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_Excasso_Items_Extra.Visible = False
        '
        'Lbl_Excasso_Totalen
        '
        Me.Lbl_Excasso_Totalen.AutoSize = True
        Me.Lbl_Excasso_Totalen.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Totalen.Location = New System.Drawing.Point(22, 102)
        Me.Lbl_Excasso_Totalen.Name = "Lbl_Excasso_Totalen"
        Me.Lbl_Excasso_Totalen.Size = New System.Drawing.Size(142, 27)
        Me.Lbl_Excasso_Totalen.TabIndex = 94
        Me.Lbl_Excasso_Totalen.Text = "CP-vergoeding"
        '
        'Lbl_Excasso_Tot_Gen
        '
        Me.Lbl_Excasso_Tot_Gen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Tot_Gen.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Tot_Gen.Location = New System.Drawing.Point(248, 138)
        Me.Lbl_Excasso_Tot_Gen.Name = "Lbl_Excasso_Tot_Gen"
        Me.Lbl_Excasso_Tot_Gen.Size = New System.Drawing.Size(78, 37)
        Me.Lbl_Excasso_Tot_Gen.TabIndex = 115
        Me.Lbl_Excasso_Tot_Gen.Text = "0"
        Me.Lbl_Excasso_Tot_Gen.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Excasso_CP_Totaal
        '
        Me.Lbl_Excasso_CP_Totaal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_CP_Totaal.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_CP_Totaal.ForeColor = System.Drawing.Color.SeaGreen
        Me.Lbl_Excasso_CP_Totaal.Location = New System.Drawing.Point(248, 97)
        Me.Lbl_Excasso_CP_Totaal.Name = "Lbl_Excasso_CP_Totaal"
        Me.Lbl_Excasso_CP_Totaal.Size = New System.Drawing.Size(78, 35)
        Me.Lbl_Excasso_CP_Totaal.TabIndex = 123
        Me.Lbl_Excasso_CP_Totaal.Text = "0"
        Me.Lbl_Excasso_CP_Totaal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Excasso_Contractwaarde
        '
        Me.Lbl_Excasso_Contractwaarde.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Contractwaarde.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Contractwaarde.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Lbl_Excasso_Contractwaarde.Location = New System.Drawing.Point(165, 43)
        Me.Lbl_Excasso_Contractwaarde.Name = "Lbl_Excasso_Contractwaarde"
        Me.Lbl_Excasso_Contractwaarde.Size = New System.Drawing.Size(60, 25)
        Me.Lbl_Excasso_Contractwaarde.TabIndex = 78
        Me.Lbl_Excasso_Contractwaarde.Text = "0"
        Me.Lbl_Excasso_Contractwaarde.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Lbl_Excasso_Contractwaarde.Visible = False
        '
        'Lbl_Excasso_Tot_Gen_MLD
        '
        Me.Lbl_Excasso_Tot_Gen_MLD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Tot_Gen_MLD.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Tot_Gen_MLD.Location = New System.Drawing.Point(332, 138)
        Me.Lbl_Excasso_Tot_Gen_MLD.Name = "Lbl_Excasso_Tot_Gen_MLD"
        Me.Lbl_Excasso_Tot_Gen_MLD.Size = New System.Drawing.Size(94, 37)
        Me.Lbl_Excasso_Tot_Gen_MLD.TabIndex = 115
        Me.Lbl_Excasso_Tot_Gen_MLD.Text = "0"
        Me.Lbl_Excasso_Tot_Gen_MLD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Excasso_CP_Totaal_MDL
        '
        Me.Lbl_Excasso_CP_Totaal_MDL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_CP_Totaal_MDL.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_CP_Totaal_MDL.Location = New System.Drawing.Point(332, 97)
        Me.Lbl_Excasso_CP_Totaal_MDL.Name = "Lbl_Excasso_CP_Totaal_MDL"
        Me.Lbl_Excasso_CP_Totaal_MDL.Size = New System.Drawing.Size(94, 37)
        Me.Lbl_Excasso_CP_Totaal_MDL.TabIndex = 115
        Me.Lbl_Excasso_CP_Totaal_MDL.Text = "0"
        Me.Lbl_Excasso_CP_Totaal_MDL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Excasso_Totaal_MDL
        '
        Me.Lbl_Excasso_Totaal_MDL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Totaal_MDL.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Totaal_MDL.Location = New System.Drawing.Point(332, 52)
        Me.Lbl_Excasso_Totaal_MDL.Name = "Lbl_Excasso_Totaal_MDL"
        Me.Lbl_Excasso_Totaal_MDL.Size = New System.Drawing.Size(94, 37)
        Me.Lbl_Excasso_Totaal_MDL.TabIndex = 115
        Me.Lbl_Excasso_Totaal_MDL.Text = "0"
        Me.Lbl_Excasso_Totaal_MDL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.Location = New System.Drawing.Point(22, 57)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(120, 28)
        Me.Label89.TabIndex = 120
        Me.Label89.Text = "Uit te keren"
        '
        'Lbl_Excasso_Totaal
        '
        Me.Lbl_Excasso_Totaal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Lbl_Excasso_Totaal.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Totaal.Location = New System.Drawing.Point(248, 52)
        Me.Lbl_Excasso_Totaal.Name = "Lbl_Excasso_Totaal"
        Me.Lbl_Excasso_Totaal.Size = New System.Drawing.Size(78, 37)
        Me.Lbl_Excasso_Totaal.TabIndex = 115
        Me.Lbl_Excasso_Totaal.Text = "0"
        Me.Lbl_Excasso_Totaal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox4
        '
        Me.GroupBox4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GroupBox4.Controls.Add(Me.Label99)
        Me.GroupBox4.Controls.Add(Me.Lbl_Excasso_Contract)
        Me.GroupBox4.Controls.Add(Me.Tbx_Excasso_CP1)
        Me.GroupBox4.Controls.Add(Me.Label86)
        Me.GroupBox4.Controls.Add(Me.Tbx_Excasso_Norm1)
        Me.GroupBox4.Controls.Add(Me.Btn_Excasso_CP_Calculate)
        Me.GroupBox4.Controls.Add(Me.Tbx_Excasso_CP2)
        Me.GroupBox4.Controls.Add(Me.Btn_Excasso_Base1)
        Me.GroupBox4.Controls.Add(Me.Btn_Excasso_Base2)
        Me.GroupBox4.Controls.Add(Me.Btn_Excasso_Base3)
        Me.GroupBox4.Controls.Add(Me.Label98)
        Me.GroupBox4.Controls.Add(Me.Lbl_Excasso_Items_Totaal)
        Me.GroupBox4.Controls.Add(Me.Lbl_Excasso_Extr)
        Me.GroupBox4.Controls.Add(Me.Label139)
        Me.GroupBox4.Controls.Add(Me.Tbx_Excasso_Norm3)
        Me.GroupBox4.Controls.Add(Me.Tbx_Excasso_Norm2)
        Me.GroupBox4.Controls.Add(Me.Tbx_Excasso_CP3)
        Me.GroupBox4.Controls.Add(Me.Lbl_Excasso_Internal)
        Me.GroupBox4.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(651, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(432, 189)
        Me.GroupBox4.TabIndex = 117
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Bepaling CP vergoeding"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.Location = New System.Drawing.Point(290, 71)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(23, 28)
        Me.Label99.TabIndex = 128
        Me.Label99.Text = "="
        '
        'Lbl_Excasso_Contract
        '
        Me.Lbl_Excasso_Contract.AutoSize = True
        Me.Lbl_Excasso_Contract.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Contract.Location = New System.Drawing.Point(9, 31)
        Me.Lbl_Excasso_Contract.Name = "Lbl_Excasso_Contract"
        Me.Lbl_Excasso_Contract.Size = New System.Drawing.Size(93, 28)
        Me.Lbl_Excasso_Contract.TabIndex = 124
        Me.Lbl_Excasso_Contract.Text = "Contract"
        '
        'Tbx_Excasso_CP1
        '
        Me.Tbx_Excasso_CP1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Tbx_Excasso_CP1.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_CP1.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Excasso_CP1.Location = New System.Drawing.Point(318, 34)
        Me.Tbx_Excasso_CP1.Name = "Tbx_Excasso_CP1"
        Me.Tbx_Excasso_CP1.Size = New System.Drawing.Size(39, 27)
        Me.Tbx_Excasso_CP1.TabIndex = 80
        Me.Tbx_Excasso_CP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.Location = New System.Drawing.Point(290, 109)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(23, 28)
        Me.Label86.TabIndex = 127
        Me.Label86.Text = "="
        '
        'Tbx_Excasso_Norm1
        '
        Me.Tbx_Excasso_Norm1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Tbx_Excasso_Norm1.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_Norm1.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Excasso_Norm1.Location = New System.Drawing.Point(214, 34)
        Me.Tbx_Excasso_Norm1.Name = "Tbx_Excasso_Norm1"
        Me.Tbx_Excasso_Norm1.Size = New System.Drawing.Size(36, 27)
        Me.Tbx_Excasso_Norm1.TabIndex = 83
        Me.Tbx_Excasso_Norm1.Text = "4"
        Me.Tbx_Excasso_Norm1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_Excasso_CP_Calculate
        '
        Me.Btn_Excasso_CP_Calculate.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Btn_Excasso_CP_Calculate.Enabled = False
        Me.Btn_Excasso_CP_Calculate.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Excasso_CP_Calculate.Image = CType(resources.GetObject("Btn_Excasso_CP_Calculate.Image"), System.Drawing.Image)
        Me.Btn_Excasso_CP_Calculate.Location = New System.Drawing.Point(364, 125)
        Me.Btn_Excasso_CP_Calculate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_CP_Calculate.Name = "Btn_Excasso_CP_Calculate"
        Me.Btn_Excasso_CP_Calculate.Size = New System.Drawing.Size(45, 55)
        Me.Btn_Excasso_CP_Calculate.TabIndex = 114
        Me.Btn_Excasso_CP_Calculate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btn_Excasso_CP_Calculate.UseVisualStyleBackColor = True
        '
        'Tbx_Excasso_CP2
        '
        Me.Tbx_Excasso_CP2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Tbx_Excasso_CP2.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_CP2.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Excasso_CP2.Location = New System.Drawing.Point(318, 71)
        Me.Tbx_Excasso_CP2.Name = "Tbx_Excasso_CP2"
        Me.Tbx_Excasso_CP2.Size = New System.Drawing.Size(39, 27)
        Me.Tbx_Excasso_CP2.TabIndex = 80
        Me.Tbx_Excasso_CP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_Excasso_Base1
        '
        Me.Btn_Excasso_Base1.FlatAppearance.BorderSize = 0
        Me.Btn_Excasso_Base1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Excasso_Base1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Excasso_Base1.ForeColor = System.Drawing.Color.Blue
        Me.Btn_Excasso_Base1.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btn_Excasso_Base1.Location = New System.Drawing.Point(255, 28)
        Me.Btn_Excasso_Base1.Name = "Btn_Excasso_Base1"
        Me.Btn_Excasso_Base1.Size = New System.Drawing.Size(33, 52)
        Me.Btn_Excasso_Base1.TabIndex = 116
        Me.Btn_Excasso_Base1.Text = "€"
        Me.Btn_Excasso_Base1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Btn_Excasso_Base1.UseVisualStyleBackColor = True
        '
        'Btn_Excasso_Base2
        '
        Me.Btn_Excasso_Base2.FlatAppearance.BorderSize = 0
        Me.Btn_Excasso_Base2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Excasso_Base2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Excasso_Base2.ForeColor = System.Drawing.Color.Blue
        Me.Btn_Excasso_Base2.Location = New System.Drawing.Point(255, 65)
        Me.Btn_Excasso_Base2.Name = "Btn_Excasso_Base2"
        Me.Btn_Excasso_Base2.Size = New System.Drawing.Size(33, 45)
        Me.Btn_Excasso_Base2.TabIndex = 116
        Me.Btn_Excasso_Base2.Text = "€"
        Me.Btn_Excasso_Base2.UseVisualStyleBackColor = True
        '
        'Btn_Excasso_Base3
        '
        Me.Btn_Excasso_Base3.FlatAppearance.BorderSize = 0
        Me.Btn_Excasso_Base3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Excasso_Base3.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Excasso_Base3.ForeColor = System.Drawing.Color.Blue
        Me.Btn_Excasso_Base3.Location = New System.Drawing.Point(255, 102)
        Me.Btn_Excasso_Base3.Name = "Btn_Excasso_Base3"
        Me.Btn_Excasso_Base3.Size = New System.Drawing.Size(33, 40)
        Me.Btn_Excasso_Base3.TabIndex = 116
        Me.Btn_Excasso_Base3.Text = "€"
        Me.Btn_Excasso_Base3.UseVisualStyleBackColor = True
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.Location = New System.Drawing.Point(9, 146)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(209, 28)
        Me.Label98.TabIndex = 132
        Me.Label98.Text = "Aantal begunstigden:"
        '
        'Lbl_Excasso_Items_Totaal
        '
        Me.Lbl_Excasso_Items_Totaal.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Items_Totaal.Location = New System.Drawing.Point(213, 146)
        Me.Lbl_Excasso_Items_Totaal.Name = "Lbl_Excasso_Items_Totaal"
        Me.Lbl_Excasso_Items_Totaal.Size = New System.Drawing.Size(54, 32)
        Me.Lbl_Excasso_Items_Totaal.TabIndex = 76
        Me.Lbl_Excasso_Items_Totaal.Text = "0"
        Me.Lbl_Excasso_Items_Totaal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Excasso_Extr
        '
        Me.Lbl_Excasso_Extr.AutoSize = True
        Me.Lbl_Excasso_Extr.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Extr.Location = New System.Drawing.Point(6, 69)
        Me.Lbl_Excasso_Extr.Name = "Lbl_Excasso_Extr"
        Me.Lbl_Excasso_Extr.Size = New System.Drawing.Size(118, 28)
        Me.Lbl_Excasso_Extr.TabIndex = 77
        Me.Lbl_Excasso_Extr.Text = "Extra giften"
        '
        'Label139
        '
        Me.Label139.AutoSize = True
        Me.Label139.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label139.Location = New System.Drawing.Point(290, 34)
        Me.Label139.Name = "Label139"
        Me.Label139.Size = New System.Drawing.Size(23, 28)
        Me.Label139.TabIndex = 126
        Me.Label139.Text = "="
        '
        'Tbx_Excasso_Norm3
        '
        Me.Tbx_Excasso_Norm3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Tbx_Excasso_Norm3.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_Norm3.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Excasso_Norm3.Location = New System.Drawing.Point(214, 109)
        Me.Tbx_Excasso_Norm3.Name = "Tbx_Excasso_Norm3"
        Me.Tbx_Excasso_Norm3.Size = New System.Drawing.Size(36, 27)
        Me.Tbx_Excasso_Norm3.TabIndex = 84
        Me.Tbx_Excasso_Norm3.Text = "3"
        Me.Tbx_Excasso_Norm3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_Excasso_Norm2
        '
        Me.Tbx_Excasso_Norm2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Tbx_Excasso_Norm2.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_Norm2.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Excasso_Norm2.Location = New System.Drawing.Point(214, 71)
        Me.Tbx_Excasso_Norm2.Name = "Tbx_Excasso_Norm2"
        Me.Tbx_Excasso_Norm2.Size = New System.Drawing.Size(36, 27)
        Me.Tbx_Excasso_Norm2.TabIndex = 82
        Me.Tbx_Excasso_Norm2.Text = "3"
        Me.Tbx_Excasso_Norm2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_Excasso_CP3
        '
        Me.Tbx_Excasso_CP3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Tbx_Excasso_CP3.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_Excasso_CP3.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Excasso_CP3.Location = New System.Drawing.Point(318, 109)
        Me.Tbx_Excasso_CP3.Name = "Tbx_Excasso_CP3"
        Me.Tbx_Excasso_CP3.Size = New System.Drawing.Size(39, 27)
        Me.Tbx_Excasso_CP3.TabIndex = 80
        Me.Tbx_Excasso_CP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Lbl_Excasso_Internal
        '
        Me.Lbl_Excasso_Internal.AutoSize = True
        Me.Lbl_Excasso_Internal.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Excasso_Internal.Location = New System.Drawing.Point(6, 109)
        Me.Lbl_Excasso_Internal.Name = "Lbl_Excasso_Internal"
        Me.Lbl_Excasso_Internal.Size = New System.Drawing.Size(172, 28)
        Me.Lbl_Excasso_Internal.TabIndex = 78
        Me.Lbl_Excasso_Internal.Text = "Fondsuitkeringen"
        '
        'Btn_Excasso_Save
        '
        Me.Btn_Excasso_Save.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Excasso_Save.Image = CType(resources.GetObject("Btn_Excasso_Save.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Save.Location = New System.Drawing.Point(669, 880)
        Me.Btn_Excasso_Save.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Save.Name = "Btn_Excasso_Save"
        Me.Btn_Excasso_Save.Size = New System.Drawing.Size(52, 55)
        Me.Btn_Excasso_Save.TabIndex = 96
        Me.Btn_Excasso_Save.UseVisualStyleBackColor = True
        '
        'Btn_Excasso_Print
        '
        Me.Btn_Excasso_Print.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Excasso_Print.Image = CType(resources.GetObject("Btn_Excasso_Print.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Print.Location = New System.Drawing.Point(606, 880)
        Me.Btn_Excasso_Print.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Print.Name = "Btn_Excasso_Print"
        Me.Btn_Excasso_Print.Size = New System.Drawing.Size(52, 55)
        Me.Btn_Excasso_Print.TabIndex = 98
        Me.Btn_Excasso_Print.UseVisualStyleBackColor = True
        '
        'Btn_Excasso_Cancel
        '
        Me.Btn_Excasso_Cancel.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Excasso_Cancel.Enabled = False
        Me.Btn_Excasso_Cancel.Image = CType(resources.GetObject("Btn_Excasso_Cancel.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Cancel.Location = New System.Drawing.Point(483, 880)
        Me.Btn_Excasso_Cancel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Cancel.Name = "Btn_Excasso_Cancel"
        Me.Btn_Excasso_Cancel.Size = New System.Drawing.Size(52, 55)
        Me.Btn_Excasso_Cancel.TabIndex = 115
        Me.Btn_Excasso_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Excasso_Delete
        '
        Me.Btn_Excasso_Delete.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Btn_Excasso_Delete.Image = CType(resources.GetObject("Btn_Excasso_Delete.Image"), System.Drawing.Image)
        Me.Btn_Excasso_Delete.Location = New System.Drawing.Point(546, 880)
        Me.Btn_Excasso_Delete.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Excasso_Delete.Name = "Btn_Excasso_Delete"
        Me.Btn_Excasso_Delete.Size = New System.Drawing.Size(52, 55)
        Me.Btn_Excasso_Delete.TabIndex = 97
        Me.Btn_Excasso_Delete.UseVisualStyleBackColor = True
        '
        'Incasso
        '
        Me.Incasso.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Incasso.Controls.Add(Me.Panel3)
        Me.Incasso.Controls.Add(Me.Dgv_Incasso)
        Me.Incasso.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Incasso.Location = New System.Drawing.Point(4, 38)
        Me.Incasso.Name = "Incasso"
        Me.Incasso.Padding = New System.Windows.Forms.Padding(3)
        Me.Incasso.Size = New System.Drawing.Size(1618, 889)
        Me.Incasso.TabIndex = 2
        Me.Incasso.Text = "Incasso   "
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel10)
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.Dtp_Incasso_end)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(3, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(441, 883)
        Me.Panel3.TabIndex = 100
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.Dgv_incasso_totals)
        Me.Panel10.Controls.Add(Me.Label79)
        Me.Panel10.Controls.Add(Me.Lbl_Incasso_Error)
        Me.Panel10.Location = New System.Drawing.Point(4, 346)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(417, 445)
        Me.Panel10.TabIndex = 103
        '
        'Dgv_incasso_totals
        '
        Me.Dgv_incasso_totals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_incasso_totals.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.Dgv_incasso_totals.Location = New System.Drawing.Point(21, 32)
        Me.Dgv_incasso_totals.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_incasso_totals.Name = "Dgv_incasso_totals"
        Me.Dgv_incasso_totals.ReadOnly = True
        Me.Dgv_incasso_totals.RowHeadersVisible = False
        Me.Dgv_incasso_totals.RowHeadersWidth = 62
        Me.Dgv_incasso_totals.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.Dgv_incasso_totals.ShowEditingIcon = False
        Me.Dgv_incasso_totals.Size = New System.Drawing.Size(363, 178)
        Me.Dgv_incasso_totals.TabIndex = 78
        '
        'Label79
        '
        Me.Label79.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.Location = New System.Drawing.Point(16, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(80, 28)
        Me.Label79.TabIndex = 71
        Me.Label79.Text = "Totalen"
        '
        'Lbl_Incasso_Error
        '
        Me.Lbl_Incasso_Error.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Lbl_Incasso_Error.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Lbl_Incasso_Error.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Incasso_Error.ForeColor = System.Drawing.Color.Firebrick
        Me.Lbl_Incasso_Error.Location = New System.Drawing.Point(21, 260)
        Me.Lbl_Incasso_Error.Name = "Lbl_Incasso_Error"
        Me.Lbl_Incasso_Error.Size = New System.Drawing.Size(392, 166)
        Me.Lbl_Incasso_Error.TabIndex = 77
        Me.Lbl_Incasso_Error.Text = "Error"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Rbn_Incasso_Verschillen)
        Me.Panel5.Controls.Add(Me.Dtp_Incasso_start)
        Me.Panel5.Controls.Add(Me.Cmx_Incasso_Bankaccount)
        Me.Panel5.Controls.Add(Me.Label9)
        Me.Panel5.Controls.Add(Me.Rbn_Incasso_SEPA)
        Me.Panel5.Controls.Add(Me.Label145)
        Me.Panel5.Controls.Add(Me.Label94)
        Me.Panel5.Controls.Add(Me.Rbn_Incasso_journal)
        Me.Panel5.Controls.Add(Me.Label71)
        Me.Panel5.Controls.Add(Me.Lbl_Incasso_Status)
        Me.Panel5.Controls.Add(Me.Label82)
        Me.Panel5.Controls.Add(Me.Lbl_Incasso_job_name)
        Me.Panel5.Location = New System.Drawing.Point(4, 5)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(423, 320)
        Me.Panel5.TabIndex = 101
        '
        'Rbn_Incasso_Verschillen
        '
        Me.Rbn_Incasso_Verschillen.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Rbn_Incasso_Verschillen.AutoSize = True
        Me.Rbn_Incasso_Verschillen.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Rbn_Incasso_Verschillen.Location = New System.Drawing.Point(144, 278)
        Me.Rbn_Incasso_Verschillen.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Incasso_Verschillen.Name = "Rbn_Incasso_Verschillen"
        Me.Rbn_Incasso_Verschillen.Size = New System.Drawing.Size(143, 29)
        Me.Rbn_Incasso_Verschillen.TabIndex = 103
        Me.Rbn_Incasso_Verschillen.Text = "Verschillen"
        Me.Rbn_Incasso_Verschillen.UseVisualStyleBackColor = False
        '
        'Dtp_Incasso_start
        '
        Me.Dtp_Incasso_start.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Dtp_Incasso_start.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Incasso_start.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.Dtp_Incasso_start.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Incasso_start.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_Incasso_start.Location = New System.Drawing.Point(132, 14)
        Me.Dtp_Incasso_start.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_Incasso_start.MinDate = New Date(2020, 1, 1, 0, 0, 0, 0)
        Me.Dtp_Incasso_start.Name = "Dtp_Incasso_start"
        Me.Dtp_Incasso_start.ShowUpDown = True
        Me.Dtp_Incasso_start.Size = New System.Drawing.Size(278, 46)
        Me.Dtp_Incasso_start.TabIndex = 65
        Me.Dtp_Incasso_start.Value = New Date(2020, 1, 1, 0, 0, 0, 0)
        '
        'Cmx_Incasso_Bankaccount
        '
        Me.Cmx_Incasso_Bankaccount.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cmx_Incasso_Bankaccount.FormattingEnabled = True
        Me.Cmx_Incasso_Bankaccount.Location = New System.Drawing.Point(132, 72)
        Me.Cmx_Incasso_Bankaccount.Name = "Cmx_Incasso_Bankaccount"
        Me.Cmx_Incasso_Bankaccount.Size = New System.Drawing.Size(278, 33)
        Me.Cmx_Incasso_Bankaccount.TabIndex = 79
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(16, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 28)
        Me.Label9.TabIndex = 66
        Me.Label9.Text = "Maand"
        '
        'Rbn_Incasso_SEPA
        '
        Me.Rbn_Incasso_SEPA.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Rbn_Incasso_SEPA.AutoSize = True
        Me.Rbn_Incasso_SEPA.Checked = True
        Me.Rbn_Incasso_SEPA.Location = New System.Drawing.Point(144, 211)
        Me.Rbn_Incasso_SEPA.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Incasso_SEPA.Name = "Rbn_Incasso_SEPA"
        Me.Rbn_Incasso_SEPA.Size = New System.Drawing.Size(93, 29)
        Me.Rbn_Incasso_SEPA.TabIndex = 73
        Me.Rbn_Incasso_SEPA.TabStop = True
        Me.Rbn_Incasso_SEPA.Text = "SEPA"
        Me.Rbn_Incasso_SEPA.UseVisualStyleBackColor = True
        '
        'Label145
        '
        Me.Label145.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label145.AutoSize = True
        Me.Label145.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label145.Location = New System.Drawing.Point(16, 72)
        Me.Label145.Name = "Label145"
        Me.Label145.Size = New System.Drawing.Size(95, 28)
        Me.Label145.TabIndex = 78
        Me.Label145.Text = "Rekening"
        '
        'Label94
        '
        Me.Label94.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.Location = New System.Drawing.Point(20, 118)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(100, 28)
        Me.Label94.TabIndex = 68
        Me.Label94.Text = "Job naam"
        '
        'Rbn_Incasso_journal
        '
        Me.Rbn_Incasso_journal.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Rbn_Incasso_journal.AutoSize = True
        Me.Rbn_Incasso_journal.Location = New System.Drawing.Point(144, 245)
        Me.Rbn_Incasso_journal.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Incasso_journal.Name = "Rbn_Incasso_journal"
        Me.Rbn_Incasso_journal.Size = New System.Drawing.Size(185, 29)
        Me.Rbn_Incasso_journal.TabIndex = 73
        Me.Rbn_Incasso_journal.Text = "Journaalposten"
        Me.Rbn_Incasso_journal.UseVisualStyleBackColor = True
        '
        'Label71
        '
        Me.Label71.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(20, 162)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(71, 28)
        Me.Label71.TabIndex = 68
        Me.Label71.Text = "Status"
        '
        'Lbl_Incasso_Status
        '
        Me.Lbl_Incasso_Status.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Lbl_Incasso_Status.AutoSize = True
        Me.Lbl_Incasso_Status.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Incasso_Status.Location = New System.Drawing.Point(140, 162)
        Me.Lbl_Incasso_Status.Name = "Lbl_Incasso_Status"
        Me.Lbl_Incasso_Status.Size = New System.Drawing.Size(70, 27)
        Me.Lbl_Incasso_Status.TabIndex = 69
        Me.Lbl_Incasso_Status.Text = "Status"
        '
        'Label82
        '
        Me.Label82.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.Location = New System.Drawing.Point(20, 212)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(57, 28)
        Me.Label82.TabIndex = 72
        Me.Label82.Text = "Toon"
        '
        'Lbl_Incasso_job_name
        '
        Me.Lbl_Incasso_job_name.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Lbl_Incasso_job_name.AutoSize = True
        Me.Lbl_Incasso_job_name.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Incasso_job_name.Location = New System.Drawing.Point(140, 118)
        Me.Lbl_Incasso_job_name.Name = "Lbl_Incasso_job_name"
        Me.Lbl_Incasso_job_name.Size = New System.Drawing.Size(100, 28)
        Me.Lbl_Incasso_job_name.TabIndex = 69
        Me.Lbl_Incasso_job_name.Text = "Job naam"
        '
        'Dtp_Incasso_end
        '
        Me.Dtp_Incasso_end.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Dtp_Incasso_end.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.Dtp_Incasso_end.Enabled = False
        Me.Dtp_Incasso_end.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_Incasso_end.Location = New System.Drawing.Point(9, 818)
        Me.Dtp_Incasso_end.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_Incasso_end.Name = "Dtp_Incasso_end"
        Me.Dtp_Incasso_end.Size = New System.Drawing.Size(138, 30)
        Me.Dtp_Incasso_end.TabIndex = 67
        Me.Dtp_Incasso_end.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        Me.Dtp_Incasso_end.Visible = False
        '
        'Dgv_Incasso
        '
        Me.Dgv_Incasso.AllowUserToAddRows = False
        Me.Dgv_Incasso.AllowUserToDeleteRows = False
        DataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        DataGridViewCellStyle19.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle19.NullValue = " -"
        Me.Dgv_Incasso.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle19
        Me.Dgv_Incasso.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Incasso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle20.NullValue = "-"
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dgv_Incasso.DefaultCellStyle = DataGridViewCellStyle20
        Me.Dgv_Incasso.Location = New System.Drawing.Point(450, 8)
        Me.Dgv_Incasso.MultiSelect = False
        Me.Dgv_Incasso.Name = "Dgv_Incasso"
        Me.Dgv_Incasso.ReadOnly = True
        Me.Dgv_Incasso.RowHeadersVisible = False
        Me.Dgv_Incasso.RowHeadersWidth = 30
        Me.Dgv_Incasso.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Incasso.RowTemplate.Height = 20
        Me.Dgv_Incasso.RowTemplate.ReadOnly = True
        Me.Dgv_Incasso.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgv_Incasso.Size = New System.Drawing.Size(1108, 838)
        Me.Dgv_Incasso.TabIndex = 4
        '
        'Tab_Bank
        '
        Me.Tab_Bank.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Tab_Bank.Controls.Add(Me.Pan_Bank2)
        Me.Tab_Bank.Controls.Add(Me.Pan_Bank)
        Me.Tab_Bank.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tab_Bank.Location = New System.Drawing.Point(4, 38)
        Me.Tab_Bank.Name = "Tab_Bank"
        Me.Tab_Bank.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_Bank.Size = New System.Drawing.Size(1618, 889)
        Me.Tab_Bank.TabIndex = 1
        Me.Tab_Bank.Text = "Bank   "
        '
        'Pan_Bank2
        '
        Me.Pan_Bank2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pan_Bank2.Controls.Add(Me.Dgv_Bank)
        Me.Pan_Bank2.Location = New System.Drawing.Point(475, 0)
        Me.Pan_Bank2.Name = "Pan_Bank2"
        Me.Pan_Bank2.Size = New System.Drawing.Size(1137, 889)
        Me.Pan_Bank2.TabIndex = 58
        '
        'Dgv_Bank
        '
        Me.Dgv_Bank.AllowUserToAddRows = False
        Me.Dgv_Bank.AllowUserToDeleteRows = False
        DataGridViewCellStyle21.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle21.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle21.NullValue = " -"
        Me.Dgv_Bank.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle21
        Me.Dgv_Bank.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Bank.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle22.NullValue = "-"
        DataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dgv_Bank.DefaultCellStyle = DataGridViewCellStyle22
        Me.Dgv_Bank.Location = New System.Drawing.Point(3, 6)
        Me.Dgv_Bank.MultiSelect = False
        Me.Dgv_Bank.Name = "Dgv_Bank"
        Me.Dgv_Bank.ReadOnly = True
        Me.Dgv_Bank.RowHeadersVisible = False
        Me.Dgv_Bank.RowHeadersWidth = 30
        Me.Dgv_Bank.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Bank.RowTemplate.Height = 20
        Me.Dgv_Bank.RowTemplate.ReadOnly = True
        Me.Dgv_Bank.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgv_Bank.Size = New System.Drawing.Size(1137, 877)
        Me.Dgv_Bank.TabIndex = 3
        '
        'Pan_Bank
        '
        Me.Pan_Bank.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Pan_Bank.Controls.Add(Me.Panel6)
        Me.Pan_Bank.Controls.Add(Me.Chbx_Bank_ExtraInfo_achter)
        Me.Pan_Bank.Controls.Add(Me.Chbx_Bank_ExtraInfo_voor)
        Me.Pan_Bank.Controls.Add(Me.Lbl_Bank_Extra_Info)
        Me.Pan_Bank.Controls.Add(Me.Tbx_Bank_Extra_Info)
        Me.Pan_Bank.Controls.Add(Me.Cmx_Bank_bankacc)
        Me.Pan_Bank.Controls.Add(Me.Label63)
        Me.Pan_Bank.Controls.Add(Me.Dgv_Bank_Account)
        Me.Pan_Bank.Controls.Add(Me.Tbx_Bank_Search)
        Me.Pan_Bank.Controls.Add(Me.CheckBox1)
        Me.Pan_Bank.Controls.Add(Me.Tbx_Bank_Description)
        Me.Pan_Bank.Controls.Add(Me.Label8)
        Me.Pan_Bank.Controls.Add(Me.Dgv_Bank_Account2)
        Me.Pan_Bank.Controls.Add(Me.Label100)
        Me.Pan_Bank.Controls.Add(Me.Cmx_Bank_Account)
        Me.Pan_Bank.Controls.Add(Me.Btn_Bank_Add_Journal)
        Me.Pan_Bank.Controls.Add(Me.Tbx_Bank_Amount)
        Me.Pan_Bank.Controls.Add(Me.Lbl_Bank_Saldo)
        Me.Pan_Bank.Controls.Add(Me.Btn_Bank_Split)
        Me.Pan_Bank.Controls.Add(Me.Label76)
        Me.Pan_Bank.Controls.Add(Me.Pan_Bank_jtype)
        Me.Pan_Bank.Location = New System.Drawing.Point(3, 0)
        Me.Pan_Bank.Name = "Pan_Bank"
        Me.Pan_Bank.Size = New System.Drawing.Size(466, 883)
        Me.Pan_Bank.TabIndex = 47
        '
        'Chbx_Bank_ExtraInfo_achter
        '
        Me.Chbx_Bank_ExtraInfo_achter.AutoSize = True
        Me.Chbx_Bank_ExtraInfo_achter.Enabled = False
        Me.Chbx_Bank_ExtraInfo_achter.Location = New System.Drawing.Point(218, 430)
        Me.Chbx_Bank_ExtraInfo_achter.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Chbx_Bank_ExtraInfo_achter.Name = "Chbx_Bank_ExtraInfo_achter"
        Me.Chbx_Bank_ExtraInfo_achter.Size = New System.Drawing.Size(223, 29)
        Me.Chbx_Bank_ExtraInfo_achter.TabIndex = 56
        Me.Chbx_Bank_ExtraInfo_achter.Text = "achter omschrijving"
        Me.Chbx_Bank_ExtraInfo_achter.UseVisualStyleBackColor = True
        '
        'Chbx_Bank_ExtraInfo_voor
        '
        Me.Chbx_Bank_ExtraInfo_voor.AutoSize = True
        Me.Chbx_Bank_ExtraInfo_voor.Checked = True
        Me.Chbx_Bank_ExtraInfo_voor.Location = New System.Drawing.Point(130, 430)
        Me.Chbx_Bank_ExtraInfo_voor.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Chbx_Bank_ExtraInfo_voor.Name = "Chbx_Bank_ExtraInfo_voor"
        Me.Chbx_Bank_ExtraInfo_voor.Size = New System.Drawing.Size(79, 29)
        Me.Chbx_Bank_ExtraInfo_voor.TabIndex = 55
        Me.Chbx_Bank_ExtraInfo_voor.TabStop = True
        Me.Chbx_Bank_ExtraInfo_voor.Text = "vóór"
        Me.Chbx_Bank_ExtraInfo_voor.UseVisualStyleBackColor = True
        '
        'Lbl_Bank_Extra_Info
        '
        Me.Lbl_Bank_Extra_Info.AutoSize = True
        Me.Lbl_Bank_Extra_Info.Location = New System.Drawing.Point(6, 433)
        Me.Lbl_Bank_Extra_Info.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Bank_Extra_Info.Name = "Lbl_Bank_Extra_Info"
        Me.Lbl_Bank_Extra_Info.Size = New System.Drawing.Size(103, 25)
        Me.Lbl_Bank_Extra_Info.TabIndex = 54
        Me.Lbl_Bank_Extra_Info.Text = "Extra info"
        '
        'Tbx_Bank_Extra_Info
        '
        Me.Tbx_Bank_Extra_Info.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Tbx_Bank_Extra_Info.ForeColor = System.Drawing.Color.Blue
        Me.Tbx_Bank_Extra_Info.Location = New System.Drawing.Point(15, 462)
        Me.Tbx_Bank_Extra_Info.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_Bank_Extra_Info.Multiline = True
        Me.Tbx_Bank_Extra_Info.Name = "Tbx_Bank_Extra_Info"
        Me.Tbx_Bank_Extra_Info.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_Bank_Extra_Info.Size = New System.Drawing.Size(430, 50)
        Me.Tbx_Bank_Extra_Info.TabIndex = 53
        '
        'Cmx_Bank_bankacc
        '
        Me.Cmx_Bank_bankacc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cmx_Bank_bankacc.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmx_Bank_bankacc.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmx_Bank_bankacc.FormattingEnabled = True
        Me.Cmx_Bank_bankacc.Location = New System.Drawing.Point(11, 5)
        Me.Cmx_Bank_bankacc.Name = "Cmx_Bank_bankacc"
        Me.Cmx_Bank_bankacc.Size = New System.Drawing.Size(438, 36)
        Me.Cmx_Bank_bankacc.TabIndex = 21
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(33, 940)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(114, 25)
        Me.Label63.TabIndex = 22
        Me.Label63.Text = "Zoeken op"
        Me.Label63.Visible = False
        '
        'Dgv_Bank_Account
        '
        Me.Dgv_Bank_Account.AllowUserToAddRows = False
        Me.Dgv_Bank_Account.AllowUserToDeleteRows = False
        DataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Dgv_Bank_Account.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle23
        Me.Dgv_Bank_Account.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dgv_Bank_Account.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dgv_Bank_Account.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Bank_Account.Location = New System.Drawing.Point(6, 602)
        Me.Dgv_Bank_Account.Name = "Dgv_Bank_Account"
        Me.Dgv_Bank_Account.RowHeadersVisible = False
        Me.Dgv_Bank_Account.RowHeadersWidth = 50
        DataGridViewCellStyle24.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgv_Bank_Account.RowsDefaultCellStyle = DataGridViewCellStyle24
        Me.Dgv_Bank_Account.RowTemplate.Height = 20
        Me.Dgv_Bank_Account.Size = New System.Drawing.Size(443, 273)
        Me.Dgv_Bank_Account.TabIndex = 37
        '
        'Tbx_Bank_Search
        '
        Me.Tbx_Bank_Search.Location = New System.Drawing.Point(156, 940)
        Me.Tbx_Bank_Search.Name = "Tbx_Bank_Search"
        Me.Tbx_Bank_Search.Size = New System.Drawing.Size(58, 30)
        Me.Tbx_Bank_Search.TabIndex = 23
        Me.Tbx_Bank_Search.Visible = False
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Enabled = False
        Me.CheckBox1.Location = New System.Drawing.Point(10, 966)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(211, 29)
        Me.CheckBox1.TabIndex = 24
        Me.CheckBox1.Text = "Alleen ongecateg."
        Me.CheckBox1.UseVisualStyleBackColor = True
        Me.CheckBox1.Visible = False
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 313)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(136, 25)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Omschrijving"
        '
        'Dgv_Bank_Account2
        '
        Me.Dgv_Bank_Account2.AllowUserToAddRows = False
        Me.Dgv_Bank_Account2.AllowUserToDeleteRows = False
        Me.Dgv_Bank_Account2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Bank_Account2.Location = New System.Drawing.Point(10, 908)
        Me.Dgv_Bank_Account2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_Bank_Account2.Name = "Dgv_Bank_Account2"
        Me.Dgv_Bank_Account2.RowHeadersWidth = 82
        Me.Dgv_Bank_Account2.Size = New System.Drawing.Size(110, 28)
        Me.Dgv_Bank_Account2.TabIndex = 44
        Me.Dgv_Bank_Account2.Visible = False
        '
        'Label100
        '
        Me.Label100.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.Location = New System.Drawing.Point(4, 58)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(143, 25)
        Me.Label100.TabIndex = 43
        Me.Label100.Text = "Actueel saldo"
        '
        'Cmx_Bank_Account
        '
        Me.Cmx_Bank_Account.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Cmx_Bank_Account.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cmx_Bank_Account.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cmx_Bank_Account.FormattingEnabled = True
        Me.Cmx_Bank_Account.Location = New System.Drawing.Point(108, 563)
        Me.Cmx_Bank_Account.Name = "Cmx_Bank_Account"
        Me.Cmx_Bank_Account.Size = New System.Drawing.Size(283, 33)
        Me.Cmx_Bank_Account.TabIndex = 32
        '
        'Btn_Bank_Add_Journal
        '
        Me.Btn_Bank_Add_Journal.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Btn_Bank_Add_Journal.Image = CType(resources.GetObject("Btn_Bank_Add_Journal.Image"), System.Drawing.Image)
        Me.Btn_Bank_Add_Journal.Location = New System.Drawing.Point(355, 120)
        Me.Btn_Bank_Add_Journal.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Bank_Add_Journal.Name = "Btn_Bank_Add_Journal"
        Me.Btn_Bank_Add_Journal.Size = New System.Drawing.Size(48, 38)
        Me.Btn_Bank_Add_Journal.TabIndex = 35
        Me.Btn_Bank_Add_Journal.UseVisualStyleBackColor = True
        Me.Btn_Bank_Add_Journal.Visible = False
        '
        'Tbx_Bank_Amount
        '
        Me.Tbx_Bank_Amount.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Bank_Amount.Location = New System.Drawing.Point(364, 55)
        Me.Tbx_Bank_Amount.Name = "Tbx_Bank_Amount"
        Me.Tbx_Bank_Amount.Size = New System.Drawing.Size(85, 30)
        Me.Tbx_Bank_Amount.TabIndex = 34
        Me.Tbx_Bank_Amount.Visible = False
        '
        'Lbl_Bank_Saldo
        '
        Me.Lbl_Bank_Saldo.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Lbl_Bank_Saldo.AutoSize = True
        Me.Lbl_Bank_Saldo.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Bank_Saldo.Location = New System.Drawing.Point(172, 55)
        Me.Lbl_Bank_Saldo.Name = "Lbl_Bank_Saldo"
        Me.Lbl_Bank_Saldo.Size = New System.Drawing.Size(55, 29)
        Me.Lbl_Bank_Saldo.TabIndex = 32
        Me.Lbl_Bank_Saldo.Text = "0,00"
        Me.Lbl_Bank_Saldo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Btn_Bank_Split
        '
        Me.Btn_Bank_Split.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Btn_Bank_Split.Image = CType(resources.GetObject("Btn_Bank_Split.Image"), System.Drawing.Image)
        Me.Btn_Bank_Split.Location = New System.Drawing.Point(398, 559)
        Me.Btn_Bank_Split.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Btn_Bank_Split.Name = "Btn_Bank_Split"
        Me.Btn_Bank_Split.Size = New System.Drawing.Size(48, 38)
        Me.Btn_Bank_Split.TabIndex = 45
        Me.Btn_Bank_Split.UseVisualStyleBackColor = True
        '
        'Label76
        '
        Me.Label76.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.Location = New System.Drawing.Point(6, 566)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(91, 27)
        Me.Label76.TabIndex = 30
        Me.Label76.Text = "Categorie"
        '
        'Pan_Bank_jtype
        '
        Me.Pan_Bank_jtype.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Pan_Bank_jtype.Controls.Add(Me.Label150)
        Me.Pan_Bank_jtype.Controls.Add(Me.Rbn_Bank_jtype_con)
        Me.Pan_Bank_jtype.Controls.Add(Me.Rbn_Bank_jtype_int)
        Me.Pan_Bank_jtype.Controls.Add(Me.Rbn_Bank_jtype_ext)
        Me.Pan_Bank_jtype.Location = New System.Drawing.Point(10, 524)
        Me.Pan_Bank_jtype.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pan_Bank_jtype.Name = "Pan_Bank_jtype"
        Me.Pan_Bank_jtype.Size = New System.Drawing.Size(439, 37)
        Me.Pan_Bank_jtype.TabIndex = 52
        Me.Pan_Bank_jtype.Visible = False
        '
        'Label150
        '
        Me.Label150.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label150.AutoSize = True
        Me.Label150.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label150.Location = New System.Drawing.Point(3, 2)
        Me.Label150.Name = "Label150"
        Me.Label150.Size = New System.Drawing.Size(53, 27)
        Me.Label150.TabIndex = 53
        Me.Label150.Text = "Type"
        '
        'Rbn_Bank_jtype_con
        '
        Me.Rbn_Bank_jtype_con.AutoSize = True
        Me.Rbn_Bank_jtype_con.Location = New System.Drawing.Point(63, 1)
        Me.Rbn_Bank_jtype_con.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Bank_jtype_con.Name = "Rbn_Bank_jtype_con"
        Me.Rbn_Bank_jtype_con.Size = New System.Drawing.Size(118, 29)
        Me.Rbn_Bank_jtype_con.TabIndex = 49
        Me.Rbn_Bank_jtype_con.TabStop = True
        Me.Rbn_Bank_jtype_con.Text = "Contract"
        Me.Rbn_Bank_jtype_con.UseVisualStyleBackColor = True
        '
        'Rbn_Bank_jtype_int
        '
        Me.Rbn_Bank_jtype_int.AutoSize = True
        Me.Rbn_Bank_jtype_int.Location = New System.Drawing.Point(270, 1)
        Me.Rbn_Bank_jtype_int.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Bank_jtype_int.Name = "Rbn_Bank_jtype_int"
        Me.Rbn_Bank_jtype_int.Size = New System.Drawing.Size(165, 29)
        Me.Rbn_Bank_jtype_int.TabIndex = 51
        Me.Rbn_Bank_jtype_int.TabStop = True
        Me.Rbn_Bank_jtype_int.Text = "Anders/intern"
        Me.Rbn_Bank_jtype_int.UseVisualStyleBackColor = True
        '
        'Rbn_Bank_jtype_ext
        '
        Me.Rbn_Bank_jtype_ext.AutoSize = True
        Me.Rbn_Bank_jtype_ext.Location = New System.Drawing.Point(182, 1)
        Me.Rbn_Bank_jtype_ext.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_Bank_jtype_ext.Name = "Rbn_Bank_jtype_ext"
        Me.Rbn_Bank_jtype_ext.Size = New System.Drawing.Size(87, 29)
        Me.Rbn_Bank_jtype_ext.TabIndex = 50
        Me.Rbn_Bank_jtype_ext.TabStop = True
        Me.Rbn_Bank_jtype_ext.Text = "Extra"
        Me.Rbn_Bank_jtype_ext.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.TC_Object)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 38)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1618, 889)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Basisadministratie   "
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Panel1.Controls.Add(Me.Lbx_Basis)
        Me.Panel1.Location = New System.Drawing.Point(6, 23)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(411, 843)
        Me.Panel1.TabIndex = 99
        '
        'Lbx_Basis
        '
        Me.Lbx_Basis.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Lbx_Basis.FormattingEnabled = True
        Me.Lbx_Basis.ItemHeight = 25
        Me.Lbx_Basis.Location = New System.Drawing.Point(0, 0)
        Me.Lbx_Basis.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Lbx_Basis.Name = "Lbx_Basis"
        Me.Lbx_Basis.Size = New System.Drawing.Size(404, 804)
        Me.Lbx_Basis.TabIndex = 17
        '
        'TC_Object
        '
        Me.TC_Object.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TC_Object.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TC_Object.Controls.Add(Me.Contract)
        Me.TC_Object.Controls.Add(Me.target)
        Me.TC_Object.Controls.Add(Me.Relation)
        Me.TC_Object.Controls.Add(Me.CP)
        Me.TC_Object.Controls.Add(Me.Account)
        Me.TC_Object.Controls.Add(Me.Accgroup)
        Me.TC_Object.Controls.Add(Me.BankAcc)
        Me.TC_Object.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TC_Object.Location = New System.Drawing.Point(423, 25)
        Me.TC_Object.Name = "TC_Object"
        Me.TC_Object.SelectedIndex = 0
        Me.TC_Object.Size = New System.Drawing.Size(1160, 848)
        Me.TC_Object.TabIndex = 7
        Me.TC_Object.Tag = "Doel"
        '
        'Contract
        '
        Me.Contract.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Contract.Controls.Add(Me.Lbl_Rel_id)
        Me.Contract.Controls.Add(Me.Lbl_Contract_tgt)
        Me.Contract.Controls.Add(Me.Label96)
        Me.Contract.Controls.Add(Me.Lbl_Contract_Bronaccount)
        Me.Contract.Controls.Add(Me.Cmx_00_Contract__fk_account_id)
        Me.Contract.Controls.Add(Me.Tbx_Contract_ttype)
        Me.Contract.Controls.Add(Me.Cbx_00_contract__active)
        Me.Contract.Controls.Add(Me.Lbl_contract_mach_datum)
        Me.Contract.Controls.Add(Me.Lbl_contract_macht_kenm)
        Me.Contract.Controls.Add(Me.Pan_Contract_Date_New)
        Me.Contract.Controls.Add(Me.Lbl_00_contract_doeltype)
        Me.Contract.Controls.Add(Me.Pan_contract_select_target)
        Me.Contract.Controls.Add(Me.Lbl_00_contract_autcol)
        Me.Contract.Controls.Add(Me.Pic_Contract_Target_photo)
        Me.Contract.Controls.Add(Me.Label85)
        Me.Contract.Controls.Add(Me.dtp_contract_relation_date)
        Me.Contract.Controls.Add(Me.Label80)
        Me.Contract.Controls.Add(Me.Label84)
        Me.Contract.Controls.Add(Me.Label77)
        Me.Contract.Controls.Add(Me.Label74)
        Me.Contract.Controls.Add(Me.Lbl_00_Contract__name)
        Me.Contract.Controls.Add(Me.Lbl_Contract_pkid)
        Me.Contract.Controls.Add(Me.Label70)
        Me.Contract.Controls.Add(Me.Cmx_00_contract__fk_relation_id)
        Me.Contract.Controls.Add(Me.Cmx_01_contract__fk_target_id)
        Me.Contract.Controls.Add(Me.Cmx_02_Contract__term)
        Me.Contract.Controls.Add(Me.Dtp_31_contract__enddate)
        Me.Contract.Controls.Add(Me.Label4)
        Me.Contract.Controls.Add(Me.Dtp_31_contract__startdate)
        Me.Contract.Controls.Add(Me.Label5)
        Me.Contract.Controls.Add(Me.Tbx_00_contract__description)
        Me.Contract.Controls.Add(Me.Chx_00_contract__autcol)
        Me.Contract.Controls.Add(Me.Label7)
        Me.Contract.Controls.Add(Me.Tbx_11_contract__overhead)
        Me.Contract.Controls.Add(Me.Lbl_Basis_Startdatum)
        Me.Contract.Controls.Add(Me.Tbx_contract_period_amt)
        Me.Contract.Controls.Add(Me.Label3)
        Me.Contract.Controls.Add(Me.Label10)
        Me.Contract.Controls.Add(Me.Label1)
        Me.Contract.Controls.Add(Me.Tbx_11_Contract__donation)
        Me.Contract.Controls.Add(Me.Tbx_01_contract_yeartotal)
        Me.Contract.Location = New System.Drawing.Point(4, 40)
        Me.Contract.Name = "Contract"
        Me.Contract.Padding = New System.Windows.Forms.Padding(3)
        Me.Contract.Size = New System.Drawing.Size(1152, 804)
        Me.Contract.TabIndex = 1
        Me.Contract.Text = "Contract"
        '
        'Lbl_Rel_id
        '
        Me.Lbl_Rel_id.AutoSize = True
        Me.Lbl_Rel_id.Location = New System.Drawing.Point(537, 329)
        Me.Lbl_Rel_id.Name = "Lbl_Rel_id"
        Me.Lbl_Rel_id.Size = New System.Drawing.Size(30, 28)
        Me.Lbl_Rel_id.TabIndex = 74
        Me.Lbl_Rel_id.Text = "..."
        Me.Lbl_Rel_id.Visible = False
        '
        'Lbl_Contract_tgt
        '
        Me.Lbl_Contract_tgt.AutoSize = True
        Me.Lbl_Contract_tgt.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_Contract_tgt.Location = New System.Drawing.Point(513, 25)
        Me.Lbl_Contract_tgt.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Contract_tgt.Name = "Lbl_Contract_tgt"
        Me.Lbl_Contract_tgt.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_Contract_tgt.TabIndex = 73
        Me.Lbl_Contract_tgt.Text = "id"
        Me.Lbl_Contract_tgt.Visible = False
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label96.Location = New System.Drawing.Point(498, 25)
        Me.Label96.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(21, 28)
        Me.Label96.TabIndex = 72
        Me.Label96.Text = "/"
        Me.Label96.Visible = False
        '
        'Lbl_Contract_Bronaccount
        '
        Me.Lbl_Contract_Bronaccount.AutoSize = True
        Me.Lbl_Contract_Bronaccount.Location = New System.Drawing.Point(22, 389)
        Me.Lbl_Contract_Bronaccount.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Contract_Bronaccount.Name = "Lbl_Contract_Bronaccount"
        Me.Lbl_Contract_Bronaccount.Size = New System.Drawing.Size(132, 28)
        Me.Lbl_Contract_Bronaccount.TabIndex = 70
        Me.Lbl_Contract_Bronaccount.Text = "Bronaccount"
        Me.Lbl_Contract_Bronaccount.Visible = False
        '
        'Cmx_00_Contract__fk_account_id
        '
        Me.Cmx_00_Contract__fk_account_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cmx_00_Contract__fk_account_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cmx_00_Contract__fk_account_id.FormattingEnabled = True
        Me.Cmx_00_Contract__fk_account_id.Location = New System.Drawing.Point(207, 385)
        Me.Cmx_00_Contract__fk_account_id.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_00_Contract__fk_account_id.Name = "Cmx_00_Contract__fk_account_id"
        Me.Cmx_00_Contract__fk_account_id.Size = New System.Drawing.Size(430, 36)
        Me.Cmx_00_Contract__fk_account_id.Sorted = True
        Me.Cmx_00_Contract__fk_account_id.TabIndex = 69
        Me.Cmx_00_Contract__fk_account_id.Tag = "Sponsor"
        Me.Cmx_00_Contract__fk_account_id.Visible = False
        '
        'Tbx_Contract_ttype
        '
        Me.Tbx_Contract_ttype.Location = New System.Drawing.Point(508, 138)
        Me.Tbx_Contract_ttype.Name = "Tbx_Contract_ttype"
        Me.Tbx_Contract_ttype.Size = New System.Drawing.Size(76, 35)
        Me.Tbx_Contract_ttype.TabIndex = 66
        Me.Tbx_Contract_ttype.Visible = False
        '
        'Cbx_00_contract__active
        '
        Me.Cbx_00_contract__active.AutoSize = True
        Me.Cbx_00_contract__active.Checked = True
        Me.Cbx_00_contract__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_contract__active.Enabled = False
        Me.Cbx_00_contract__active.Location = New System.Drawing.Point(249, 91)
        Me.Cbx_00_contract__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_contract__active.Name = "Cbx_00_contract__active"
        Me.Cbx_00_contract__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_contract__active.TabIndex = 65
        Me.Cbx_00_contract__active.Text = "Actief"
        Me.Cbx_00_contract__active.UseVisualStyleBackColor = True
        '
        'Lbl_contract_mach_datum
        '
        Me.Lbl_contract_mach_datum.AutoSize = True
        Me.Lbl_contract_mach_datum.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_contract_mach_datum.Location = New System.Drawing.Point(688, 480)
        Me.Lbl_contract_mach_datum.Name = "Lbl_contract_mach_datum"
        Me.Lbl_contract_mach_datum.Size = New System.Drawing.Size(253, 28)
        Me.Lbl_contract_mach_datum.TabIndex = 64
        Me.Lbl_contract_mach_datum.Text = "Ingangsdatum machtiging"
        Me.Lbl_contract_mach_datum.Visible = False
        '
        'Lbl_contract_macht_kenm
        '
        Me.Lbl_contract_macht_kenm.AutoSize = True
        Me.Lbl_contract_macht_kenm.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_contract_macht_kenm.Location = New System.Drawing.Point(688, 440)
        Me.Lbl_contract_macht_kenm.Name = "Lbl_contract_macht_kenm"
        Me.Lbl_contract_macht_kenm.Size = New System.Drawing.Size(205, 28)
        Me.Lbl_contract_macht_kenm.TabIndex = 64
        Me.Lbl_contract_macht_kenm.Text = "Machtigingskenmerk"
        Me.Lbl_contract_macht_kenm.Visible = False
        '
        'Pan_Contract_Date_New
        '
        Me.Pan_Contract_Date_New.Controls.Add(Me.Dtp_30_Contract_Change)
        Me.Pan_Contract_Date_New.Controls.Add(Me.Lbl_contract_new_date)
        Me.Pan_Contract_Date_New.Location = New System.Drawing.Point(678, 317)
        Me.Pan_Contract_Date_New.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pan_Contract_Date_New.Name = "Pan_Contract_Date_New"
        Me.Pan_Contract_Date_New.Size = New System.Drawing.Size(426, 49)
        Me.Pan_Contract_Date_New.TabIndex = 63
        Me.Pan_Contract_Date_New.Visible = False
        '
        'Dtp_30_Contract_Change
        '
        Me.Dtp_30_Contract_Change.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_30_Contract_Change.Location = New System.Drawing.Point(266, 8)
        Me.Dtp_30_Contract_Change.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_30_Contract_Change.MinDate = New Date(2020, 1, 1, 0, 0, 0, 0)
        Me.Dtp_30_Contract_Change.Name = "Dtp_30_Contract_Change"
        Me.Dtp_30_Contract_Change.Size = New System.Drawing.Size(138, 35)
        Me.Dtp_30_Contract_Change.TabIndex = 25
        '
        'Lbl_contract_new_date
        '
        Me.Lbl_contract_new_date.AutoSize = True
        Me.Lbl_contract_new_date.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_contract_new_date.Location = New System.Drawing.Point(14, 14)
        Me.Lbl_contract_new_date.Name = "Lbl_contract_new_date"
        Me.Lbl_contract_new_date.Size = New System.Drawing.Size(230, 28)
        Me.Lbl_contract_new_date.TabIndex = 52
        Me.Lbl_contract_new_date.Text = "Ingangsdatum wijziging"
        '
        'Lbl_00_contract_doeltype
        '
        Me.Lbl_00_contract_doeltype.AutoSize = True
        Me.Lbl_00_contract_doeltype.Location = New System.Drawing.Point(244, 138)
        Me.Lbl_00_contract_doeltype.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_00_contract_doeltype.Name = "Lbl_00_contract_doeltype"
        Me.Lbl_00_contract_doeltype.Size = New System.Drawing.Size(95, 28)
        Me.Lbl_00_contract_doeltype.TabIndex = 40
        Me.Lbl_00_contract_doeltype.Text = "Doeltype"
        '
        'Pan_contract_select_target
        '
        Me.Pan_contract_select_target.Controls.Add(Me.Rbn_00_contract_child)
        Me.Pan_contract_select_target.Controls.Add(Me.Rbn_00_contract_elder)
        Me.Pan_contract_select_target.Controls.Add(Me.Rbn_00_contract_other)
        Me.Pan_contract_select_target.Enabled = False
        Me.Pan_contract_select_target.Location = New System.Drawing.Point(384, 138)
        Me.Pan_contract_select_target.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pan_contract_select_target.Name = "Pan_contract_select_target"
        Me.Pan_contract_select_target.Size = New System.Drawing.Size(117, 111)
        Me.Pan_contract_select_target.TabIndex = 62
        '
        'Rbn_00_contract_child
        '
        Me.Rbn_00_contract_child.AutoSize = True
        Me.Rbn_00_contract_child.Location = New System.Drawing.Point(4, 2)
        Me.Rbn_00_contract_child.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_00_contract_child.Name = "Rbn_00_contract_child"
        Me.Rbn_00_contract_child.Size = New System.Drawing.Size(78, 32)
        Me.Rbn_00_contract_child.TabIndex = 37
        Me.Rbn_00_contract_child.TabStop = True
        Me.Rbn_00_contract_child.Text = "Kind"
        Me.Rbn_00_contract_child.UseVisualStyleBackColor = True
        '
        'Rbn_00_contract_elder
        '
        Me.Rbn_00_contract_elder.AutoSize = True
        Me.Rbn_00_contract_elder.Location = New System.Drawing.Point(4, 38)
        Me.Rbn_00_contract_elder.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_00_contract_elder.Name = "Rbn_00_contract_elder"
        Me.Rbn_00_contract_elder.Size = New System.Drawing.Size(106, 32)
        Me.Rbn_00_contract_elder.TabIndex = 38
        Me.Rbn_00_contract_elder.TabStop = True
        Me.Rbn_00_contract_elder.Text = "Oudere"
        Me.Rbn_00_contract_elder.UseVisualStyleBackColor = True
        '
        'Rbn_00_contract_other
        '
        Me.Rbn_00_contract_other.AutoSize = True
        Me.Rbn_00_contract_other.Location = New System.Drawing.Point(4, 72)
        Me.Rbn_00_contract_other.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbn_00_contract_other.Name = "Rbn_00_contract_other"
        Me.Rbn_00_contract_other.Size = New System.Drawing.Size(97, 32)
        Me.Rbn_00_contract_other.TabIndex = 39
        Me.Rbn_00_contract_other.TabStop = True
        Me.Rbn_00_contract_other.Text = "Overig"
        Me.Rbn_00_contract_other.UseVisualStyleBackColor = True
        '
        'Lbl_00_contract_autcol
        '
        Me.Lbl_00_contract_autcol.AutoSize = True
        Me.Lbl_00_contract_autcol.ForeColor = System.Drawing.Color.Black
        Me.Lbl_00_contract_autcol.Location = New System.Drawing.Point(944, 440)
        Me.Lbl_00_contract_autcol.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_00_contract_autcol.MinimumSize = New System.Drawing.Size(140, 40)
        Me.Lbl_00_contract_autcol.Name = "Lbl_00_contract_autcol"
        Me.Lbl_00_contract_autcol.Size = New System.Drawing.Size(140, 40)
        Me.Lbl_00_contract_autcol.TabIndex = 61
        Me.Lbl_00_contract_autcol.Text = "Reference"
        Me.Lbl_00_contract_autcol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Lbl_00_contract_autcol.Visible = False
        '
        'Pic_Contract_Target_photo
        '
        Me.Pic_Contract_Target_photo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Contract_Target_photo.Image = CType(resources.GetObject("Pic_Contract_Target_photo.Image"), System.Drawing.Image)
        Me.Pic_Contract_Target_photo.InitialImage = CType(resources.GetObject("Pic_Contract_Target_photo.InitialImage"), System.Drawing.Image)
        Me.Pic_Contract_Target_photo.Location = New System.Drawing.Point(22, 25)
        Me.Pic_Contract_Target_photo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pic_Contract_Target_photo.Name = "Pic_Contract_Target_photo"
        Me.Pic_Contract_Target_photo.Size = New System.Drawing.Size(194, 222)
        Me.Pic_Contract_Target_photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pic_Contract_Target_photo.TabIndex = 57
        Me.Pic_Contract_Target_photo.TabStop = False
        Me.Pic_Contract_Target_photo.Tag = "Click to add photo"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(22, 338)
        Me.Label85.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(88, 28)
        Me.Label85.TabIndex = 56
        Me.Label85.Text = "Sponsor"
        '
        'dtp_contract_relation_date
        '
        Me.dtp_contract_relation_date.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right
        Me.dtp_contract_relation_date.Enabled = False
        Me.dtp_contract_relation_date.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtp_contract_relation_date.Location = New System.Drawing.Point(944, 480)
        Me.dtp_contract_relation_date.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dtp_contract_relation_date.Name = "dtp_contract_relation_date"
        Me.dtp_contract_relation_date.Size = New System.Drawing.Size(138, 35)
        Me.dtp_contract_relation_date.TabIndex = 54
        Me.dtp_contract_relation_date.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        Me.dtp_contract_relation_date.Visible = False
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.Location = New System.Drawing.Point(692, 160)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(69, 28)
        Me.Label80.TabIndex = 45
        Me.Label80.Text = "Totaal"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(22, 289)
        Me.Label84.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(128, 28)
        Me.Label84.TabIndex = 44
        Me.Label84.Text = "Sponsordoel"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.Location = New System.Drawing.Point(244, 25)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(113, 28)
        Me.Label77.TabIndex = 41
        Me.Label77.Text = "Contractnr"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(246, 58)
        Me.Label74.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(94, 28)
        Me.Label74.TabIndex = 34
        Me.Label74.Text = "Kenmerk"
        '
        'Lbl_00_Contract__name
        '
        Me.Lbl_00_Contract__name.AutoSize = True
        Me.Lbl_00_Contract__name.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_00_Contract__name.Location = New System.Drawing.Point(384, 25)
        Me.Lbl_00_Contract__name.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_00_Contract__name.Name = "Lbl_00_Contract__name"
        Me.Lbl_00_Contract__name.Size = New System.Drawing.Size(104, 28)
        Me.Lbl_00_Contract__name.TabIndex = 32
        Me.Lbl_00_Contract__name.Text = "Reference"
        '
        'Lbl_Contract_pkid
        '
        Me.Lbl_Contract_pkid.AutoSize = True
        Me.Lbl_Contract_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_Contract_pkid.Location = New System.Drawing.Point(386, 58)
        Me.Lbl_Contract_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Contract_pkid.Name = "Lbl_Contract_pkid"
        Me.Lbl_Contract_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_Contract_pkid.TabIndex = 33
        Me.Lbl_Contract_pkid.Text = "id"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(692, 262)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(146, 28)
        Me.Label70.TabIndex = 30
        Me.Label70.Text = "Termijnbedrag"
        '
        'Cmx_00_contract__fk_relation_id
        '
        Me.Cmx_00_contract__fk_relation_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.Cmx_00_contract__fk_relation_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cmx_00_contract__fk_relation_id.Enabled = False
        Me.Cmx_00_contract__fk_relation_id.FormattingEnabled = True
        Me.Cmx_00_contract__fk_relation_id.Location = New System.Drawing.Point(207, 335)
        Me.Cmx_00_contract__fk_relation_id.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_00_contract__fk_relation_id.Name = "Cmx_00_contract__fk_relation_id"
        Me.Cmx_00_contract__fk_relation_id.Size = New System.Drawing.Size(312, 36)
        Me.Cmx_00_contract__fk_relation_id.Sorted = True
        Me.Cmx_00_contract__fk_relation_id.TabIndex = 29
        Me.Cmx_00_contract__fk_relation_id.Tag = "Sponsor"
        '
        'Cmx_01_contract__fk_target_id
        '
        Me.Cmx_01_contract__fk_target_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.Cmx_01_contract__fk_target_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.Cmx_01_contract__fk_target_id.Enabled = False
        Me.Cmx_01_contract__fk_target_id.FormattingEnabled = True
        Me.Cmx_01_contract__fk_target_id.Location = New System.Drawing.Point(207, 285)
        Me.Cmx_01_contract__fk_target_id.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_01_contract__fk_target_id.Name = "Cmx_01_contract__fk_target_id"
        Me.Cmx_01_contract__fk_target_id.Size = New System.Drawing.Size(312, 36)
        Me.Cmx_01_contract__fk_target_id.TabIndex = 29
        Me.Cmx_01_contract__fk_target_id.Tag = "Sponsordoel"
        '
        'Cmx_02_Contract__term
        '
        Me.Cmx_02_Contract__term.Enabled = False
        Me.Cmx_02_Contract__term.FormattingEnabled = True
        Me.Cmx_02_Contract__term.Items.AddRange(New Object() {"1", "3", "4", "6", "12"})
        Me.Cmx_02_Contract__term.Location = New System.Drawing.Point(990, 211)
        Me.Cmx_02_Contract__term.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_02_Contract__term.Name = "Cmx_02_Contract__term"
        Me.Cmx_02_Contract__term.Size = New System.Drawing.Size(91, 36)
        Me.Cmx_02_Contract__term.TabIndex = 23
        Me.Cmx_02_Contract__term.Text = "12"
        '
        'Dtp_31_contract__enddate
        '
        Me.Dtp_31_contract__enddate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_31_contract__enddate.Location = New System.Drawing.Point(489, 442)
        Me.Dtp_31_contract__enddate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_31_contract__enddate.Name = "Dtp_31_contract__enddate"
        Me.Dtp_31_contract__enddate.Size = New System.Drawing.Size(148, 35)
        Me.Dtp_31_contract__enddate.TabIndex = 26
        Me.Dtp_31_contract__enddate.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(369, 448)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 28)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Einddatum"
        '
        'Dtp_31_contract__startdate
        '
        Me.Dtp_31_contract__startdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_31_contract__startdate.Location = New System.Drawing.Point(207, 442)
        Me.Dtp_31_contract__startdate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_31_contract__startdate.Name = "Dtp_31_contract__startdate"
        Me.Dtp_31_contract__startdate.Size = New System.Drawing.Size(148, 35)
        Me.Dtp_31_contract__startdate.TabIndex = 25
        Me.Dtp_31_contract__startdate.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(18, 517)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 28)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Toelichting"
        '
        'Tbx_00_contract__description
        '
        Me.Tbx_00_contract__description.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Tbx_00_contract__description.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_contract__description.Location = New System.Drawing.Point(22, 554)
        Me.Tbx_00_contract__description.Multiline = True
        Me.Tbx_00_contract__description.Name = "Tbx_00_contract__description"
        Me.Tbx_00_contract__description.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_00_contract__description.Size = New System.Drawing.Size(1111, 162)
        Me.Tbx_00_contract__description.TabIndex = 6
        '
        'Chx_00_contract__autcol
        '
        Me.Chx_00_contract__autcol.AutoSize = True
        Me.Chx_00_contract__autcol.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Chx_00_contract__autcol.Location = New System.Drawing.Point(696, 400)
        Me.Chx_00_contract__autcol.Name = "Chx_00_contract__autcol"
        Me.Chx_00_contract__autcol.Size = New System.Drawing.Size(240, 32)
        Me.Chx_00_contract__autcol.TabIndex = 24
        Me.Chx_00_contract__autcol.Text = "Automatische incasso"
        Me.Chx_00_contract__autcol.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(692, 215)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(186, 28)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Termijnen per jaar "
        '
        'Tbx_11_contract__overhead
        '
        Me.Tbx_11_contract__overhead.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_11_contract__overhead.Location = New System.Drawing.Point(990, 120)
        Me.Tbx_11_contract__overhead.Name = "Tbx_11_contract__overhead"
        Me.Tbx_11_contract__overhead.Size = New System.Drawing.Size(91, 30)
        Me.Tbx_11_contract__overhead.TabIndex = 22
        Me.Tbx_11_contract__overhead.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lbl_Basis_Startdatum
        '
        Me.Lbl_Basis_Startdatum.AutoSize = True
        Me.Lbl_Basis_Startdatum.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Basis_Startdatum.Location = New System.Drawing.Point(22, 442)
        Me.Lbl_Basis_Startdatum.Name = "Lbl_Basis_Startdatum"
        Me.Lbl_Basis_Startdatum.Size = New System.Drawing.Size(119, 28)
        Me.Lbl_Basis_Startdatum.TabIndex = 7
        Me.Lbl_Basis_Startdatum.Text = "Startdatum"
        '
        'Tbx_contract_period_amt
        '
        Me.Tbx_contract_period_amt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_contract_period_amt.Location = New System.Drawing.Point(990, 258)
        Me.Tbx_contract_period_amt.Name = "Tbx_contract_period_amt"
        Me.Tbx_contract_period_amt.Size = New System.Drawing.Size(91, 30)
        Me.Tbx_contract_period_amt.TabIndex = 23
        Me.Tbx_contract_period_amt.Tag = "Sponsorbedrag"
        Me.Tbx_contract_period_amt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(692, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 28)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Doel"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(692, 120)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(102, 28)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Overhead"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(692, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 28)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Bedragen"
        '
        'Tbx_11_Contract__donation
        '
        Me.Tbx_11_Contract__donation.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_11_Contract__donation.Location = New System.Drawing.Point(990, 80)
        Me.Tbx_11_Contract__donation.Name = "Tbx_11_Contract__donation"
        Me.Tbx_11_Contract__donation.Size = New System.Drawing.Size(91, 30)
        Me.Tbx_11_Contract__donation.TabIndex = 20
        Me.Tbx_11_Contract__donation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tbx_01_contract_yeartotal
        '
        Me.Tbx_01_contract_yeartotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_01_contract_yeartotal.Location = New System.Drawing.Point(990, 160)
        Me.Tbx_01_contract_yeartotal.Name = "Tbx_01_contract_yeartotal"
        Me.Tbx_01_contract_yeartotal.Size = New System.Drawing.Size(91, 30)
        Me.Tbx_01_contract_yeartotal.TabIndex = 22
        Me.Tbx_01_contract_yeartotal.Tag = "Sponsorbedrag"
        Me.Tbx_01_contract_yeartotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'target
        '
        Me.target.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.target.Controls.Add(Me.Tbx_20_Target__childnearby)
        Me.target.Controls.Add(Me.Tbx_20_Target__children)
        Me.target.Controls.Add(Me.Label16)
        Me.target.Controls.Add(Me.Rbtn_Target_Alone)
        Me.target.Controls.Add(Me.Rbtn_Target_Institution)
        Me.target.Controls.Add(Me.Rbtn_Target_OtherHousing)
        Me.target.Controls.Add(Me.Label78)
        Me.target.Controls.Add(Me.Label65)
        Me.target.Controls.Add(Me.Label62)
        Me.target.Controls.Add(Me.Label118)
        Me.target.Controls.Add(Me.Cmx_01_Target__fk_cp_id)
        Me.target.Controls.Add(Me.Pan_Target)
        Me.target.Controls.Add(Me.Cbx_00_target__active)
        Me.target.Controls.Add(Me.Label75)
        Me.target.Controls.Add(Me.Label55)
        Me.target.Controls.Add(Me.Lbl_CP)
        Me.target.Controls.Add(Me.Lbl_Target_Total_Expenses)
        Me.target.Controls.Add(Me.Lbl_Target_NameAdd)
        Me.target.Controls.Add(Me.Tbx_00_Target__living)
        Me.target.Controls.Add(Me.Tbx_10_Target__water)
        Me.target.Controls.Add(Me.Tbx_01_Target__name_add)
        Me.target.Controls.Add(Me.Label19)
        Me.target.Controls.Add(Me.Lbl_Target_Name)
        Me.target.Controls.Add(Me.Tbx_10_Target__benefit)
        Me.target.Controls.Add(Me.Dtp_00_Target__birthday)
        Me.target.Controls.Add(Me.Lbl_Target_Total_Income)
        Me.target.Controls.Add(Me.Tbx_01_Target__name)
        Me.target.Controls.Add(Me.Lbl_Target_BirthDay)
        Me.target.Controls.Add(Me.Tbx_10_Target__otherincome)
        Me.target.Controls.Add(Me.Tbx_01_Target__ttype)
        Me.target.Controls.Add(Me.Lbl_Target_Pension)
        Me.target.Controls.Add(Me.Lbl_Target_Description)
        Me.target.Controls.Add(Me.Lbl_Target_Type)
        Me.target.Controls.Add(Me.Tbx_10_Target__pension)
        Me.target.Controls.Add(Me.Lbl_00_Target__reference)
        Me.target.Controls.Add(Me.Label18)
        Me.target.Controls.Add(Me.Label23)
        Me.target.Controls.Add(Me.Lbl_Target_Extra)
        Me.target.Controls.Add(Me.Lbl_Target_pkid)
        Me.target.Controls.Add(Me.Label13)
        Me.target.Controls.Add(Me.Tbx_00_Target__description)
        Me.target.Controls.Add(Me.Tbx_10_Target__allowance)
        Me.target.Controls.Add(Me.Label12)
        Me.target.Controls.Add(Me.Lbl_Target_Salary)
        Me.target.Controls.Add(Me.Tbx_10_Target__income)
        Me.target.Controls.Add(Me.Label2)
        Me.target.Controls.Add(Me.Lbl_Target_Income)
        Me.target.Controls.Add(Me.Tbx_00_Target__zip)
        Me.target.Controls.Add(Me.Lbl_Target_Benefit)
        Me.target.Controls.Add(Me.Label17)
        Me.target.Controls.Add(Me.Tbx_00_Target__country)
        Me.target.Controls.Add(Me.Lbl_Target_Otherincome)
        Me.target.Controls.Add(Me.Tbx_10_Target__rent)
        Me.target.Controls.Add(Me.Lbl_Target_Address)
        Me.target.Controls.Add(Me.Tbx_10_Target__medicine)
        Me.target.Controls.Add(Me.Label11)
        Me.target.Controls.Add(Me.Tbx_00_Target__address)
        Me.target.Controls.Add(Me.Label14)
        Me.target.Controls.Add(Me.Label20)
        Me.target.Controls.Add(Me.Tbx_10_Target__food)
        Me.target.Controls.Add(Me.Tbx_10_Target__heating)
        Me.target.Controls.Add(Me.Tbx_00_Target__city)
        Me.target.Controls.Add(Me.Tbx_10_Target__gaselectra)
        Me.target.Controls.Add(Me.Pic_Target__photo)
        Me.target.Location = New System.Drawing.Point(4, 40)
        Me.target.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.target.Name = "target"
        Me.target.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.target.Size = New System.Drawing.Size(1152, 804)
        Me.target.TabIndex = 2
        Me.target.Tag = "Doel"
        Me.target.Text = "Doel"
        '
        'Tbx_20_Target__childnearby
        '
        Me.Tbx_20_Target__childnearby.Location = New System.Drawing.Point(825, 631)
        Me.Tbx_20_Target__childnearby.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_20_Target__childnearby.Name = "Tbx_20_Target__childnearby"
        Me.Tbx_20_Target__childnearby.Size = New System.Drawing.Size(73, 35)
        Me.Tbx_20_Target__childnearby.TabIndex = 65
        '
        'Tbx_20_Target__children
        '
        Me.Tbx_20_Target__children.Location = New System.Drawing.Point(825, 585)
        Me.Tbx_20_Target__children.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_20_Target__children.Name = "Tbx_20_Target__children"
        Me.Tbx_20_Target__children.Size = New System.Drawing.Size(73, 35)
        Me.Tbx_20_Target__children.TabIndex = 64
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(644, 591)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(158, 28)
        Me.Label16.TabIndex = 63
        Me.Label16.Text = "Aantal kinderen"
        '
        'Rbtn_Target_Alone
        '
        Me.Rbtn_Target_Alone.AutoSize = True
        Me.Rbtn_Target_Alone.Location = New System.Drawing.Point(825, 477)
        Me.Rbtn_Target_Alone.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Target_Alone.Name = "Rbtn_Target_Alone"
        Me.Rbtn_Target_Alone.Size = New System.Drawing.Size(157, 32)
        Me.Rbtn_Target_Alone.TabIndex = 62
        Me.Rbtn_Target_Alone.TabStop = True
        Me.Rbtn_Target_Alone.Text = "Alleenstaand"
        Me.Rbtn_Target_Alone.UseVisualStyleBackColor = True
        '
        'Rbtn_Target_Institution
        '
        Me.Rbtn_Target_Institution.AutoSize = True
        Me.Rbtn_Target_Institution.Location = New System.Drawing.Point(825, 508)
        Me.Rbtn_Target_Institution.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Target_Institution.Name = "Rbtn_Target_Institution"
        Me.Rbtn_Target_Institution.Size = New System.Drawing.Size(188, 32)
        Me.Rbtn_Target_Institution.TabIndex = 61
        Me.Rbtn_Target_Institution.TabStop = True
        Me.Rbtn_Target_Institution.Text = "Tehuis/Instelling"
        Me.Rbtn_Target_Institution.UseVisualStyleBackColor = True
        '
        'Rbtn_Target_OtherHousing
        '
        Me.Rbtn_Target_OtherHousing.AutoSize = True
        Me.Rbtn_Target_OtherHousing.Location = New System.Drawing.Point(825, 538)
        Me.Rbtn_Target_OtherHousing.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Target_OtherHousing.Name = "Rbtn_Target_OtherHousing"
        Me.Rbtn_Target_OtherHousing.Size = New System.Drawing.Size(102, 32)
        Me.Rbtn_Target_OtherHousing.TabIndex = 60
        Me.Rbtn_Target_OtherHousing.TabStop = True
        Me.Rbtn_Target_OtherHousing.Text = "Anders"
        Me.Rbtn_Target_OtherHousing.UseVisualStyleBackColor = True
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(644, 431)
        Me.Label78.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(176, 28)
        Me.Label78.TabIndex = 58
        Me.Label78.Text = "Omstandigheden"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(644, 477)
        Me.Label65.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(136, 28)
        Me.Label65.TabIndex = 57
        Me.Label65.Text = "Woonsituatie"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(644, 637)
        Me.Label62.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(184, 28)
        Me.Label62.TabIndex = 56
        Me.Label62.Text = "Korste afstand (m)"
        '
        'Label118
        '
        Me.Label118.Font = New System.Drawing.Font("Arial Narrow", 7.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label118.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label118.Location = New System.Drawing.Point(9, 234)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(195, 43)
        Me.Label118.TabIndex = 54
        Me.Label118.Text = "Shift-S-Window: selecteer; dubbelklik  foto: plak of verwijder"
        '
        'Cmx_01_Target__fk_cp_id
        '
        Me.Cmx_01_Target__fk_cp_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmx_01_Target__fk_cp_id.FormattingEnabled = True
        Me.Cmx_01_Target__fk_cp_id.Location = New System.Drawing.Point(220, 526)
        Me.Cmx_01_Target__fk_cp_id.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_01_Target__fk_cp_id.Name = "Cmx_01_Target__fk_cp_id"
        Me.Cmx_01_Target__fk_cp_id.Size = New System.Drawing.Size(348, 36)
        Me.Cmx_01_Target__fk_cp_id.TabIndex = 15
        Me.Cmx_01_Target__fk_cp_id.Tag = "Contactpersoon"
        '
        'Pan_Target
        '
        Me.Pan_Target.Controls.Add(Me.Rbtn_Target_Child)
        Me.Pan_Target.Controls.Add(Me.Rbtn_Target_Elder)
        Me.Pan_Target.Controls.Add(Me.Rbtn_Target_Other)
        Me.Pan_Target.Enabled = False
        Me.Pan_Target.Location = New System.Drawing.Point(342, 134)
        Me.Pan_Target.Name = "Pan_Target"
        Me.Pan_Target.Size = New System.Drawing.Size(122, 106)
        Me.Pan_Target.TabIndex = 53
        '
        'Rbtn_Target_Child
        '
        Me.Rbtn_Target_Child.AutoSize = True
        Me.Rbtn_Target_Child.Location = New System.Drawing.Point(4, 5)
        Me.Rbtn_Target_Child.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Target_Child.Name = "Rbtn_Target_Child"
        Me.Rbtn_Target_Child.Size = New System.Drawing.Size(78, 32)
        Me.Rbtn_Target_Child.TabIndex = 3
        Me.Rbtn_Target_Child.TabStop = True
        Me.Rbtn_Target_Child.Text = "Kind"
        Me.Rbtn_Target_Child.UseVisualStyleBackColor = True
        '
        'Rbtn_Target_Elder
        '
        Me.Rbtn_Target_Elder.AutoSize = True
        Me.Rbtn_Target_Elder.Location = New System.Drawing.Point(4, 37)
        Me.Rbtn_Target_Elder.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Target_Elder.Name = "Rbtn_Target_Elder"
        Me.Rbtn_Target_Elder.Size = New System.Drawing.Size(106, 32)
        Me.Rbtn_Target_Elder.TabIndex = 4
        Me.Rbtn_Target_Elder.TabStop = True
        Me.Rbtn_Target_Elder.Text = "Oudere"
        Me.Rbtn_Target_Elder.UseVisualStyleBackColor = True
        '
        'Rbtn_Target_Other
        '
        Me.Rbtn_Target_Other.AutoSize = True
        Me.Rbtn_Target_Other.Location = New System.Drawing.Point(4, 71)
        Me.Rbtn_Target_Other.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Target_Other.Name = "Rbtn_Target_Other"
        Me.Rbtn_Target_Other.Size = New System.Drawing.Size(97, 32)
        Me.Rbtn_Target_Other.TabIndex = 5
        Me.Rbtn_Target_Other.TabStop = True
        Me.Rbtn_Target_Other.Text = "Overig"
        Me.Rbtn_Target_Other.UseVisualStyleBackColor = True
        '
        'Cbx_00_target__active
        '
        Me.Cbx_00_target__active.AutoSize = True
        Me.Cbx_00_target__active.Checked = True
        Me.Cbx_00_target__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_target__active.Location = New System.Drawing.Point(342, 72)
        Me.Cbx_00_target__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_target__active.Name = "Cbx_00_target__active"
        Me.Cbx_00_target__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_target__active.TabIndex = 52
        Me.Cbx_00_target__active.Text = "Actief"
        Me.Cbx_00_target__active.UseVisualStyleBackColor = True
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(216, 40)
        Me.Label75.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(107, 28)
        Me.Label75.TabIndex = 41
        Me.Label75.Text = "Referentie"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(644, 8)
        Me.Label55.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(186, 28)
        Me.Label55.TabIndex = 34
        Me.Label55.Text = "Financiële situatie"
        '
        'Lbl_CP
        '
        Me.Lbl_CP.AutoSize = True
        Me.Lbl_CP.Location = New System.Drawing.Point(9, 531)
        Me.Lbl_CP.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_CP.Name = "Lbl_CP"
        Me.Lbl_CP.Size = New System.Drawing.Size(36, 28)
        Me.Lbl_CP.TabIndex = 10
        Me.Lbl_CP.Text = "CP"
        '
        'Lbl_Target_Total_Expenses
        '
        Me.Lbl_Target_Total_Expenses.BackColor = System.Drawing.Color.White
        Me.Lbl_Target_Total_Expenses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Target_Total_Expenses.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Target_Total_Expenses.Location = New System.Drawing.Point(957, 360)
        Me.Lbl_Target_Total_Expenses.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Total_Expenses.MinimumSize = New System.Drawing.Size(119, 34)
        Me.Lbl_Target_Total_Expenses.Name = "Lbl_Target_Total_Expenses"
        Me.Lbl_Target_Total_Expenses.Size = New System.Drawing.Size(119, 34)
        Me.Lbl_Target_Total_Expenses.TabIndex = 16
        Me.Lbl_Target_Total_Expenses.Text = "0,00"
        Me.Lbl_Target_Total_Expenses.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Target_NameAdd
        '
        Me.Lbl_Target_NameAdd.AutoSize = True
        Me.Lbl_Target_NameAdd.Location = New System.Drawing.Point(9, 337)
        Me.Lbl_Target_NameAdd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_NameAdd.Name = "Lbl_Target_NameAdd"
        Me.Lbl_Target_NameAdd.Size = New System.Drawing.Size(108, 28)
        Me.Lbl_Target_NameAdd.TabIndex = 3
        Me.Lbl_Target_NameAdd.Text = "Voornaam"
        '
        'Tbx_00_Target__living
        '
        Me.Tbx_00_Target__living.Location = New System.Drawing.Point(756, 311)
        Me.Tbx_00_Target__living.Name = "Tbx_00_Target__living"
        Me.Tbx_00_Target__living.Size = New System.Drawing.Size(90, 35)
        Me.Tbx_00_Target__living.TabIndex = 31
        Me.Tbx_00_Target__living.Visible = False
        '
        'Tbx_10_Target__water
        '
        Me.Tbx_10_Target__water.Location = New System.Drawing.Point(993, 260)
        Me.Tbx_10_Target__water.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__water.Name = "Tbx_10_Target__water"
        Me.Tbx_10_Target__water.Size = New System.Drawing.Size(79, 35)
        Me.Tbx_10_Target__water.TabIndex = 38
        Me.Tbx_10_Target__water.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tbx_01_Target__name_add
        '
        Me.Tbx_01_Target__name_add.Location = New System.Drawing.Point(220, 332)
        Me.Tbx_01_Target__name_add.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_Target__name_add.Name = "Tbx_01_Target__name_add"
        Me.Tbx_01_Target__name_add.Size = New System.Drawing.Size(348, 35)
        Me.Tbx_01_Target__name_add.TabIndex = 2
        Me.Tbx_01_Target__name_add.Tag = "Voornaam"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(864, 263)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 28)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Water"
        '
        'Lbl_Target_Name
        '
        Me.Lbl_Target_Name.AutoSize = True
        Me.Lbl_Target_Name.Location = New System.Drawing.Point(9, 288)
        Me.Lbl_Target_Name.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Name.Name = "Lbl_Target_Name"
        Me.Lbl_Target_Name.Size = New System.Drawing.Size(67, 28)
        Me.Lbl_Target_Name.TabIndex = 3
        Me.Lbl_Target_Name.Text = "Naam"
        '
        'Tbx_10_Target__benefit
        '
        Me.Tbx_10_Target__benefit.Location = New System.Drawing.Point(756, 177)
        Me.Tbx_10_Target__benefit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__benefit.Name = "Tbx_10_Target__benefit"
        Me.Tbx_10_Target__benefit.Size = New System.Drawing.Size(91, 35)
        Me.Tbx_10_Target__benefit.TabIndex = 32
        Me.Tbx_10_Target__benefit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Dtp_00_Target__birthday
        '
        Me.Dtp_00_Target__birthday.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_00_Target__birthday.Location = New System.Drawing.Point(220, 383)
        Me.Dtp_00_Target__birthday.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_00_Target__birthday.Name = "Dtp_00_Target__birthday"
        Me.Dtp_00_Target__birthday.Size = New System.Drawing.Size(162, 35)
        Me.Dtp_00_Target__birthday.TabIndex = 10
        Me.Dtp_00_Target__birthday.Value = New Date(1900, 1, 1, 18, 36, 0, 0)
        '
        'Lbl_Target_Total_Income
        '
        Me.Lbl_Target_Total_Income.BackColor = System.Drawing.Color.White
        Me.Lbl_Target_Total_Income.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Target_Total_Income.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Target_Total_Income.Location = New System.Drawing.Point(730, 363)
        Me.Lbl_Target_Total_Income.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Total_Income.MaximumSize = New System.Drawing.Size(132, 2)
        Me.Lbl_Target_Total_Income.MinimumSize = New System.Drawing.Size(119, 34)
        Me.Lbl_Target_Total_Income.Name = "Lbl_Target_Total_Income"
        Me.Lbl_Target_Total_Income.Size = New System.Drawing.Size(119, 34)
        Me.Lbl_Target_Total_Income.TabIndex = 15
        Me.Lbl_Target_Total_Income.Text = "0,00"
        Me.Lbl_Target_Total_Income.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Tbx_01_Target__name
        '
        Me.Tbx_01_Target__name.Location = New System.Drawing.Point(220, 283)
        Me.Tbx_01_Target__name.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_Target__name.Name = "Tbx_01_Target__name"
        Me.Tbx_01_Target__name.Size = New System.Drawing.Size(348, 35)
        Me.Tbx_01_Target__name.TabIndex = 1
        Me.Tbx_01_Target__name.Tag = "Naam"
        '
        'Lbl_Target_BirthDay
        '
        Me.Lbl_Target_BirthDay.AutoSize = True
        Me.Lbl_Target_BirthDay.Location = New System.Drawing.Point(9, 391)
        Me.Lbl_Target_BirthDay.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_BirthDay.Name = "Lbl_Target_BirthDay"
        Me.Lbl_Target_BirthDay.Size = New System.Drawing.Size(162, 28)
        Me.Lbl_Target_BirthDay.TabIndex = 9
        Me.Lbl_Target_BirthDay.Text = "Geboortedatum"
        '
        'Tbx_10_Target__otherincome
        '
        Me.Tbx_10_Target__otherincome.Location = New System.Drawing.Point(756, 266)
        Me.Tbx_10_Target__otherincome.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__otherincome.Name = "Tbx_10_Target__otherincome"
        Me.Tbx_10_Target__otherincome.Size = New System.Drawing.Size(91, 35)
        Me.Tbx_10_Target__otherincome.TabIndex = 34
        Me.Tbx_10_Target__otherincome.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tbx_01_Target__ttype
        '
        Me.Tbx_01_Target__ttype.Location = New System.Drawing.Point(495, 165)
        Me.Tbx_01_Target__ttype.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_Target__ttype.Name = "Tbx_01_Target__ttype"
        Me.Tbx_01_Target__ttype.Size = New System.Drawing.Size(64, 35)
        Me.Tbx_01_Target__ttype.TabIndex = 12
        Me.Tbx_01_Target__ttype.Tag = "Doeltype"
        Me.Tbx_01_Target__ttype.Visible = False
        '
        'Lbl_Target_Pension
        '
        Me.Lbl_Target_Pension.AutoSize = True
        Me.Lbl_Target_Pension.Location = New System.Drawing.Point(644, 129)
        Me.Lbl_Target_Pension.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Pension.Name = "Lbl_Target_Pension"
        Me.Lbl_Target_Pension.Size = New System.Drawing.Size(96, 28)
        Me.Lbl_Target_Pension.TabIndex = 6
        Me.Lbl_Target_Pension.Text = "Pensioen"
        '
        'Lbl_Target_Description
        '
        Me.Lbl_Target_Description.AutoSize = True
        Me.Lbl_Target_Description.Location = New System.Drawing.Point(9, 568)
        Me.Lbl_Target_Description.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Description.Name = "Lbl_Target_Description"
        Me.Lbl_Target_Description.Size = New System.Drawing.Size(112, 28)
        Me.Lbl_Target_Description.TabIndex = 5
        Me.Lbl_Target_Description.Text = "Toelichting"
        '
        'Lbl_Target_Type
        '
        Me.Lbl_Target_Type.AutoSize = True
        Me.Lbl_Target_Type.Location = New System.Drawing.Point(216, 134)
        Me.Lbl_Target_Type.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Type.Name = "Lbl_Target_Type"
        Me.Lbl_Target_Type.Size = New System.Drawing.Size(95, 28)
        Me.Lbl_Target_Type.TabIndex = 7
        Me.Lbl_Target_Type.Text = "Doeltype"
        '
        'Tbx_10_Target__pension
        '
        Me.Tbx_10_Target__pension.Location = New System.Drawing.Point(756, 131)
        Me.Tbx_10_Target__pension.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__pension.Name = "Tbx_10_Target__pension"
        Me.Tbx_10_Target__pension.Size = New System.Drawing.Size(91, 35)
        Me.Tbx_10_Target__pension.TabIndex = 31
        Me.Tbx_10_Target__pension.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lbl_00_Target__reference
        '
        Me.Lbl_00_Target__reference.AutoSize = True
        Me.Lbl_00_Target__reference.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_00_Target__reference.Location = New System.Drawing.Point(338, 40)
        Me.Lbl_00_Target__reference.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_00_Target__reference.Name = "Lbl_00_Target__reference"
        Me.Lbl_00_Target__reference.Size = New System.Drawing.Size(104, 28)
        Me.Lbl_00_Target__reference.TabIndex = 14
        Me.Lbl_00_Target__reference.Text = "Reference"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(864, 308)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(116, 28)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = "Medicijnen"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(216, 11)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(94, 28)
        Me.Label23.TabIndex = 15
        Me.Label23.Text = "Kenmerk"
        '
        'Lbl_Target_Extra
        '
        Me.Lbl_Target_Extra.AutoSize = True
        Me.Lbl_Target_Extra.Location = New System.Drawing.Point(644, 220)
        Me.Lbl_Target_Extra.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Extra.Name = "Lbl_Target_Extra"
        Me.Lbl_Target_Extra.Size = New System.Drawing.Size(82, 28)
        Me.Lbl_Target_Extra.TabIndex = 6
        Me.Lbl_Target_Extra.Text = "Toelage"
        '
        'Lbl_Target_pkid
        '
        Me.Lbl_Target_pkid.AutoSize = True
        Me.Lbl_Target_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_Target_pkid.Location = New System.Drawing.Point(338, 11)
        Me.Lbl_Target_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_pkid.Name = "Lbl_Target_pkid"
        Me.Lbl_Target_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_Target_pkid.TabIndex = 14
        Me.Lbl_Target_pkid.Text = "id"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(644, 368)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(81, 28)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Totalen"
        '
        'Tbx_00_Target__description
        '
        Me.Tbx_00_Target__description.Location = New System.Drawing.Point(14, 606)
        Me.Tbx_00_Target__description.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Target__description.Multiline = True
        Me.Tbx_00_Target__description.Name = "Tbx_00_Target__description"
        Me.Tbx_00_Target__description.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_00_Target__description.Size = New System.Drawing.Size(554, 113)
        Me.Tbx_00_Target__description.TabIndex = 16
        '
        'Tbx_10_Target__allowance
        '
        Me.Tbx_10_Target__allowance.Location = New System.Drawing.Point(756, 222)
        Me.Tbx_10_Target__allowance.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__allowance.Name = "Tbx_10_Target__allowance"
        Me.Tbx_10_Target__allowance.Size = New System.Drawing.Size(91, 35)
        Me.Tbx_10_Target__allowance.TabIndex = 33
        Me.Tbx_10_Target__allowance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(864, 83)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(84, 28)
        Me.Label12.TabIndex = 8
        Me.Label12.Text = "Voedsel"
        '
        'Lbl_Target_Salary
        '
        Me.Lbl_Target_Salary.AutoSize = True
        Me.Lbl_Target_Salary.Location = New System.Drawing.Point(644, 85)
        Me.Lbl_Target_Salary.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Salary.Name = "Lbl_Target_Salary"
        Me.Lbl_Target_Salary.Size = New System.Drawing.Size(72, 28)
        Me.Lbl_Target_Salary.TabIndex = 6
        Me.Lbl_Target_Salary.Text = "Salaris"
        '
        'Tbx_10_Target__income
        '
        Me.Tbx_10_Target__income.Location = New System.Drawing.Point(756, 85)
        Me.Tbx_10_Target__income.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__income.Name = "Tbx_10_Target__income"
        Me.Tbx_10_Target__income.Size = New System.Drawing.Size(90, 35)
        Me.Tbx_10_Target__income.TabIndex = 30
        Me.Tbx_10_Target__income.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(864, 223)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 28)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Electra"
        '
        'Lbl_Target_Income
        '
        Me.Lbl_Target_Income.AutoSize = True
        Me.Lbl_Target_Income.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Target_Income.Location = New System.Drawing.Point(644, 43)
        Me.Lbl_Target_Income.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Income.Name = "Lbl_Target_Income"
        Me.Lbl_Target_Income.Size = New System.Drawing.Size(92, 28)
        Me.Lbl_Target_Income.TabIndex = 4
        Me.Lbl_Target_Income.Text = "Inkomen"
        '
        'Tbx_00_Target__zip
        '
        Me.Tbx_00_Target__zip.Location = New System.Drawing.Point(220, 432)
        Me.Tbx_00_Target__zip.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Target__zip.Name = "Tbx_00_Target__zip"
        Me.Tbx_00_Target__zip.Size = New System.Drawing.Size(90, 35)
        Me.Tbx_00_Target__zip.TabIndex = 12
        '
        'Lbl_Target_Benefit
        '
        Me.Lbl_Target_Benefit.AutoSize = True
        Me.Lbl_Target_Benefit.Location = New System.Drawing.Point(644, 175)
        Me.Lbl_Target_Benefit.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Benefit.Name = "Lbl_Target_Benefit"
        Me.Lbl_Target_Benefit.Size = New System.Drawing.Size(96, 28)
        Me.Lbl_Target_Benefit.TabIndex = 6
        Me.Lbl_Target_Benefit.Text = "Uitkering"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(864, 178)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(124, 28)
        Me.Label17.TabIndex = 8
        Me.Label17.Text = "Verwarming"
        '
        'Tbx_00_Target__country
        '
        Me.Tbx_00_Target__country.Location = New System.Drawing.Point(435, 477)
        Me.Tbx_00_Target__country.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Target__country.Name = "Tbx_00_Target__country"
        Me.Tbx_00_Target__country.Size = New System.Drawing.Size(133, 35)
        Me.Tbx_00_Target__country.TabIndex = 14
        '
        'Lbl_Target_Otherincome
        '
        Me.Lbl_Target_Otherincome.AutoSize = True
        Me.Lbl_Target_Otherincome.Location = New System.Drawing.Point(644, 266)
        Me.Lbl_Target_Otherincome.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Otherincome.Name = "Lbl_Target_Otherincome"
        Me.Lbl_Target_Otherincome.Size = New System.Drawing.Size(77, 28)
        Me.Lbl_Target_Otherincome.TabIndex = 6
        Me.Lbl_Target_Otherincome.Text = "Anders"
        '
        'Tbx_10_Target__rent
        '
        Me.Tbx_10_Target__rent.Location = New System.Drawing.Point(993, 125)
        Me.Tbx_10_Target__rent.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__rent.Name = "Tbx_10_Target__rent"
        Me.Tbx_10_Target__rent.Size = New System.Drawing.Size(79, 35)
        Me.Tbx_10_Target__rent.TabIndex = 35
        Me.Tbx_10_Target__rent.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lbl_Target_Address
        '
        Me.Lbl_Target_Address.AutoSize = True
        Me.Lbl_Target_Address.Location = New System.Drawing.Point(9, 437)
        Me.Lbl_Target_Address.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Target_Address.Name = "Lbl_Target_Address"
        Me.Lbl_Target_Address.Size = New System.Drawing.Size(159, 28)
        Me.Lbl_Target_Address.TabIndex = 20
        Me.Lbl_Target_Address.Text = "Postcode/Adres"
        '
        'Tbx_10_Target__medicine
        '
        Me.Tbx_10_Target__medicine.Location = New System.Drawing.Point(993, 306)
        Me.Tbx_10_Target__medicine.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__medicine.Name = "Tbx_10_Target__medicine"
        Me.Tbx_10_Target__medicine.Size = New System.Drawing.Size(79, 35)
        Me.Tbx_10_Target__medicine.TabIndex = 40
        Me.Tbx_10_Target__medicine.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(864, 129)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 28)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Huur"
        '
        'Tbx_00_Target__address
        '
        Me.Tbx_00_Target__address.Location = New System.Drawing.Point(315, 432)
        Me.Tbx_00_Target__address.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Target__address.Name = "Tbx_00_Target__address"
        Me.Tbx_00_Target__address.Size = New System.Drawing.Size(253, 35)
        Me.Tbx_00_Target__address.TabIndex = 11
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(9, 489)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(162, 28)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "Plaats/Provincie"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(864, 40)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(97, 28)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "Uitgaven"
        '
        'Tbx_10_Target__food
        '
        Me.Tbx_10_Target__food.Location = New System.Drawing.Point(993, 78)
        Me.Tbx_10_Target__food.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__food.Name = "Tbx_10_Target__food"
        Me.Tbx_10_Target__food.Size = New System.Drawing.Size(79, 35)
        Me.Tbx_10_Target__food.TabIndex = 39
        Me.Tbx_10_Target__food.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tbx_10_Target__heating
        '
        Me.Tbx_10_Target__heating.Location = New System.Drawing.Point(993, 169)
        Me.Tbx_10_Target__heating.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__heating.Name = "Tbx_10_Target__heating"
        Me.Tbx_10_Target__heating.Size = New System.Drawing.Size(79, 35)
        Me.Tbx_10_Target__heating.TabIndex = 36
        Me.Tbx_10_Target__heating.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tbx_00_Target__city
        '
        Me.Tbx_00_Target__city.Location = New System.Drawing.Point(220, 477)
        Me.Tbx_00_Target__city.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Target__city.Name = "Tbx_00_Target__city"
        Me.Tbx_00_Target__city.Size = New System.Drawing.Size(204, 35)
        Me.Tbx_00_Target__city.TabIndex = 13
        '
        'Tbx_10_Target__gaselectra
        '
        Me.Tbx_10_Target__gaselectra.Location = New System.Drawing.Point(993, 215)
        Me.Tbx_10_Target__gaselectra.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_10_Target__gaselectra.Name = "Tbx_10_Target__gaselectra"
        Me.Tbx_10_Target__gaselectra.Size = New System.Drawing.Size(79, 35)
        Me.Tbx_10_Target__gaselectra.TabIndex = 37
        Me.Tbx_10_Target__gaselectra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Pic_Target__photo
        '
        Me.Pic_Target__photo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_Target__photo.Image = CType(resources.GetObject("Pic_Target__photo.Image"), System.Drawing.Image)
        Me.Pic_Target__photo.InitialImage = CType(resources.GetObject("Pic_Target__photo.InitialImage"), System.Drawing.Image)
        Me.Pic_Target__photo.Location = New System.Drawing.Point(9, 6)
        Me.Pic_Target__photo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pic_Target__photo.Name = "Pic_Target__photo"
        Me.Pic_Target__photo.Size = New System.Drawing.Size(188, 222)
        Me.Pic_Target__photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pic_Target__photo.TabIndex = 9
        Me.Pic_Target__photo.TabStop = False
        Me.Pic_Target__photo.Tag = "Click to add photo"
        '
        'Relation
        '
        Me.Relation.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Relation.Controls.Add(Me.Dgv_relation_giften)
        Me.Relation.Controls.Add(Me.Lbl_Overzicht_Giften)
        Me.Relation.Controls.Add(Me.Label60)
        Me.Relation.Controls.Add(Me.Label59)
        Me.Relation.Controls.Add(Me.Label58)
        Me.Relation.Controls.Add(Me.Label57)
        Me.Relation.Controls.Add(Me.Label56)
        Me.Relation.Controls.Add(Me.Label22)
        Me.Relation.Controls.Add(Me.Label15)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__city)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__zip)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__phone)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__address)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__email)
        Me.Relation.Controls.Add(Me.Tbx_01_relation__name)
        Me.Relation.Controls.Add(Me.Tbx_01_Relation__name_add)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__description)
        Me.Relation.Controls.Add(Me.Rbn_Relation_6)
        Me.Relation.Controls.Add(Me.Rbn_Relation_5)
        Me.Relation.Controls.Add(Me.Tbx_01_Relation__title)
        Me.Relation.Controls.Add(Me.Rbn_Relation_4)
        Me.Relation.Controls.Add(Me.Rbn_Relation_3)
        Me.Relation.Controls.Add(Me.Rbn_Relation_2)
        Me.Relation.Controls.Add(Me.Rbn_Relation_1)
        Me.Relation.Controls.Add(Me.Label81)
        Me.Relation.Controls.Add(Me.Cbx_00_relation__active)
        Me.Relation.Controls.Add(Me.Dtp_00_relation__date3)
        Me.Relation.Controls.Add(Me.Dtp_00_relation__date2)
        Me.Relation.Controls.Add(Me.Dtp_00_relation__date1)
        Me.Relation.Controls.Add(Me.Label66)
        Me.Relation.Controls.Add(Me.Label25)
        Me.Relation.Controls.Add(Me.Lbl_00_relation__reference)
        Me.Relation.Controls.Add(Me.Label24)
        Me.Relation.Controls.Add(Me.Lbl_relation_pkid)
        Me.Relation.Controls.Add(Me.Label69)
        Me.Relation.Controls.Add(Me.Label68)
        Me.Relation.Controls.Add(Me.Label67)
        Me.Relation.Controls.Add(Me.Label64)
        Me.Relation.Controls.Add(Me.Tbx_00_Relation__iban)
        Me.Relation.Location = New System.Drawing.Point(4, 40)
        Me.Relation.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Relation.Name = "Relation"
        Me.Relation.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Relation.Size = New System.Drawing.Size(1152, 804)
        Me.Relation.TabIndex = 3
        Me.Relation.Text = "Relatie"
        '
        'Dgv_relation_giften
        '
        Me.Dgv_relation_giften.AllowUserToAddRows = False
        Me.Dgv_relation_giften.AllowUserToDeleteRows = False
        DataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Dgv_relation_giften.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle25
        Me.Dgv_relation_giften.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_relation_giften.Location = New System.Drawing.Point(700, 343)
        Me.Dgv_relation_giften.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dgv_relation_giften.Name = "Dgv_relation_giften"
        Me.Dgv_relation_giften.RowHeadersVisible = False
        Me.Dgv_relation_giften.RowHeadersWidth = 62
        Me.Dgv_relation_giften.Size = New System.Drawing.Size(369, 358)
        Me.Dgv_relation_giften.TabIndex = 98
        '
        'Lbl_Overzicht_Giften
        '
        Me.Lbl_Overzicht_Giften.AutoSize = True
        Me.Lbl_Overzicht_Giften.Location = New System.Drawing.Point(696, 311)
        Me.Lbl_Overzicht_Giften.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Overzicht_Giften.Name = "Lbl_Overzicht_Giften"
        Me.Lbl_Overzicht_Giften.Size = New System.Drawing.Size(158, 28)
        Me.Lbl_Overzicht_Giften.TabIndex = 97
        Me.Lbl_Overzicht_Giften.Text = "Overzicht giften"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(28, 585)
        Me.Label60.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(112, 28)
        Me.Label60.TabIndex = 96
        Me.Label60.Text = "Toelichting"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(28, 545)
        Me.Label59.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(163, 28)
        Me.Label59.TabIndex = 95
        Me.Label59.Text = "Postcode/Plaats"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(28, 498)
        Me.Label58.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(65, 28)
        Me.Label58.TabIndex = 94
        Me.Label58.Text = "Adres"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(28, 452)
        Me.Label57.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(91, 28)
        Me.Label57.TabIndex = 93
        Me.Label57.Text = "Telefoon"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(28, 406)
        Me.Label56.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(62, 28)
        Me.Label56.TabIndex = 92
        Me.Label56.Text = "Email"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(28, 360)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(108, 28)
        Me.Label22.TabIndex = 91
        Me.Label22.Text = "Voornaam"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(28, 314)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(126, 28)
        Me.Label15.TabIndex = 90
        Me.Label15.Text = "Achternaam"
        '
        'Tbx_00_Relation__city
        '
        Me.Tbx_00_Relation__city.Location = New System.Drawing.Point(375, 538)
        Me.Tbx_00_Relation__city.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__city.Name = "Tbx_00_Relation__city"
        Me.Tbx_00_Relation__city.Size = New System.Drawing.Size(222, 35)
        Me.Tbx_00_Relation__city.TabIndex = 89
        '
        'Tbx_00_Relation__zip
        '
        Me.Tbx_00_Relation__zip.Location = New System.Drawing.Point(208, 538)
        Me.Tbx_00_Relation__zip.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__zip.Name = "Tbx_00_Relation__zip"
        Me.Tbx_00_Relation__zip.Size = New System.Drawing.Size(148, 35)
        Me.Tbx_00_Relation__zip.TabIndex = 88
        '
        'Tbx_00_Relation__phone
        '
        Me.Tbx_00_Relation__phone.Location = New System.Drawing.Point(208, 446)
        Me.Tbx_00_Relation__phone.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__phone.Name = "Tbx_00_Relation__phone"
        Me.Tbx_00_Relation__phone.Size = New System.Drawing.Size(388, 35)
        Me.Tbx_00_Relation__phone.TabIndex = 86
        '
        'Tbx_00_Relation__address
        '
        Me.Tbx_00_Relation__address.Location = New System.Drawing.Point(208, 492)
        Me.Tbx_00_Relation__address.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__address.Name = "Tbx_00_Relation__address"
        Me.Tbx_00_Relation__address.Size = New System.Drawing.Size(388, 35)
        Me.Tbx_00_Relation__address.TabIndex = 87
        '
        'Tbx_00_Relation__email
        '
        Me.Tbx_00_Relation__email.Location = New System.Drawing.Point(208, 400)
        Me.Tbx_00_Relation__email.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__email.Name = "Tbx_00_Relation__email"
        Me.Tbx_00_Relation__email.Size = New System.Drawing.Size(388, 35)
        Me.Tbx_00_Relation__email.TabIndex = 85
        '
        'Tbx_01_relation__name
        '
        Me.Tbx_01_relation__name.Location = New System.Drawing.Point(208, 308)
        Me.Tbx_01_relation__name.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_relation__name.Name = "Tbx_01_relation__name"
        Me.Tbx_01_relation__name.Size = New System.Drawing.Size(388, 35)
        Me.Tbx_01_relation__name.TabIndex = 83
        Me.Tbx_01_relation__name.Tag = "Achternaam"
        '
        'Tbx_01_Relation__name_add
        '
        Me.Tbx_01_Relation__name_add.Location = New System.Drawing.Point(208, 354)
        Me.Tbx_01_Relation__name_add.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_Relation__name_add.Name = "Tbx_01_Relation__name_add"
        Me.Tbx_01_Relation__name_add.Size = New System.Drawing.Size(388, 35)
        Me.Tbx_01_Relation__name_add.TabIndex = 84
        Me.Tbx_01_Relation__name_add.Tag = "Voornaam"
        '
        'Tbx_00_Relation__description
        '
        Me.Tbx_00_Relation__description.Location = New System.Drawing.Point(208, 585)
        Me.Tbx_00_Relation__description.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__description.Multiline = True
        Me.Tbx_00_Relation__description.Name = "Tbx_00_Relation__description"
        Me.Tbx_00_Relation__description.Size = New System.Drawing.Size(388, 116)
        Me.Tbx_00_Relation__description.TabIndex = 90
        '
        'Rbn_Relation_6
        '
        Me.Rbn_Relation_6.AutoSize = True
        Me.Rbn_Relation_6.Location = New System.Drawing.Point(360, 191)
        Me.Rbn_Relation_6.Name = "Rbn_Relation_6"
        Me.Rbn_Relation_6.Size = New System.Drawing.Size(62, 32)
        Me.Rbn_Relation_6.TabIndex = 79
        Me.Rbn_Relation_6.TabStop = True
        Me.Rbn_Relation_6.Text = "St."
        Me.Rbn_Relation_6.UseVisualStyleBackColor = True
        '
        'Rbn_Relation_5
        '
        Me.Rbn_Relation_5.AutoSize = True
        Me.Rbn_Relation_5.Location = New System.Drawing.Point(218, 234)
        Me.Rbn_Relation_5.Name = "Rbn_Relation_5"
        Me.Rbn_Relation_5.Size = New System.Drawing.Size(82, 32)
        Me.Rbn_Relation_5.TabIndex = 78
        Me.Rbn_Relation_5.TabStop = True
        Me.Rbn_Relation_5.Text = "Fam."
        Me.Rbn_Relation_5.UseVisualStyleBackColor = True
        '
        'Tbx_01_Relation__title
        '
        Me.Tbx_01_Relation__title.Location = New System.Drawing.Point(471, 85)
        Me.Tbx_01_Relation__title.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_Relation__title.Name = "Tbx_01_Relation__title"
        Me.Tbx_01_Relation__title.Size = New System.Drawing.Size(133, 35)
        Me.Tbx_01_Relation__title.TabIndex = 77
        Me.Tbx_01_Relation__title.Tag = "Aanhef"
        Me.Tbx_01_Relation__title.Visible = False
        '
        'Rbn_Relation_4
        '
        Me.Rbn_Relation_4.AutoSize = True
        Me.Rbn_Relation_4.Location = New System.Drawing.Point(360, 234)
        Me.Rbn_Relation_4.Name = "Rbn_Relation_4"
        Me.Rbn_Relation_4.Size = New System.Drawing.Size(86, 32)
        Me.Rbn_Relation_4.TabIndex = 76
        Me.Rbn_Relation_4.TabStop = True
        Me.Rbn_Relation_4.Text = "Geen"
        Me.Rbn_Relation_4.UseVisualStyleBackColor = True
        '
        'Rbn_Relation_3
        '
        Me.Rbn_Relation_3.AutoSize = True
        Me.Rbn_Relation_3.Location = New System.Drawing.Point(360, 148)
        Me.Rbn_Relation_3.Name = "Rbn_Relation_3"
        Me.Rbn_Relation_3.Size = New System.Drawing.Size(155, 32)
        Me.Rbn_Relation_3.TabIndex = 75
        Me.Rbn_Relation_3.TabStop = True
        Me.Rbn_Relation_3.Text = "Dhr en mevr."
        Me.Rbn_Relation_3.UseVisualStyleBackColor = True
        '
        'Rbn_Relation_2
        '
        Me.Rbn_Relation_2.AutoSize = True
        Me.Rbn_Relation_2.Location = New System.Drawing.Point(218, 191)
        Me.Rbn_Relation_2.Name = "Rbn_Relation_2"
        Me.Rbn_Relation_2.Size = New System.Drawing.Size(90, 32)
        Me.Rbn_Relation_2.TabIndex = 75
        Me.Rbn_Relation_2.TabStop = True
        Me.Rbn_Relation_2.Text = "Mevr."
        Me.Rbn_Relation_2.UseVisualStyleBackColor = True
        '
        'Rbn_Relation_1
        '
        Me.Rbn_Relation_1.AutoSize = True
        Me.Rbn_Relation_1.Location = New System.Drawing.Point(218, 148)
        Me.Rbn_Relation_1.Name = "Rbn_Relation_1"
        Me.Rbn_Relation_1.Size = New System.Drawing.Size(75, 32)
        Me.Rbn_Relation_1.TabIndex = 75
        Me.Rbn_Relation_1.TabStop = True
        Me.Rbn_Relation_1.Text = "Dhr."
        Me.Rbn_Relation_1.UseVisualStyleBackColor = True
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(33, 145)
        Me.Label81.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(78, 28)
        Me.Label81.TabIndex = 74
        Me.Label81.Text = "Aanhef"
        '
        'Cbx_00_relation__active
        '
        Me.Cbx_00_relation__active.AutoSize = True
        Me.Cbx_00_relation__active.Checked = True
        Me.Cbx_00_relation__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_relation__active.Location = New System.Drawing.Point(213, 102)
        Me.Cbx_00_relation__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_relation__active.Name = "Cbx_00_relation__active"
        Me.Cbx_00_relation__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_relation__active.TabIndex = 73
        Me.Cbx_00_relation__active.Text = "Actief"
        Me.Cbx_00_relation__active.UseVisualStyleBackColor = True
        '
        'Dtp_00_relation__date3
        '
        Me.Dtp_00_relation__date3.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_00_relation__date3.Location = New System.Drawing.Point(908, 232)
        Me.Dtp_00_relation__date3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_00_relation__date3.Name = "Dtp_00_relation__date3"
        Me.Dtp_00_relation__date3.Size = New System.Drawing.Size(162, 35)
        Me.Dtp_00_relation__date3.TabIndex = 72
        Me.Dtp_00_relation__date3.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        '
        'Dtp_00_relation__date2
        '
        Me.Dtp_00_relation__date2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_00_relation__date2.Location = New System.Drawing.Point(908, 185)
        Me.Dtp_00_relation__date2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_00_relation__date2.Name = "Dtp_00_relation__date2"
        Me.Dtp_00_relation__date2.Size = New System.Drawing.Size(162, 35)
        Me.Dtp_00_relation__date2.TabIndex = 72
        Me.Dtp_00_relation__date2.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        '
        'Dtp_00_relation__date1
        '
        Me.Dtp_00_relation__date1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.Dtp_00_relation__date1.Location = New System.Drawing.Point(908, 135)
        Me.Dtp_00_relation__date1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Dtp_00_relation__date1.Name = "Dtp_00_relation__date1"
        Me.Dtp_00_relation__date1.Size = New System.Drawing.Size(162, 35)
        Me.Dtp_00_relation__date1.TabIndex = 72
        Me.Dtp_00_relation__date1.Value = New Date(2999, 12, 31, 0, 0, 0, 0)
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(696, 37)
        Me.Label66.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(326, 28)
        Me.Label66.TabIndex = 71
        Me.Label66.Text = "Machtiging automatische incasso"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(32, 69)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(59, 28)
        Me.Label25.TabIndex = 70
        Me.Label25.Text = "Code"
        '
        'Lbl_00_relation__reference
        '
        Me.Lbl_00_relation__reference.AutoSize = True
        Me.Lbl_00_relation__reference.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_00_relation__reference.Location = New System.Drawing.Point(208, 69)
        Me.Lbl_00_relation__reference.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_00_relation__reference.Name = "Lbl_00_relation__reference"
        Me.Lbl_00_relation__reference.Size = New System.Drawing.Size(104, 28)
        Me.Lbl_00_relation__reference.TabIndex = 69
        Me.Lbl_00_relation__reference.Text = "Reference"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(28, 37)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(94, 28)
        Me.Label24.TabIndex = 68
        Me.Label24.Text = "Kenmerk"
        '
        'Lbl_relation_pkid
        '
        Me.Lbl_relation_pkid.AutoSize = True
        Me.Lbl_relation_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_relation_pkid.Location = New System.Drawing.Point(208, 37)
        Me.Lbl_relation_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_relation_pkid.Name = "Lbl_relation_pkid"
        Me.Lbl_relation_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_relation_pkid.TabIndex = 67
        Me.Lbl_relation_pkid.Text = "id"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(696, 242)
        Me.Label69.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(72, 28)
        Me.Label69.TabIndex = 60
        Me.Label69.Text = "Overig"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(696, 194)
        Me.Label68.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(195, 28)
        Me.Label68.TabIndex = 60
        Me.Label68.Text = "Ouderensponsoring"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(696, 145)
        Me.Label67.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(174, 28)
        Me.Label67.TabIndex = 60
        Me.Label67.Text = "Kindersponsoring"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(696, 91)
        Me.Label64.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(59, 28)
        Me.Label64.TabIndex = 66
        Me.Label64.Text = "IBAN"
        '
        'Tbx_00_Relation__iban
        '
        Me.Tbx_00_Relation__iban.Location = New System.Drawing.Point(786, 86)
        Me.Tbx_00_Relation__iban.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_Relation__iban.Name = "Tbx_00_Relation__iban"
        Me.Tbx_00_Relation__iban.Size = New System.Drawing.Size(283, 35)
        Me.Tbx_00_Relation__iban.TabIndex = 48
        Me.Tbx_00_Relation__iban.Tag = "IBAN"
        '
        'CP
        '
        Me.CP.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.CP.Controls.Add(Me.Cbx_00_cp__active)
        Me.CP.Controls.Add(Me.Tbx_00_cp__description)
        Me.CP.Controls.Add(Me.Cmx_01_cp__fk_bankacc_id)
        Me.CP.Controls.Add(Me.Label34)
        Me.CP.Controls.Add(Me.Lbl_CP_pkid)
        Me.CP.Controls.Add(Me.Tbx_00_CP__telephone)
        Me.CP.Controls.Add(Me.Label30)
        Me.CP.Controls.Add(Me.Tbx_01_CP__name)
        Me.CP.Controls.Add(Me.Tbx_00_CP__zip)
        Me.CP.Controls.Add(Me.Label31)
        Me.CP.Controls.Add(Me.Tbx_00_CP__country)
        Me.CP.Controls.Add(Me.Label29)
        Me.CP.Controls.Add(Me.Tbx_00_CP__email)
        Me.CP.Controls.Add(Me.Tbx_00_CP__address)
        Me.CP.Controls.Add(Me.Label39)
        Me.CP.Controls.Add(Me.Tbx_00_CP__city)
        Me.CP.Controls.Add(Me.Label21)
        Me.CP.Controls.Add(Me.Label28)
        Me.CP.Controls.Add(Me.Label38)
        Me.CP.Controls.Add(Me.Label27)
        Me.CP.Controls.Add(Me.Label37)
        Me.CP.Controls.Add(Me.Label32)
        Me.CP.Controls.Add(Me.Tbx_01_CP__name_add)
        Me.CP.Controls.Add(Me.Pic_cp__photo)
        Me.CP.Location = New System.Drawing.Point(4, 40)
        Me.CP.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CP.Name = "CP"
        Me.CP.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CP.Size = New System.Drawing.Size(1152, 804)
        Me.CP.TabIndex = 4
        Me.CP.Tag = "CP"
        Me.CP.Text = "Contactpersoon"
        '
        'Cbx_00_cp__active
        '
        Me.Cbx_00_cp__active.AutoSize = True
        Me.Cbx_00_cp__active.Checked = True
        Me.Cbx_00_cp__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_cp__active.Location = New System.Drawing.Point(228, 52)
        Me.Cbx_00_cp__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_cp__active.Name = "Cbx_00_cp__active"
        Me.Cbx_00_cp__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_cp__active.TabIndex = 52
        Me.Cbx_00_cp__active.Text = "Actief"
        Me.Cbx_00_cp__active.UseVisualStyleBackColor = True
        '
        'Tbx_00_cp__description
        '
        Me.Tbx_00_cp__description.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_cp__description.Location = New System.Drawing.Point(627, 225)
        Me.Tbx_00_cp__description.Multiline = True
        Me.Tbx_00_cp__description.Name = "Tbx_00_cp__description"
        Me.Tbx_00_cp__description.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_00_cp__description.Size = New System.Drawing.Size(451, 433)
        Me.Tbx_00_cp__description.TabIndex = 10
        '
        'Cmx_01_cp__fk_bankacc_id
        '
        Me.Cmx_01_cp__fk_bankacc_id.FormattingEnabled = True
        Me.Cmx_01_cp__fk_bankacc_id.Location = New System.Drawing.Point(210, 323)
        Me.Cmx_01_cp__fk_bankacc_id.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_01_cp__fk_bankacc_id.Name = "Cmx_01_cp__fk_bankacc_id"
        Me.Cmx_01_cp__fk_bankacc_id.Size = New System.Drawing.Size(386, 36)
        Me.Cmx_01_cp__fk_bankacc_id.TabIndex = 3
        Me.Cmx_01_cp__fk_bankacc_id.Tag = "IBAN"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(224, 15)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(94, 28)
        Me.Label34.TabIndex = 46
        Me.Label34.Text = "Kenmerk"
        '
        'Lbl_CP_pkid
        '
        Me.Lbl_CP_pkid.AutoSize = True
        Me.Lbl_CP_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_CP_pkid.Location = New System.Drawing.Point(327, 15)
        Me.Lbl_CP_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_CP_pkid.Name = "Lbl_CP_pkid"
        Me.Lbl_CP_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_CP_pkid.TabIndex = 45
        Me.Lbl_CP_pkid.Text = "id"
        '
        'Tbx_00_CP__telephone
        '
        Me.Tbx_00_CP__telephone.AcceptsTab = True
        Me.Tbx_00_CP__telephone.Location = New System.Drawing.Point(210, 423)
        Me.Tbx_00_CP__telephone.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_CP__telephone.Name = "Tbx_00_CP__telephone"
        Me.Tbx_00_CP__telephone.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_00_CP__telephone.TabIndex = 5
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(26, 526)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(98, 28)
        Me.Label30.TabIndex = 36
        Me.Label30.Text = "Postcode"
        '
        'Tbx_01_CP__name
        '
        Me.Tbx_01_CP__name.Location = New System.Drawing.Point(210, 225)
        Me.Tbx_01_CP__name.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_CP__name.Name = "Tbx_01_CP__name"
        Me.Tbx_01_CP__name.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_01_CP__name.TabIndex = 1
        Me.Tbx_01_CP__name.Tag = "Achternaam"
        '
        'Tbx_00_CP__zip
        '
        Me.Tbx_00_CP__zip.Location = New System.Drawing.Point(210, 522)
        Me.Tbx_00_CP__zip.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_CP__zip.Name = "Tbx_00_CP__zip"
        Me.Tbx_00_CP__zip.Size = New System.Drawing.Size(133, 35)
        Me.Tbx_00_CP__zip.TabIndex = 7
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(26, 229)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(126, 28)
        Me.Label31.TabIndex = 41
        Me.Label31.Text = "Achternaam"
        '
        'Tbx_00_CP__country
        '
        Me.Tbx_00_CP__country.Location = New System.Drawing.Point(210, 622)
        Me.Tbx_00_CP__country.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_CP__country.Name = "Tbx_00_CP__country"
        Me.Tbx_00_CP__country.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_00_CP__country.TabIndex = 9
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(26, 458)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(65, 28)
        Me.Label29.TabIndex = 35
        Me.Label29.Text = "Adres"
        '
        'Tbx_00_CP__email
        '
        Me.Tbx_00_CP__email.AcceptsTab = True
        Me.Tbx_00_CP__email.Location = New System.Drawing.Point(210, 372)
        Me.Tbx_00_CP__email.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_CP__email.Name = "Tbx_00_CP__email"
        Me.Tbx_00_CP__email.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_00_CP__email.TabIndex = 4
        '
        'Tbx_00_CP__address
        '
        Me.Tbx_00_CP__address.Location = New System.Drawing.Point(210, 472)
        Me.Tbx_00_CP__address.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_CP__address.Name = "Tbx_00_CP__address"
        Me.Tbx_00_CP__address.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_00_CP__address.TabIndex = 6
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(26, 423)
        Me.Label39.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(91, 28)
        Me.Label39.TabIndex = 42
        Me.Label39.Text = "Telefoon"
        '
        'Tbx_00_CP__city
        '
        Me.Tbx_00_CP__city.Location = New System.Drawing.Point(210, 571)
        Me.Tbx_00_CP__city.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_00_CP__city.Name = "Tbx_00_CP__city"
        Me.Tbx_00_CP__city.Size = New System.Drawing.Size(238, 35)
        Me.Tbx_00_CP__city.TabIndex = 8
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(622, 180)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(112, 28)
        Me.Label21.TabIndex = 37
        Me.Label21.Text = "Toelichting"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(26, 626)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(97, 28)
        Me.Label28.TabIndex = 37
        Me.Label28.Text = "Provincie"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(26, 377)
        Me.Label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(62, 28)
        Me.Label38.TabIndex = 42
        Me.Label38.Text = "Email"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(26, 557)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(68, 28)
        Me.Label27.TabIndex = 38
        Me.Label27.Text = "Plaats"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(26, 328)
        Me.Label37.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(59, 28)
        Me.Label37.TabIndex = 42
        Me.Label37.Text = "IBAN"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(26, 278)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(108, 28)
        Me.Label32.TabIndex = 42
        Me.Label32.Text = "Voornaam"
        '
        'Tbx_01_CP__name_add
        '
        Me.Tbx_01_CP__name_add.Location = New System.Drawing.Point(210, 274)
        Me.Tbx_01_CP__name_add.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Tbx_01_CP__name_add.Name = "Tbx_01_CP__name_add"
        Me.Tbx_01_CP__name_add.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_01_CP__name_add.TabIndex = 2
        Me.Tbx_01_CP__name_add.Tag = "Voornaam"
        '
        'Pic_cp__photo
        '
        Me.Pic_cp__photo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pic_cp__photo.ErrorImage = Nothing
        Me.Pic_cp__photo.Image = CType(resources.GetObject("Pic_cp__photo.Image"), System.Drawing.Image)
        Me.Pic_cp__photo.Location = New System.Drawing.Point(15, 9)
        Me.Pic_cp__photo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pic_cp__photo.Name = "Pic_cp__photo"
        Me.Pic_cp__photo.Size = New System.Drawing.Size(198, 213)
        Me.Pic_cp__photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pic_cp__photo.TabIndex = 43
        Me.Pic_cp__photo.TabStop = False
        Me.Pic_cp__photo.Tag = "Doubleclick to add photo"
        '
        'Account
        '
        Me.Account.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Account.Controls.Add(Me.Label50)
        Me.Account.Controls.Add(Me.Cmx_01_account__fk_accgroup_id)
        Me.Account.Controls.Add(Me.Lbl_Account_Doeltype)
        Me.Account.Controls.Add(Me.Lbl_20_Account__f_key)
        Me.Account.Controls.Add(Me.Lbl_Account_Budget_Difference)
        Me.Account.Controls.Add(Me.Label136)
        Me.Account.Controls.Add(Me.Label101)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_nov)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_dec)
        Me.Account.Controls.Add(Me.Tbx_00_Account__bankcode)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_oct)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_aug)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_sep)
        Me.Account.Controls.Add(Me.Pan_account)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_jul)
        Me.Account.Controls.Add(Me.Cbx_00_Account__active)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_may)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_jun)
        Me.Account.Controls.Add(Me.Label51)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_apr)
        Me.Account.Controls.Add(Me.Tbx_00_Account__searchword)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_feb)
        Me.Account.Controls.Add(Me.Lbl_00_pkid)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_mar)
        Me.Account.Controls.Add(Me.Label41)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_jan)
        Me.Account.Controls.Add(Me.Label110)
        Me.Account.Controls.Add(Me.Label47)
        Me.Account.Controls.Add(Me.Label111)
        Me.Account.Controls.Add(Me.Tbx_00_Account__description)
        Me.Account.Controls.Add(Me.Label112)
        Me.Account.Controls.Add(Me.Tbx_01_Account__name)
        Me.Account.Controls.Add(Me.Label113)
        Me.Account.Controls.Add(Me.Label46)
        Me.Account.Controls.Add(Me.Label114)
        Me.Account.Controls.Add(Me.Label49)
        Me.Account.Controls.Add(Me.Label115)
        Me.Account.Controls.Add(Me.Label122)
        Me.Account.Controls.Add(Me.Tbx_10_Account__b_year)
        Me.Account.Controls.Add(Me.Label109)
        Me.Account.Controls.Add(Me.Label48)
        Me.Account.Controls.Add(Me.Label93)
        Me.Account.Controls.Add(Me.Tbx_00_Account__type)
        Me.Account.Controls.Add(Me.Label92)
        Me.Account.Controls.Add(Me.Lbl_00_Account__source)
        Me.Account.Controls.Add(Me.Label91)
        Me.Account.Controls.Add(Me.Label33)
        Me.Account.Controls.Add(Me.Label90)
        Me.Account.Controls.Add(Me.Label43)
        Me.Account.Controls.Add(Me.Label88)
        Me.Account.Controls.Add(Me.Label87)
        Me.Account.Controls.Add(Me.Btn_Account_Budget_All)
        Me.Account.Controls.Add(Me.Btn_Account_Budget_Id)
        Me.Account.Location = New System.Drawing.Point(4, 40)
        Me.Account.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Account.Name = "Account"
        Me.Account.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Account.Size = New System.Drawing.Size(1152, 804)
        Me.Account.TabIndex = 5
        Me.Account.Text = "Account"
        '
        'Label50
        '
        Me.Label50.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(345, 357)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(318, 54)
        Me.Label50.TabIndex = 129
        Me.Label50.Text = "(tweeletterige banktransactie code, gescheiden door komma's, max. 3 )"
        '
        'Cmx_01_account__fk_accgroup_id
        '
        Me.Cmx_01_account__fk_accgroup_id.FormattingEnabled = True
        Me.Cmx_01_account__fk_accgroup_id.Location = New System.Drawing.Point(210, 123)
        Me.Cmx_01_account__fk_accgroup_id.Name = "Cmx_01_account__fk_accgroup_id"
        Me.Cmx_01_account__fk_accgroup_id.Size = New System.Drawing.Size(451, 36)
        Me.Cmx_01_account__fk_accgroup_id.TabIndex = 128
        Me.Cmx_01_account__fk_accgroup_id.Tag = "Accountgroep"
        '
        'Lbl_Account_Doeltype
        '
        Me.Lbl_Account_Doeltype.AutoSize = True
        Me.Lbl_Account_Doeltype.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Account_Doeltype.Location = New System.Drawing.Point(450, 308)
        Me.Lbl_Account_Doeltype.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_Account_Doeltype.Name = "Lbl_Account_Doeltype"
        Me.Lbl_Account_Doeltype.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_Account_Doeltype.TabIndex = 127
        Me.Lbl_Account_Doeltype.Text = "id"
        Me.Lbl_Account_Doeltype.Visible = False
        '
        'Lbl_20_Account__f_key
        '
        Me.Lbl_20_Account__f_key.AutoSize = True
        Me.Lbl_20_Account__f_key.ForeColor = System.Drawing.Color.Black
        Me.Lbl_20_Account__f_key.Location = New System.Drawing.Point(363, 308)
        Me.Lbl_20_Account__f_key.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_20_Account__f_key.Name = "Lbl_20_Account__f_key"
        Me.Lbl_20_Account__f_key.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_20_Account__f_key.TabIndex = 125
        Me.Lbl_20_Account__f_key.Text = "id"
        '
        'Lbl_Account_Budget_Difference
        '
        Me.Lbl_Account_Budget_Difference.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Account_Budget_Difference.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Account_Budget_Difference.Location = New System.Drawing.Point(986, 357)
        Me.Lbl_Account_Budget_Difference.Name = "Lbl_Account_Budget_Difference"
        Me.Lbl_Account_Budget_Difference.Size = New System.Drawing.Size(88, 36)
        Me.Lbl_Account_Budget_Difference.TabIndex = 124
        Me.Lbl_Account_Budget_Difference.Text = "0"
        Me.Lbl_Account_Budget_Difference.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label136.Location = New System.Drawing.Point(930, 362)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(43, 28)
        Me.Label136.TabIndex = 108
        Me.Label136.Text = "Var"
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.Location = New System.Drawing.Point(741, 35)
        Me.Label101.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(106, 27)
        Me.Label101.TabIndex = 106
        Me.Label101.Text = "Budgetten"
        '
        'Tbx_10_Account__b_nov
        '
        Me.Tbx_10_Account__b_nov.Location = New System.Drawing.Point(986, 258)
        Me.Tbx_10_Account__b_nov.Name = "Tbx_10_Account__b_nov"
        Me.Tbx_10_Account__b_nov.Size = New System.Drawing.Size(88, 35)
        Me.Tbx_10_Account__b_nov.TabIndex = 103
        Me.Tbx_10_Account__b_nov.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_10_Account__b_dec
        '
        Me.Tbx_10_Account__b_dec.Location = New System.Drawing.Point(986, 303)
        Me.Tbx_10_Account__b_dec.Name = "Tbx_10_Account__b_dec"
        Me.Tbx_10_Account__b_dec.Size = New System.Drawing.Size(86, 35)
        Me.Tbx_10_Account__b_dec.TabIndex = 102
        Me.Tbx_10_Account__b_dec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_00_Account__bankcode
        '
        Me.Tbx_00_Account__bankcode.Location = New System.Drawing.Point(208, 357)
        Me.Tbx_00_Account__bankcode.Name = "Tbx_00_Account__bankcode"
        Me.Tbx_00_Account__bankcode.Size = New System.Drawing.Size(128, 35)
        Me.Tbx_00_Account__bankcode.TabIndex = 79
        Me.Tbx_00_Account__bankcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Tbx_10_Account__b_oct
        '
        Me.Tbx_10_Account__b_oct.Location = New System.Drawing.Point(986, 214)
        Me.Tbx_10_Account__b_oct.Name = "Tbx_10_Account__b_oct"
        Me.Tbx_10_Account__b_oct.Size = New System.Drawing.Size(88, 35)
        Me.Tbx_10_Account__b_oct.TabIndex = 101
        Me.Tbx_10_Account__b_oct.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_10_Account__b_aug
        '
        Me.Tbx_10_Account__b_aug.Location = New System.Drawing.Point(986, 125)
        Me.Tbx_10_Account__b_aug.Name = "Tbx_10_Account__b_aug"
        Me.Tbx_10_Account__b_aug.Size = New System.Drawing.Size(88, 35)
        Me.Tbx_10_Account__b_aug.TabIndex = 100
        Me.Tbx_10_Account__b_aug.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_10_Account__b_sep
        '
        Me.Tbx_10_Account__b_sep.Location = New System.Drawing.Point(986, 168)
        Me.Tbx_10_Account__b_sep.Name = "Tbx_10_Account__b_sep"
        Me.Tbx_10_Account__b_sep.Size = New System.Drawing.Size(88, 35)
        Me.Tbx_10_Account__b_sep.TabIndex = 99
        Me.Tbx_10_Account__b_sep.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Pan_account
        '
        Me.Pan_account.Controls.Add(Me.Rbtn_Account_Income)
        Me.Pan_account.Controls.Add(Me.Rbtn_Account_Transit)
        Me.Pan_account.Controls.Add(Me.Rbtn_Account_Expense)
        Me.Pan_account.Location = New System.Drawing.Point(210, 178)
        Me.Pan_account.Name = "Pan_account"
        Me.Pan_account.Size = New System.Drawing.Size(252, 108)
        Me.Pan_account.TabIndex = 53
        '
        'Rbtn_Account_Income
        '
        Me.Rbtn_Account_Income.AutoSize = True
        Me.Rbtn_Account_Income.BackColor = System.Drawing.Color.Transparent
        Me.Rbtn_Account_Income.Location = New System.Drawing.Point(4, 0)
        Me.Rbtn_Account_Income.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Account_Income.Name = "Rbtn_Account_Income"
        Me.Rbtn_Account_Income.Size = New System.Drawing.Size(191, 32)
        Me.Rbtn_Account_Income.TabIndex = 26
        Me.Rbtn_Account_Income.TabStop = True
        Me.Rbtn_Account_Income.Text = "Generiek (fonds)"
        Me.Rbtn_Account_Income.UseVisualStyleBackColor = False
        '
        'Rbtn_Account_Transit
        '
        Me.Rbtn_Account_Transit.AutoSize = True
        Me.Rbtn_Account_Transit.Location = New System.Drawing.Point(4, 74)
        Me.Rbtn_Account_Transit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Account_Transit.Name = "Rbtn_Account_Transit"
        Me.Rbtn_Account_Transit.Size = New System.Drawing.Size(102, 32)
        Me.Rbtn_Account_Transit.TabIndex = 26
        Me.Rbtn_Account_Transit.TabStop = True
        Me.Rbtn_Account_Transit.Text = "Anders"
        Me.Rbtn_Account_Transit.UseVisualStyleBackColor = True
        '
        'Rbtn_Account_Expense
        '
        Me.Rbtn_Account_Expense.AutoSize = True
        Me.Rbtn_Account_Expense.Location = New System.Drawing.Point(4, 38)
        Me.Rbtn_Account_Expense.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_Account_Expense.Name = "Rbtn_Account_Expense"
        Me.Rbtn_Account_Expense.Size = New System.Drawing.Size(178, 32)
        Me.Rbtn_Account_Expense.TabIndex = 26
        Me.Rbtn_Account_Expense.TabStop = True
        Me.Rbtn_Account_Expense.Text = "Specifiek (doel)"
        Me.Rbtn_Account_Expense.UseVisualStyleBackColor = True
        '
        'Tbx_10_Account__b_jul
        '
        Me.Tbx_10_Account__b_jul.Location = New System.Drawing.Point(986, 80)
        Me.Tbx_10_Account__b_jul.Name = "Tbx_10_Account__b_jul"
        Me.Tbx_10_Account__b_jul.Size = New System.Drawing.Size(88, 35)
        Me.Tbx_10_Account__b_jul.TabIndex = 98
        Me.Tbx_10_Account__b_jul.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Cbx_00_Account__active
        '
        Me.Cbx_00_Account__active.AutoSize = True
        Me.Cbx_00_Account__active.Checked = True
        Me.Cbx_00_Account__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_Account__active.Enabled = False
        Me.Cbx_00_Account__active.Location = New System.Drawing.Point(501, 32)
        Me.Cbx_00_Account__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_Account__active.Name = "Cbx_00_Account__active"
        Me.Cbx_00_Account__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_Account__active.TabIndex = 52
        Me.Cbx_00_Account__active.Text = "Actief"
        Me.Cbx_00_Account__active.UseVisualStyleBackColor = True
        '
        'Tbx_10_Account__b_may
        '
        Me.Tbx_10_Account__b_may.Location = New System.Drawing.Point(798, 258)
        Me.Tbx_10_Account__b_may.Name = "Tbx_10_Account__b_may"
        Me.Tbx_10_Account__b_may.Size = New System.Drawing.Size(103, 35)
        Me.Tbx_10_Account__b_may.TabIndex = 97
        Me.Tbx_10_Account__b_may.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_10_Account__b_jun
        '
        Me.Tbx_10_Account__b_jun.Location = New System.Drawing.Point(798, 303)
        Me.Tbx_10_Account__b_jun.Name = "Tbx_10_Account__b_jun"
        Me.Tbx_10_Account__b_jun.Size = New System.Drawing.Size(103, 35)
        Me.Tbx_10_Account__b_jun.TabIndex = 96
        Me.Tbx_10_Account__b_jun.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(45, 32)
        Me.Label51.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(94, 28)
        Me.Label51.TabIndex = 48
        Me.Label51.Text = "Kenmerk"
        '
        'Tbx_10_Account__b_apr
        '
        Me.Tbx_10_Account__b_apr.Location = New System.Drawing.Point(798, 214)
        Me.Tbx_10_Account__b_apr.Name = "Tbx_10_Account__b_apr"
        Me.Tbx_10_Account__b_apr.Size = New System.Drawing.Size(103, 35)
        Me.Tbx_10_Account__b_apr.TabIndex = 95
        Me.Tbx_10_Account__b_apr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tbx_00_Account__searchword
        '
        Me.Tbx_00_Account__searchword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_Account__searchword.Location = New System.Drawing.Point(210, 414)
        Me.Tbx_00_Account__searchword.Multiline = True
        Me.Tbx_00_Account__searchword.Name = "Tbx_00_Account__searchword"
        Me.Tbx_00_Account__searchword.Size = New System.Drawing.Size(451, 98)
        Me.Tbx_00_Account__searchword.TabIndex = 8
        '
        'Tbx_10_Account__b_feb
        '
        Me.Tbx_10_Account__b_feb.Location = New System.Drawing.Point(798, 125)
        Me.Tbx_10_Account__b_feb.Name = "Tbx_10_Account__b_feb"
        Me.Tbx_10_Account__b_feb.Size = New System.Drawing.Size(103, 35)
        Me.Tbx_10_Account__b_feb.TabIndex = 94
        Me.Tbx_10_Account__b_feb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Lbl_00_pkid
        '
        Me.Lbl_00_pkid.AutoSize = True
        Me.Lbl_00_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_00_pkid.Location = New System.Drawing.Point(210, 32)
        Me.Lbl_00_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_00_pkid.Name = "Lbl_00_pkid"
        Me.Lbl_00_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_00_pkid.TabIndex = 47
        Me.Lbl_00_pkid.Text = "id"
        '
        'Tbx_10_Account__b_mar
        '
        Me.Tbx_10_Account__b_mar.Location = New System.Drawing.Point(798, 168)
        Me.Tbx_10_Account__b_mar.Name = "Tbx_10_Account__b_mar"
        Me.Tbx_10_Account__b_mar.Size = New System.Drawing.Size(103, 35)
        Me.Tbx_10_Account__b_mar.TabIndex = 93
        Me.Tbx_10_Account__b_mar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(44, 69)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(67, 28)
        Me.Label41.TabIndex = 5
        Me.Label41.Text = "Naam"
        '
        'Tbx_10_Account__b_jan
        '
        Me.Tbx_10_Account__b_jan.Location = New System.Drawing.Point(798, 80)
        Me.Tbx_10_Account__b_jan.Name = "Tbx_10_Account__b_jan"
        Me.Tbx_10_Account__b_jan.Size = New System.Drawing.Size(103, 35)
        Me.Tbx_10_Account__b_jan.TabIndex = 80
        Me.Tbx_10_Account__b_jan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.Location = New System.Drawing.Point(928, 305)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(47, 28)
        Me.Label110.TabIndex = 86
        Me.Label110.Text = "Dec"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(44, 189)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(55, 28)
        Me.Label47.TabIndex = 5
        Me.Label47.Text = "Type"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label111.Location = New System.Drawing.Point(928, 260)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(49, 28)
        Me.Label111.TabIndex = 87
        Me.Label111.Text = "Nov"
        '
        'Tbx_00_Account__description
        '
        Me.Tbx_00_Account__description.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_Account__description.Location = New System.Drawing.Point(210, 578)
        Me.Tbx_00_Account__description.Multiline = True
        Me.Tbx_00_Account__description.Name = "Tbx_00_Account__description"
        Me.Tbx_00_Account__description.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_00_Account__description.Size = New System.Drawing.Size(451, 135)
        Me.Tbx_00_Account__description.TabIndex = 35
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.Location = New System.Drawing.Point(928, 215)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(45, 28)
        Me.Label112.TabIndex = 88
        Me.Label112.Text = "Okt"
        '
        'Tbx_01_Account__name
        '
        Me.Tbx_01_Account__name.Enabled = False
        Me.Tbx_01_Account__name.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_01_Account__name.Location = New System.Drawing.Point(210, 69)
        Me.Tbx_01_Account__name.Name = "Tbx_01_Account__name"
        Me.Tbx_01_Account__name.Size = New System.Drawing.Size(451, 30)
        Me.Tbx_01_Account__name.TabIndex = 6
        Me.Tbx_01_Account__name.Tag = "Naam"
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label113.Location = New System.Drawing.Point(928, 169)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(46, 28)
        Me.Label113.TabIndex = 89
        Me.Label113.Text = "Sep"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(44, 125)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(70, 28)
        Me.Label46.TabIndex = 33
        Me.Label46.Text = "Groep"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.Location = New System.Drawing.Point(928, 82)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(36, 28)
        Me.Label114.TabIndex = 90
        Me.Label114.Text = "Jul"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(27, 582)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(112, 28)
        Me.Label49.TabIndex = 31
        Me.Label49.Text = "Toelichting"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.Location = New System.Drawing.Point(928, 126)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(48, 28)
        Me.Label115.TabIndex = 91
        Me.Label115.Text = "Aug"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label122.Location = New System.Drawing.Point(44, 357)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(59, 28)
        Me.Label122.TabIndex = 31
        Me.Label122.Text = "Code"
        '
        'Tbx_10_Account__b_year
        '
        Me.Tbx_10_Account__b_year.Enabled = False
        Me.Tbx_10_Account__b_year.Font = New System.Drawing.Font("Calibri", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_10_Account__b_year.Location = New System.Drawing.Point(798, 357)
        Me.Tbx_10_Account__b_year.Name = "Tbx_10_Account__b_year"
        Me.Tbx_10_Account__b_year.Size = New System.Drawing.Size(103, 34)
        Me.Tbx_10_Account__b_year.TabIndex = 79
        Me.Tbx_10_Account__b_year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.Location = New System.Drawing.Point(741, 358)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(49, 28)
        Me.Label109.TabIndex = 78
        Me.Label109.Text = "Jaar"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(44, 308)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(57, 28)
        Me.Label48.TabIndex = 31
        Me.Label48.Text = "Bron"
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.Location = New System.Drawing.Point(740, 305)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(43, 28)
        Me.Label93.TabIndex = 77
        Me.Label93.Text = "Jun"
        '
        'Tbx_00_Account__type
        '
        Me.Tbx_00_Account__type.Enabled = False
        Me.Tbx_00_Account__type.Location = New System.Drawing.Point(495, 178)
        Me.Tbx_00_Account__type.Name = "Tbx_00_Account__type"
        Me.Tbx_00_Account__type.Size = New System.Drawing.Size(139, 35)
        Me.Tbx_00_Account__type.TabIndex = 27
        Me.Tbx_00_Account__type.Tag = "Accounttype"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.Location = New System.Drawing.Point(740, 260)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(48, 28)
        Me.Label92.TabIndex = 77
        Me.Label92.Text = "Mei"
        '
        'Lbl_00_Account__source
        '
        Me.Lbl_00_Account__source.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_00_Account__source.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_00_Account__source.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Lbl_00_Account__source.Location = New System.Drawing.Point(210, 308)
        Me.Lbl_00_Account__source.Name = "Lbl_00_Account__source"
        Me.Lbl_00_Account__source.Size = New System.Drawing.Size(138, 34)
        Me.Lbl_00_Account__source.TabIndex = 30
        Me.Lbl_00_Account__source.Text = "bron"
        Me.Lbl_00_Account__source.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.Location = New System.Drawing.Point(740, 215)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(45, 28)
        Me.Label91.TabIndex = 77
        Me.Label91.Text = "Apr"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(45, 414)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(131, 28)
        Me.Label33.TabIndex = 28
        Me.Label33.Text = "Trefwoorden"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.Location = New System.Drawing.Point(740, 171)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(51, 28)
        Me.Label90.TabIndex = 77
        Me.Label90.Text = "Mar"
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(204, 515)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(446, 60)
        Me.Label43.TabIndex = 29
        Me.Label43.Text = "(gescheiden door komma's, maximaal drie, t.b.v. automatische categorisering)"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(740, 82)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(42, 28)
        Me.Label88.TabIndex = 77
        Me.Label88.Text = "Jan"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.Location = New System.Drawing.Point(740, 126)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(46, 28)
        Me.Label87.TabIndex = 77
        Me.Label87.Text = "Feb"
        '
        'Btn_Account_Budget_All
        '
        Me.Btn_Account_Budget_All.Font = New System.Drawing.Font("Calibri", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Account_Budget_All.Image = CType(resources.GetObject("Btn_Account_Budget_All.Image"), System.Drawing.Image)
        Me.Btn_Account_Budget_All.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btn_Account_Budget_All.Location = New System.Drawing.Point(746, 520)
        Me.Btn_Account_Budget_All.Name = "Btn_Account_Budget_All"
        Me.Btn_Account_Budget_All.Size = New System.Drawing.Size(330, 69)
        Me.Btn_Account_Budget_All.TabIndex = 105
        Me.Btn_Account_Budget_All.Text = "Bereken budget voor alle doelen o.b.v. contract"
        Me.Btn_Account_Budget_All.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btn_Account_Budget_All.UseVisualStyleBackColor = True
        '
        'Btn_Account_Budget_Id
        '
        Me.Btn_Account_Budget_Id.Font = New System.Drawing.Font("Calibri", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Account_Budget_Id.Image = CType(resources.GetObject("Btn_Account_Budget_Id.Image"), System.Drawing.Image)
        Me.Btn_Account_Budget_Id.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Btn_Account_Budget_Id.Location = New System.Drawing.Point(744, 442)
        Me.Btn_Account_Budget_Id.Name = "Btn_Account_Budget_Id"
        Me.Btn_Account_Budget_Id.Size = New System.Drawing.Size(332, 72)
        Me.Btn_Account_Budget_Id.TabIndex = 104
        Me.Btn_Account_Budget_Id.Text = "Bereken budget voor dit doel o.b.v. contract"
        Me.Btn_Account_Budget_Id.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btn_Account_Budget_Id.UseVisualStyleBackColor = True
        '
        'Accgroup
        '
        Me.Accgroup.Controls.Add(Me.Tbx_00_Accgroup__description)
        Me.Accgroup.Controls.Add(Me.Label130)
        Me.Accgroup.Controls.Add(Me.Tbx_00_Accgroup__subtype)
        Me.Accgroup.Controls.Add(Me.Label137)
        Me.Accgroup.Controls.Add(Me.Panel9)
        Me.Accgroup.Controls.Add(Me.Cbx_00_accgroup__active)
        Me.Accgroup.Controls.Add(Me.Label132)
        Me.Accgroup.Controls.Add(Me.Lbl_accgroup_pkid)
        Me.Accgroup.Controls.Add(Me.Label134)
        Me.Accgroup.Controls.Add(Me.Label135)
        Me.Accgroup.Controls.Add(Me.Tbx_01_Accgroup__name)
        Me.Accgroup.Controls.Add(Me.Tbx_01_Accgroup__type)
        Me.Accgroup.Location = New System.Drawing.Point(4, 40)
        Me.Accgroup.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Accgroup.Name = "Accgroup"
        Me.Accgroup.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Accgroup.Size = New System.Drawing.Size(1152, 804)
        Me.Accgroup.TabIndex = 7
        Me.Accgroup.Text = "Accountgroep"
        '
        'Tbx_00_Accgroup__description
        '
        Me.Tbx_00_Accgroup__description.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_Accgroup__description.Location = New System.Drawing.Point(213, 212)
        Me.Tbx_00_Accgroup__description.Multiline = True
        Me.Tbx_00_Accgroup__description.Name = "Tbx_00_Accgroup__description"
        Me.Tbx_00_Accgroup__description.Size = New System.Drawing.Size(451, 92)
        Me.Tbx_00_Accgroup__description.TabIndex = 147
        Me.Tbx_00_Accgroup__description.Tag = "Omschrijving"
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label130.Location = New System.Drawing.Point(46, 200)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(133, 28)
        Me.Label130.TabIndex = 146
        Me.Label130.Text = "Omschrijving"
        '
        'Tbx_00_Accgroup__subtype
        '
        Me.Tbx_00_Accgroup__subtype.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_Accgroup__subtype.Location = New System.Drawing.Point(213, 158)
        Me.Tbx_00_Accgroup__subtype.Name = "Tbx_00_Accgroup__subtype"
        Me.Tbx_00_Accgroup__subtype.Size = New System.Drawing.Size(451, 30)
        Me.Tbx_00_Accgroup__subtype.TabIndex = 145
        Me.Tbx_00_Accgroup__subtype.Tag = "Subtype"
        '
        'Label137
        '
        Me.Label137.AutoSize = True
        Me.Label137.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label137.Location = New System.Drawing.Point(48, 158)
        Me.Label137.Name = "Label137"
        Me.Label137.Size = New System.Drawing.Size(88, 28)
        Me.Label137.TabIndex = 143
        Me.Label137.Text = "Subtype"
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.Rbtn_accgroup_Income)
        Me.Panel9.Controls.Add(Me.Rbtn_accgroup_transit)
        Me.Panel9.Controls.Add(Me.Rbtn_accgroup_expense)
        Me.Panel9.Location = New System.Drawing.Point(213, 114)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(453, 38)
        Me.Panel9.TabIndex = 139
        '
        'Rbtn_accgroup_Income
        '
        Me.Rbtn_accgroup_Income.AutoSize = True
        Me.Rbtn_accgroup_Income.Location = New System.Drawing.Point(4, 0)
        Me.Rbtn_accgroup_Income.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_accgroup_Income.Name = "Rbtn_accgroup_Income"
        Me.Rbtn_accgroup_Income.Size = New System.Drawing.Size(134, 32)
        Me.Rbtn_accgroup_Income.TabIndex = 26
        Me.Rbtn_accgroup_Income.TabStop = True
        Me.Rbtn_accgroup_Income.Text = "Inkomsten"
        Me.Rbtn_accgroup_Income.UseVisualStyleBackColor = True
        '
        'Rbtn_accgroup_transit
        '
        Me.Rbtn_accgroup_transit.AutoSize = True
        Me.Rbtn_accgroup_transit.Location = New System.Drawing.Point(280, -2)
        Me.Rbtn_accgroup_transit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_accgroup_transit.Name = "Rbtn_accgroup_transit"
        Me.Rbtn_accgroup_transit.Size = New System.Drawing.Size(100, 32)
        Me.Rbtn_accgroup_transit.TabIndex = 26
        Me.Rbtn_accgroup_transit.TabStop = True
        Me.Rbtn_accgroup_transit.Text = "Transit"
        Me.Rbtn_accgroup_transit.UseVisualStyleBackColor = True
        '
        'Rbtn_accgroup_expense
        '
        Me.Rbtn_accgroup_expense.AutoSize = True
        Me.Rbtn_accgroup_expense.Location = New System.Drawing.Point(150, -2)
        Me.Rbtn_accgroup_expense.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Rbtn_accgroup_expense.Name = "Rbtn_accgroup_expense"
        Me.Rbtn_accgroup_expense.Size = New System.Drawing.Size(120, 32)
        Me.Rbtn_accgroup_expense.TabIndex = 26
        Me.Rbtn_accgroup_expense.TabStop = True
        Me.Rbtn_accgroup_expense.Text = "Uitgaven"
        Me.Rbtn_accgroup_expense.UseVisualStyleBackColor = True
        '
        'Cbx_00_accgroup__active
        '
        Me.Cbx_00_accgroup__active.AutoSize = True
        Me.Cbx_00_accgroup__active.Checked = True
        Me.Cbx_00_accgroup__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_accgroup__active.Enabled = False
        Me.Cbx_00_accgroup__active.Location = New System.Drawing.Point(504, 23)
        Me.Cbx_00_accgroup__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_accgroup__active.Name = "Cbx_00_accgroup__active"
        Me.Cbx_00_accgroup__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_accgroup__active.TabIndex = 138
        Me.Cbx_00_accgroup__active.Text = "Actief"
        Me.Cbx_00_accgroup__active.UseVisualStyleBackColor = True
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label132.Location = New System.Drawing.Point(48, 23)
        Me.Label132.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(94, 28)
        Me.Label132.TabIndex = 137
        Me.Label132.Text = "Kenmerk"
        '
        'Lbl_accgroup_pkid
        '
        Me.Lbl_accgroup_pkid.AutoSize = True
        Me.Lbl_accgroup_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_accgroup_pkid.Location = New System.Drawing.Point(213, 23)
        Me.Lbl_accgroup_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_accgroup_pkid.Name = "Lbl_accgroup_pkid"
        Me.Lbl_accgroup_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_accgroup_pkid.TabIndex = 136
        Me.Lbl_accgroup_pkid.Text = "id"
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(46, 60)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(67, 28)
        Me.Label134.TabIndex = 128
        Me.Label134.Text = "Naam"
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.Location = New System.Drawing.Point(46, 125)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(55, 28)
        Me.Label135.TabIndex = 129
        Me.Label135.Text = "Type"
        '
        'Tbx_01_Accgroup__name
        '
        Me.Tbx_01_Accgroup__name.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_01_Accgroup__name.Location = New System.Drawing.Point(213, 60)
        Me.Tbx_01_Accgroup__name.Name = "Tbx_01_Accgroup__name"
        Me.Tbx_01_Accgroup__name.Size = New System.Drawing.Size(451, 30)
        Me.Tbx_01_Accgroup__name.TabIndex = 130
        Me.Tbx_01_Accgroup__name.Tag = "Naam"
        '
        'Tbx_01_Accgroup__type
        '
        Me.Tbx_01_Accgroup__type.Enabled = False
        Me.Tbx_01_Accgroup__type.Location = New System.Drawing.Point(681, 112)
        Me.Tbx_01_Accgroup__type.Name = "Tbx_01_Accgroup__type"
        Me.Tbx_01_Accgroup__type.Size = New System.Drawing.Size(102, 35)
        Me.Tbx_01_Accgroup__type.TabIndex = 131
        Me.Tbx_01_Accgroup__type.Tag = "Accounttype"
        Me.Tbx_01_Accgroup__type.Visible = False
        '
        'BankAcc
        '
        Me.BankAcc.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BankAcc.Controls.Add(Me.Label104)
        Me.BankAcc.Controls.Add(Me.Label105)
        Me.BankAcc.Controls.Add(Me.Cbx_00_BankAcc__active)
        Me.BankAcc.Controls.Add(Me.Label53)
        Me.BankAcc.Controls.Add(Me.Cmx_01_BankAcc__currency)
        Me.BankAcc.Controls.Add(Me.Tbx_00_BankAcc__bic)
        Me.BankAcc.Controls.Add(Me.Tbx_01_BankAcc__name)
        Me.BankAcc.Controls.Add(Me.Tbx_00_BankAcc__id2)
        Me.BankAcc.Controls.Add(Me.Lbl_BankAcc_pkid)
        Me.BankAcc.Controls.Add(Me.Label45)
        Me.BankAcc.Controls.Add(Me.Label36)
        Me.BankAcc.Controls.Add(Me.Label44)
        Me.BankAcc.Controls.Add(Me.Chx_00_BankAcc__expense)
        Me.BankAcc.Controls.Add(Me.Tbx_01_BankAcc__owner)
        Me.BankAcc.Controls.Add(Me.Cbx_00_BankAcc__income)
        Me.BankAcc.Controls.Add(Me.Tbx_00_BankAcc__description)
        Me.BankAcc.Controls.Add(Me.Tbx_01_BankAcc__accountno)
        Me.BankAcc.Controls.Add(Me.Label42)
        Me.BankAcc.Controls.Add(Me.Label35)
        Me.BankAcc.Controls.Add(Me.Label52)
        Me.BankAcc.Controls.Add(Me.Tbx_BankAcc_startbalance)
        Me.BankAcc.Controls.Add(Me.Label40)
        Me.BankAcc.Location = New System.Drawing.Point(4, 40)
        Me.BankAcc.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BankAcc.Name = "BankAcc"
        Me.BankAcc.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BankAcc.Size = New System.Drawing.Size(1152, 804)
        Me.BankAcc.TabIndex = 6
        Me.BankAcc.Text = "Bankrekening"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.Location = New System.Drawing.Point(24, 415)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(122, 28)
        Me.Label104.TabIndex = 77
        Me.Label104.Text = "Incassant id"
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.Location = New System.Drawing.Point(24, 458)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(43, 28)
        Me.Label105.TabIndex = 77
        Me.Label105.Text = "BIC"
        '
        'Cbx_00_BankAcc__active
        '
        Me.Cbx_00_BankAcc__active.AutoSize = True
        Me.Cbx_00_BankAcc__active.Checked = True
        Me.Cbx_00_BankAcc__active.CheckState = System.Windows.Forms.CheckState.Checked
        Me.Cbx_00_BankAcc__active.Location = New System.Drawing.Point(501, 28)
        Me.Cbx_00_BankAcc__active.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_BankAcc__active.Name = "Cbx_00_BankAcc__active"
        Me.Cbx_00_BankAcc__active.Size = New System.Drawing.Size(92, 32)
        Me.Cbx_00_BankAcc__active.TabIndex = 51
        Me.Cbx_00_BankAcc__active.Text = "Actief"
        Me.Cbx_00_BankAcc__active.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(24, 34)
        Me.Label53.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(94, 28)
        Me.Label53.TabIndex = 50
        Me.Label53.Text = "Kenmerk"
        '
        'Cmx_01_BankAcc__currency
        '
        Me.Cmx_01_BankAcc__currency.FormattingEnabled = True
        Me.Cmx_01_BankAcc__currency.Items.AddRange(New Object() {"EUR", "MLD", "USD"})
        Me.Cmx_01_BankAcc__currency.Location = New System.Drawing.Point(210, 354)
        Me.Cmx_01_BankAcc__currency.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cmx_01_BankAcc__currency.Name = "Cmx_01_BankAcc__currency"
        Me.Cmx_01_BankAcc__currency.Size = New System.Drawing.Size(114, 36)
        Me.Cmx_01_BankAcc__currency.TabIndex = 28
        Me.Cmx_01_BankAcc__currency.Tag = "Munteenheid"
        '
        'Tbx_00_BankAcc__bic
        '
        Me.Tbx_00_BankAcc__bic.Location = New System.Drawing.Point(210, 458)
        Me.Tbx_00_BankAcc__bic.Name = "Tbx_00_BankAcc__bic"
        Me.Tbx_00_BankAcc__bic.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_00_BankAcc__bic.TabIndex = 0
        '
        'Tbx_01_BankAcc__name
        '
        Me.Tbx_01_BankAcc__name.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_01_BankAcc__name.Location = New System.Drawing.Point(210, 115)
        Me.Tbx_01_BankAcc__name.Name = "Tbx_01_BankAcc__name"
        Me.Tbx_01_BankAcc__name.Size = New System.Drawing.Size(386, 30)
        Me.Tbx_01_BankAcc__name.TabIndex = 8
        Me.Tbx_01_BankAcc__name.Tag = "Rekeningnaam"
        '
        'Tbx_00_BankAcc__id2
        '
        Me.Tbx_00_BankAcc__id2.Location = New System.Drawing.Point(210, 414)
        Me.Tbx_00_BankAcc__id2.Name = "Tbx_00_BankAcc__id2"
        Me.Tbx_00_BankAcc__id2.Size = New System.Drawing.Size(386, 35)
        Me.Tbx_00_BankAcc__id2.TabIndex = 0
        '
        'Lbl_BankAcc_pkid
        '
        Me.Lbl_BankAcc_pkid.AutoSize = True
        Me.Lbl_BankAcc_pkid.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Lbl_BankAcc_pkid.Location = New System.Drawing.Point(210, 34)
        Me.Lbl_BankAcc_pkid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Lbl_BankAcc_pkid.Name = "Lbl_BankAcc_pkid"
        Me.Lbl_BankAcc_pkid.Size = New System.Drawing.Size(29, 28)
        Me.Lbl_BankAcc_pkid.TabIndex = 49
        Me.Lbl_BankAcc_pkid.Text = "id"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(24, 118)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(147, 28)
        Me.Label45.TabIndex = 9
        Me.Label45.Text = "Rekeningnaam"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(24, 358)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(138, 28)
        Me.Label36.TabIndex = 27
        Me.Label36.Text = "Munteenheid"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(622, 28)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(112, 28)
        Me.Label44.TabIndex = 19
        Me.Label44.Text = "Toelichting"
        '
        'Chx_00_BankAcc__expense
        '
        Me.Chx_00_BankAcc__expense.AutoSize = True
        Me.Chx_00_BankAcc__expense.Location = New System.Drawing.Point(210, 252)
        Me.Chx_00_BankAcc__expense.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Chx_00_BankAcc__expense.Name = "Chx_00_BankAcc__expense"
        Me.Chx_00_BankAcc__expense.Size = New System.Drawing.Size(324, 32)
        Me.Chx_00_BankAcc__expense.TabIndex = 25
        Me.Chx_00_BankAcc__expense.Text = "Uitgaande gelden (uitkeringen)"
        Me.Chx_00_BankAcc__expense.UseVisualStyleBackColor = True
        '
        'Tbx_01_BankAcc__owner
        '
        Me.Tbx_01_BankAcc__owner.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_01_BankAcc__owner.Location = New System.Drawing.Point(210, 162)
        Me.Tbx_01_BankAcc__owner.Name = "Tbx_01_BankAcc__owner"
        Me.Tbx_01_BankAcc__owner.Size = New System.Drawing.Size(386, 30)
        Me.Tbx_01_BankAcc__owner.TabIndex = 10
        Me.Tbx_01_BankAcc__owner.Tag = "Rekeninghouder"
        '
        'Cbx_00_BankAcc__income
        '
        Me.Cbx_00_BankAcc__income.AutoSize = True
        Me.Cbx_00_BankAcc__income.Location = New System.Drawing.Point(210, 209)
        Me.Cbx_00_BankAcc__income.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Cbx_00_BankAcc__income.Name = "Cbx_00_BankAcc__income"
        Me.Cbx_00_BankAcc__income.Size = New System.Drawing.Size(280, 32)
        Me.Cbx_00_BankAcc__income.TabIndex = 25
        Me.Cbx_00_BankAcc__income.Text = "Inkomende gelden (giften)"
        Me.Cbx_00_BankAcc__income.UseVisualStyleBackColor = True
        '
        'Tbx_00_BankAcc__description
        '
        Me.Tbx_00_BankAcc__description.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_00_BankAcc__description.Location = New System.Drawing.Point(627, 69)
        Me.Tbx_00_BankAcc__description.Multiline = True
        Me.Tbx_00_BankAcc__description.Name = "Tbx_00_BankAcc__description"
        Me.Tbx_00_BankAcc__description.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tbx_00_BankAcc__description.Size = New System.Drawing.Size(444, 427)
        Me.Tbx_00_BankAcc__description.TabIndex = 20
        '
        'Tbx_01_BankAcc__accountno
        '
        Me.Tbx_01_BankAcc__accountno.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_01_BankAcc__accountno.Location = New System.Drawing.Point(210, 69)
        Me.Tbx_01_BankAcc__accountno.Name = "Tbx_01_BankAcc__accountno"
        Me.Tbx_01_BankAcc__accountno.Size = New System.Drawing.Size(386, 30)
        Me.Tbx_01_BankAcc__accountno.TabIndex = 6
        Me.Tbx_01_BankAcc__accountno.Tag = "IBAN"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(24, 165)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(162, 28)
        Me.Label42.TabIndex = 7
        Me.Label42.Text = "Rekeninghouder"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(24, 72)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(59, 28)
        Me.Label35.TabIndex = 5
        Me.Label35.Text = "IBAN"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(24, 211)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(136, 28)
        Me.Label52.TabIndex = 7
        Me.Label52.Text = "Rekeningtype"
        '
        'Tbx_BankAcc_startbalance
        '
        Me.Tbx_BankAcc_startbalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbx_BankAcc_startbalance.Location = New System.Drawing.Point(210, 308)
        Me.Tbx_BankAcc_startbalance.Name = "Tbx_BankAcc_startbalance"
        Me.Tbx_BankAcc_startbalance.Size = New System.Drawing.Size(178, 30)
        Me.Tbx_BankAcc_startbalance.TabIndex = 12
        Me.Tbx_BankAcc_startbalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(24, 311)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(107, 28)
        Me.Label40.TabIndex = 21
        Me.Label40.Text = "Startsaldo"
        '
        'TC_Main
        '
        Me.TC_Main.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TC_Main.Controls.Add(Me.TabPage1)
        Me.TC_Main.Controls.Add(Me.Tab_Bank)
        Me.TC_Main.Controls.Add(Me.Incasso)
        Me.TC_Main.Controls.Add(Me.Uitkering)
        Me.TC_Main.Controls.Add(Me.Intern)
        Me.TC_Main.Controls.Add(Me.Tab_Rapportage)
        Me.TC_Main.Controls.Add(Me.Instellingen)
        Me.TC_Main.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TC_Main.Location = New System.Drawing.Point(0, 43)
        Me.TC_Main.Name = "TC_Main"
        Me.TC_Main.SelectedIndex = 0
        Me.TC_Main.Size = New System.Drawing.Size(1626, 931)
        Me.TC_Main.TabIndex = 0
        '
        'Searchbox2
        '
        Me.Searchbox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Searchbox2.Location = New System.Drawing.Point(88, 6)
        Me.Searchbox2.Name = "Searchbox2"
        Me.Searchbox2.Size = New System.Drawing.Size(398, 28)
        Me.Searchbox2.TabIndex = 74
        '
        'Zoeken
        '
        Me.Zoeken.AutoSize = True
        Me.Zoeken.Location = New System.Drawing.Point(20, 11)
        Me.Zoeken.Name = "Zoeken"
        Me.Zoeken.Size = New System.Drawing.Size(63, 20)
        Me.Zoeken.TabIndex = 75
        Me.Zoeken.Text = "Zoeken"
        '
        'Testpanel
        '
        Me.Testpanel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Testpanel.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Testpanel.Controls.Add(Me.Cbx_LifeCycle2)
        Me.Testpanel.Controls.Add(Me.Zoeken)
        Me.Testpanel.Controls.Add(Me.Searchbox2)
        Me.Testpanel.Location = New System.Drawing.Point(854, 0)
        Me.Testpanel.Name = "Testpanel"
        Me.Testpanel.Size = New System.Drawing.Size(632, 37)
        Me.Testpanel.TabIndex = 74
        '
        'Cbx_LifeCycle2
        '
        Me.Cbx_LifeCycle2.FormattingEnabled = True
        Me.Cbx_LifeCycle2.Items.AddRange(New Object() {"Actief", "Inactief", "Beide"})
        Me.Cbx_LifeCycle2.Location = New System.Drawing.Point(494, 6)
        Me.Cbx_LifeCycle2.Name = "Cbx_LifeCycle2"
        Me.Cbx_LifeCycle2.Size = New System.Drawing.Size(121, 28)
        Me.Cbx_LifeCycle2.TabIndex = 76
        Me.Cbx_LifeCycle2.Text = "Actief"
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Tbx_Transactie_totaal)
        Me.Panel6.Controls.Add(Me.Tbx_Bank_Afschrift)
        Me.Panel6.Controls.Add(Me.Tbx_Bank_Code)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Controls.Add(Me.Tbx_Bank_Relation_account)
        Me.Panel6.Controls.Add(Me.Label72)
        Me.Panel6.Controls.Add(Me.Tbx_Bank_Relation)
        Me.Panel6.Controls.Add(Me.Label73)
        Me.Panel6.Location = New System.Drawing.Point(6, 90)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(319, 220)
        Me.Panel6.TabIndex = 60
        '
        'Tbx_Transactie_totaal
        '
        Me.Tbx_Transactie_totaal.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Transactie_totaal.Location = New System.Drawing.Point(174, 176)
        Me.Tbx_Transactie_totaal.Name = "Tbx_Transactie_totaal"
        Me.Tbx_Transactie_totaal.Size = New System.Drawing.Size(118, 30)
        Me.Tbx_Transactie_totaal.TabIndex = 61
        '
        'Tbx_Bank_Afschrift
        '
        Me.Tbx_Bank_Afschrift.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Bank_Afschrift.Location = New System.Drawing.Point(69, 176)
        Me.Tbx_Bank_Afschrift.Name = "Tbx_Bank_Afschrift"
        Me.Tbx_Bank_Afschrift.Size = New System.Drawing.Size(92, 30)
        Me.Tbx_Bank_Afschrift.TabIndex = 60
        '
        'Tbx_Bank_Code
        '
        Me.Tbx_Bank_Code.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Bank_Code.Location = New System.Drawing.Point(6, 176)
        Me.Tbx_Bank_Code.Name = "Tbx_Bank_Code"
        Me.Tbx_Bank_Code.Size = New System.Drawing.Size(55, 30)
        Me.Tbx_Bank_Code.TabIndex = 59
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(-1, 146)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(155, 25)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Banktransactie"
        '
        'Tbx_Bank_Relation_account
        '
        Me.Tbx_Bank_Relation_account.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Bank_Relation_account.Location = New System.Drawing.Point(1, 104)
        Me.Tbx_Bank_Relation_account.Name = "Tbx_Bank_Relation_account"
        Me.Tbx_Bank_Relation_account.Size = New System.Drawing.Size(311, 30)
        Me.Tbx_Bank_Relation_account.TabIndex = 32
        '
        'Label72
        '
        Me.Label72.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(-1, 74)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(156, 25)
        Me.Label72.TabIndex = 31
        Me.Label72.Text = "Tegenrekening"
        '
        'Tbx_Bank_Relation
        '
        Me.Tbx_Bank_Relation.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Tbx_Bank_Relation.Location = New System.Drawing.Point(1, 39)
        Me.Tbx_Bank_Relation.Name = "Tbx_Bank_Relation"
        Me.Tbx_Bank_Relation.Size = New System.Drawing.Size(311, 30)
        Me.Tbx_Bank_Relation.TabIndex = 30
        '
        'Label73
        '
        Me.Label73.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(-1, 8)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(141, 25)
        Me.Label73.TabIndex = 29
        Me.Label73.Text = "Naam/Relatie"
        '
        'SPAS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumAquamarine
        Me.ClientSize = New System.Drawing.Size(1638, 974)
        Me.Controls.Add(Me.Testpanel)
        Me.Controls.Add(Me.TC_Main)
        Me.Controls.Add(Me.MenuStrip1)
        Me.HelpButton = True
        Me.HelpProvider1.SetHelpNavigator(Me, System.Windows.Forms.HelpNavigator.TableOfContents)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "SPAS"
        Me.HelpProvider1.SetShowHelp(Me, True)
        Me.Text = "SPAS (versie  3-2-2025)"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout
        Me.Instellingen.ResumeLayout(False)
        Me.TC_Management.ResumeLayout(False)
        Me.Settings.ResumeLayout(False)
        CType(Me.Dgv_Settings, System.ComponentModel.ISupportInitialize).EndInit
        Me.QueryBuilder.ResumeLayout(False)
        Me.QueryBuilder.PerformLayout
        CType(Me.Dgv_Query_Test, System.ComponentModel.ISupportInitialize).EndInit
        Me.TP_Test.ResumeLayout(False)
        Me.Pan_Test.ResumeLayout(False)
        Me.Pan_Test.PerformLayout
        CType(Me.Dgv_Mgnt_Tables, System.ComponentModel.ISupportInitialize).EndInit
        Me.Tab_Rapportage.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout
        CType(Me.Dgv_Report_6, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout
        CType(Me.Dgv_Rapportage_Overzicht, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout
        Me.Intern.ResumeLayout(False)
        Me.TC_Boeking.ResumeLayout(False)
        Me.Overboekingen.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout
        CType(Me.Dgv_Journal_Intern, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout
        Me.Journaalposten.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout
        CType(Me.Dgv_journaalposten, System.ComponentModel.ISupportInitialize).EndInit
        Me.Grp_Journaalposten.ResumeLayout(False)
        Me.Grp_Journaalposten.PerformLayout
        Me.GRP_journaalposten_edit.ResumeLayout(False)
        Me.GRP_journaalposten_edit.PerformLayout
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout
        Me.Accounts.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Jaarafsluiting.ResumeLayout(False)
        Me.Jaarafsluiting.PerformLayout
        CType(Me.Dgv_Report_Year_Closing, System.ComponentModel.ISupportInitialize).EndInit
        Me.Uitkering.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        CType(Me.Dgv_Uitkering_Account_Details, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel14.ResumeLayout(False)
        CType(Me.Dgv_Excasso2, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel4.ResumeLayout(False)
        Me.Gbx_Excasso_Doeltype.ResumeLayout(False)
        Me.Gbx_Excasso_Doeltype.PerformLayout
        Me.GroupBox1.ResumeLayout(False)
        Me.Pan_Excasso_preset.ResumeLayout(False)
        Me.Pan_Excasso_preset.PerformLayout
        Me.Gbx_Excasso_Calculate.ResumeLayout(False)
        Me.Gbx_Excasso_Calculate.PerformLayout
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout
        Me.Incasso.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout
        CType(Me.Dgv_incasso_totals, System.ComponentModel.ISupportInitialize).EndInit
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout
        CType(Me.Dgv_Incasso, System.ComponentModel.ISupportInitialize).EndInit
        Me.Tab_Bank.ResumeLayout(False)
        Me.Pan_Bank2.ResumeLayout(False)
        CType(Me.Dgv_Bank, System.ComponentModel.ISupportInitialize).EndInit
        Me.Pan_Bank.ResumeLayout(False)
        Me.Pan_Bank.PerformLayout
        CType(Me.Dgv_Bank_Account, System.ComponentModel.ISupportInitialize).EndInit
        CType(Me.Dgv_Bank_Account2, System.ComponentModel.ISupportInitialize).EndInit
        Me.Pan_Bank_jtype.ResumeLayout(False)
        Me.Pan_Bank_jtype.PerformLayout
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.TC_Object.ResumeLayout(False)
        Me.Contract.ResumeLayout(False)
        Me.Contract.PerformLayout
        Me.Pan_Contract_Date_New.ResumeLayout(False)
        Me.Pan_Contract_Date_New.PerformLayout
        Me.Pan_contract_select_target.ResumeLayout(False)
        Me.Pan_contract_select_target.PerformLayout
        CType(Me.Pic_Contract_Target_photo, System.ComponentModel.ISupportInitialize).EndInit
        Me.target.ResumeLayout(False)
        Me.target.PerformLayout
        Me.Pan_Target.ResumeLayout(False)
        Me.Pan_Target.PerformLayout
        CType(Me.Pic_Target__photo, System.ComponentModel.ISupportInitialize).EndInit
        Me.Relation.ResumeLayout(False)
        Me.Relation.PerformLayout
        CType(Me.Dgv_relation_giften, System.ComponentModel.ISupportInitialize).EndInit
        Me.CP.ResumeLayout(False)
        Me.CP.PerformLayout
        CType(Me.Pic_cp__photo, System.ComponentModel.ISupportInitialize).EndInit
        Me.Account.ResumeLayout(False)
        Me.Account.PerformLayout
        Me.Pan_account.ResumeLayout(False)
        Me.Pan_account.PerformLayout
        Me.Accgroup.ResumeLayout(False)
        Me.Accgroup.PerformLayout
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout
        Me.BankAcc.ResumeLayout(False)
        Me.BankAcc.PerformLayout
        Me.TC_Main.ResumeLayout(False)
        Me.Testpanel.ResumeLayout(False)
        Me.Testpanel.PerformLayout
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout
        Me.ResumeLayout(False)
        Me.PerformLayout

    End Sub
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents Rbn_Bank_Extra As RadioButton
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents MenuFilter As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents MenuDelete As ToolStripMenuItem
    Friend WithEvents Menu_Print As ToolStripMenuItem
    Friend WithEvents Menu_Export As ToolStripMenuItem
    Friend WithEvents MenuCancel As ToolStripMenuItem
    Friend WithEvents MenuAdd As ToolStripMenuItem
    Friend WithEvents MenuSave As ToolStripMenuItem
    Friend WithEvents MenuBanktransactie As ToolStripMenuItem
    Friend WithEvents MenuUploadAlles As ToolStripMenuItem
    Friend WithEvents MenuCategoriseer As ToolStripMenuItem
    Friend WithEvents Rbn_Bank_Contract As RadioButton
    Friend WithEvents HelpProvider1 As HelpProvider
    Friend WithEvents Menu_Back As ToolStripMenuItem
    Friend WithEvents Menu_Help As ToolStripMenuItem
    Friend WithEvents Instellingen As TabPage
    Friend WithEvents TC_Management As TabControl
    Friend WithEvents Settings As TabPage
    Friend WithEvents Dgv_Settings As DataGridView
    Friend WithEvents AVG As TabPage
    Friend WithEvents QueryBuilder As TabPage
    Friend WithEvents Button1 As Button
    Friend WithEvents Btn_Query_Test As Button
    Friend WithEvents Tbx_Query_SQL As TextBox
    Friend WithEvents Label117 As Label
    Friend WithEvents Tbx_Query_Formattering As TextBox
    Friend WithEvents Label116 As Label
    Friend WithEvents Tbx_Query_Naam As TextBox
    Friend WithEvents Label108 As Label
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents Label102 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Cmbx_Query_Select As ComboBox
    Friend WithEvents Dgv_Query_Test As DataGridView
    Friend WithEvents Tab_Rapportage As TabPage
    Friend WithEvents Intern As TabPage
    Friend WithEvents TC_Boeking As TabControl
    Friend WithEvents Overboekingen As TabPage
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Rbn_Journal_Extra As RadioButton
    Friend WithEvents Tbx_Journal_Name As TextBox
    Friend WithEvents Label126 As Label
    Friend WithEvents Rbn_Journal_Contract As RadioButton
    Friend WithEvents Rbn_Journal_Intern As RadioButton
    Friend WithEvents Label54 As Label
    Friend WithEvents Btn_Journal_Intern_Save As Button
    Friend WithEvents Btn_Journal_Recalculate As Button
    Friend WithEvents Btn_Journals_Cancel As Button
    Friend WithEvents Label121 As Label
    Friend WithEvents Dtp_Journal_intern As DateTimePicker
    Friend WithEvents Dgv_Journal_Intern As DataGridView
    Friend WithEvents id1 As DataGridViewTextBoxColumn
    Friend WithEvents Accnt As DataGridViewTextBoxColumn
    Friend WithEvents Amt1 As DataGridViewTextBoxColumn
    Friend WithEvents Label128 As Label
    Friend WithEvents Label125 As Label
    Friend WithEvents Tbx_Journal_Description As TextBox
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Cmbx_Overboeking_Target As ComboBox
    Friend WithEvents Cmbx_Overboeking_Bron As ComboBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Lbl_Journal_Source_Name As Label
    Friend WithEvents Tbx_Journal_Source_Amt As TextBox
    Friend WithEvents Lbl_Journal_Source_Saldo As Label
    Friend WithEvents Lbl_Journal_Source_Restamt As Label
    Friend WithEvents Lbl_Journal_Source_id As Label
    Friend WithEvents Label129 As Label
    Friend WithEvents Journaalposten As TabPage
    Friend WithEvents Lbl_Journaalposten_header As Label
    Friend WithEvents GRP_journaalposten_edit As GroupBox
    Friend WithEvents Label147 As Label
    Friend WithEvents Btn_journaalposten_Save As Button
    Friend WithEvents Label131 As Label
    Friend WithEvents Tbx_journaalposten_omschr As TextBox
    Friend WithEvents Label133 As Label
    Friend WithEvents Cmbx_journaalposten_relatie As ComboBox
    Friend WithEvents Lbl00x As Label
    Friend WithEvents Cmbx_journaalposten_account As ComboBox
    Friend WithEvents Dgv_journaalposten As DataGridView
    Friend WithEvents Lbl_accountname As Label
    Friend WithEvents journalid2 As Label
    Friend WithEvents Grp_Journaalposten As GroupBox
    Friend WithEvents Banklink As LinkLabel
    Friend WithEvents Label120 As Label
    Friend WithEvents Label144 As Label
    Friend WithEvents Label146 As Label
    Friend WithEvents Label143 As Label
    Friend WithEvents Label142 As Label
    Friend WithEvents Label141 As Label
    Friend WithEvents Label140 As Label
    Friend WithEvents Label138 As Label
    Friend WithEvents Lbl_journaalposten_iban As Label
    Friend WithEvents Lbl_journaalposten_cpinfo As Label
    Friend WithEvents Lbl_journaalposten_wisselkoers As Label
    Friend WithEvents Lbl_journaalposten_type As Label
    Friend WithEvents Lbl_journaalposten_status As Label
    Friend WithEvents Lbl_Journaalposten_bron As Label
    Friend WithEvents Lbl_Journaalposten_datum As Label
    Friend WithEvents Jaarafsluiting As TabPage
    Friend WithEvents Dgv_Report_Year_Closing As DataGridView
    Friend WithEvents Btn_Report_YearEnd_Check As Button
    Friend WithEvents Lbl_Report_total As Label
    Friend WithEvents Btn_Report_YearEnd_Post As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Cbx_Journal_Status_Verwerkt As CheckBox
    Friend WithEvents Lbl_Journal_Status As Label
    Friend WithEvents Cbx_Journal_Status_Open As CheckBox
    Friend WithEvents Tbx_Journal_Filter As TextBox
    Friend WithEvents Lv_Journal_List As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents Uitkering As TabPage
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Gbx_Excasso_Doeltype As GroupBox
    Friend WithEvents Tbx_Excasso_Exchange_rate As TextBox
    Friend WithEvents Label103 As Label
    Friend WithEvents Btn_Excasso_Exchrate As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Dtp_Excasso_Start As DateTimePicker
    Friend WithEvents Btn_Excasso_Calculate_Exchrate As Button
    Friend WithEvents Lbl_Excasso_LastCalc As Label
    Friend WithEvents Lbl_Excasso_CPid As Label
    Friend WithEvents Btn_Excasso_Copy_to_clipboard As Button
    Friend WithEvents Label83 As Label
    Friend WithEvents Cbx_Uitkering_Kind As CheckBox
    Friend WithEvents Cbx_Uitkering_Oudere As CheckBox
    Friend WithEvents Cbx_Uitkering_Overig As CheckBox
    Friend WithEvents Cmx_Excasso_Select As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Pan_Excasso_preset As Panel
    Friend WithEvents Rbn_uitkering_budget As RadioButton
    Friend WithEvents Rbn_uitkering_saldo As RadioButton
    Friend WithEvents Rbn_uitkering_nul As RadioButton
    Friend WithEvents Gbx_Excasso_Calculate As GroupBox
    Friend WithEvents Label106 As Label
    Friend WithEvents Label127 As Label
    Friend WithEvents Lbl_Excasso_Items_Contract As Label
    Friend WithEvents Lbl_Excasso_Items_Intern As Label
    Friend WithEvents Lbl_Excasso_Intern As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents Lbl_Excasso_Extra As Label
    Friend WithEvents Lbl_Excasso_Items_Extra As Label
    Friend WithEvents Lbl_Excasso_Totalen As Label
    Friend WithEvents Lbl_Excasso_Tot_Gen As Label
    Friend WithEvents Lbl_Excasso_CP_Totaal As Label
    Friend WithEvents Lbl_Excasso_Contractwaarde As Label
    Friend WithEvents Lbl_Excasso_Tot_Gen_MLD As Label
    Friend WithEvents Lbl_Excasso_CP_Totaal_MDL As Label
    Friend WithEvents Lbl_Excasso_Totaal_MDL As Label
    Friend WithEvents Label89 As Label
    Friend WithEvents Lbl_Excasso_Totaal As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label99 As Label
    Friend WithEvents Lbl_Excasso_Contract As Label
    Friend WithEvents Tbx_Excasso_CP1 As TextBox
    Friend WithEvents Label86 As Label
    Friend WithEvents Tbx_Excasso_Norm1 As TextBox
    Friend WithEvents Btn_Excasso_CP_Calculate As Button
    Friend WithEvents Tbx_Excasso_CP2 As TextBox
    Friend WithEvents Btn_Excasso_Base1 As Button
    Friend WithEvents Btn_Excasso_Base2 As Button
    Friend WithEvents Btn_Excasso_Base3 As Button
    Friend WithEvents Label98 As Label
    Friend WithEvents Lbl_Excasso_Items_Totaal As Label
    Friend WithEvents Lbl_Excasso_Extr As Label
    Friend WithEvents Label139 As Label
    Friend WithEvents Tbx_Excasso_Norm3 As TextBox
    Friend WithEvents Tbx_Excasso_Norm2 As TextBox
    Friend WithEvents Tbx_Excasso_CP3 As TextBox
    Friend WithEvents Lbl_Excasso_Internal As Label
    Friend WithEvents Dgv_Excasso2 As DataGridView
    Friend WithEvents Btn_Excasso_Save As Button
    Friend WithEvents Btn_Excasso_Print As Button
    Friend WithEvents Btn_Excasso_Cancel As Button
    Friend WithEvents Btn_Excasso_Delete As Button
    Friend WithEvents Incasso As TabPage
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Label79 As Label
    Friend WithEvents Lbl_Incasso_Error As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Dtp_Incasso_start As DateTimePicker
    Friend WithEvents Cmx_Incasso_Bankaccount As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Rbn_Incasso_SEPA As RadioButton
    Friend WithEvents Label145 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Rbn_Incasso_journal As RadioButton
    Friend WithEvents Label71 As Label
    Friend WithEvents Lbl_Incasso_Status As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Lbl_Incasso_job_name As Label
    Friend WithEvents Dtp_Incasso_end As DateTimePicker
    Friend WithEvents Dgv_Incasso As DataGridView
    Friend WithEvents Tab_Bank As TabPage
    Friend WithEvents Pan_Bank As Panel
    Friend WithEvents Chbx_Bank_ExtraInfo_achter As RadioButton
    Friend WithEvents Chbx_Bank_ExtraInfo_voor As RadioButton
    Friend WithEvents Lbl_Bank_Extra_Info As Label
    Friend WithEvents Tbx_Bank_Extra_Info As TextBox
    Friend WithEvents Cmx_Bank_bankacc As ComboBox
    Friend WithEvents Label63 As Label
    Friend WithEvents Dgv_Bank_Account As DataGridView
    Friend WithEvents Tbx_Bank_Search As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Tbx_Bank_Description As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Dgv_Bank_Account2 As DataGridView
    Friend WithEvents Label100 As Label
    Friend WithEvents Cmx_Bank_Account As ComboBox
    Friend WithEvents Btn_Bank_Add_Journal As Button
    Friend WithEvents Tbx_Bank_Amount As TextBox
    Friend WithEvents Lbl_Bank_Saldo As Label
    Friend WithEvents Btn_Bank_Split As Button
    Friend WithEvents Label76 As Label
    Friend WithEvents Pan_Bank_jtype As Panel
    Friend WithEvents Label150 As Label
    Friend WithEvents Rbn_Bank_jtype_con As RadioButton
    Friend WithEvents Rbn_Bank_jtype_int As RadioButton
    Friend WithEvents Rbn_Bank_jtype_ext As RadioButton
    Friend WithEvents Dgv_Bank As DataGridView
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TC_Object As TabControl
    Friend WithEvents Contract As TabPage
    Friend WithEvents Lbl_Contract_tgt As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Lbl_Contract_Bronaccount As Label
    Friend WithEvents Cmx_00_Contract__fk_account_id As ComboBox
    Friend WithEvents Tbx_Contract_ttype As TextBox
    Friend WithEvents Cbx_00_contract__active As CheckBox
    Friend WithEvents Lbl_contract_mach_datum As Label
    Friend WithEvents Lbl_contract_macht_kenm As Label
    Friend WithEvents Pan_Contract_Date_New As Panel
    Friend WithEvents Dtp_30_Contract_Change As DateTimePicker
    Friend WithEvents Lbl_contract_new_date As Label
    Friend WithEvents Lbl_00_contract_doeltype As Label
    Friend WithEvents Pan_contract_select_target As Panel
    Friend WithEvents Rbn_00_contract_child As RadioButton
    Friend WithEvents Rbn_00_contract_elder As RadioButton
    Friend WithEvents Rbn_00_contract_other As RadioButton
    Friend WithEvents Lbl_00_contract_autcol As Label
    Friend WithEvents Pic_Contract_Target_photo As PictureBox
    Friend WithEvents Label85 As Label
    Friend WithEvents dtp_contract_relation_date As DateTimePicker
    Friend WithEvents Label80 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Lbl_00_Contract__name As Label
    Friend WithEvents Lbl_Contract_pkid As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Cmx_00_contract__fk_relation_id As ComboBox
    Friend WithEvents Cmx_01_contract__fk_target_id As ComboBox
    Friend WithEvents Cmx_02_Contract__term As ComboBox
    Friend WithEvents Dtp_31_contract__enddate As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents Dtp_31_contract__startdate As DateTimePicker
    Friend WithEvents Label5 As Label
    Friend WithEvents Tbx_00_contract__description As TextBox
    Friend WithEvents Chx_00_contract__autcol As CheckBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Tbx_11_contract__overhead As TextBox
    Friend WithEvents Lbl_Basis_Startdatum As Label
    Friend WithEvents Tbx_contract_period_amt As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Tbx_11_Contract__donation As TextBox
    Friend WithEvents Tbx_01_contract_yeartotal As TextBox
    Friend WithEvents target As TabPage
    Friend WithEvents Tbx_20_Target__childnearby As TextBox
    Friend WithEvents Tbx_20_Target__children As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Rbtn_Target_Alone As RadioButton
    Friend WithEvents Rbtn_Target_Institution As RadioButton
    Friend WithEvents Rbtn_Target_OtherHousing As RadioButton
    Friend WithEvents Label78 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label118 As Label
    Friend WithEvents Cmx_01_Target__fk_cp_id As ComboBox
    Friend WithEvents Pan_Target As Panel
    Friend WithEvents Rbtn_Target_Child As RadioButton
    Friend WithEvents Rbtn_Target_Elder As RadioButton
    Friend WithEvents Rbtn_Target_Other As RadioButton
    Friend WithEvents Cbx_00_target__active As CheckBox
    Friend WithEvents Label75 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Lbl_CP As Label
    Friend WithEvents Lbl_Target_Total_Expenses As Label
    Friend WithEvents Lbl_Target_NameAdd As Label
    Friend WithEvents Tbx_00_Target__living As TextBox
    Friend WithEvents Tbx_10_Target__water As TextBox
    Friend WithEvents Tbx_01_Target__name_add As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Lbl_Target_Name As Label
    Friend WithEvents Tbx_10_Target__benefit As TextBox
    Friend WithEvents Dtp_00_Target__birthday As DateTimePicker
    Friend WithEvents Lbl_Target_Total_Income As Label
    Friend WithEvents Tbx_01_Target__name As TextBox
    Friend WithEvents Lbl_Target_BirthDay As Label
    Friend WithEvents Tbx_10_Target__otherincome As TextBox
    Friend WithEvents Tbx_01_Target__ttype As TextBox
    Friend WithEvents Lbl_Target_Pension As Label
    Friend WithEvents Lbl_Target_Description As Label
    Friend WithEvents Lbl_Target_Type As Label
    Friend WithEvents Tbx_10_Target__pension As TextBox
    Friend WithEvents Lbl_00_Target__reference As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Lbl_Target_Extra As Label
    Friend WithEvents Lbl_Target_pkid As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Tbx_00_Target__description As TextBox
    Friend WithEvents Tbx_10_Target__allowance As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Lbl_Target_Salary As Label
    Friend WithEvents Tbx_10_Target__income As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Lbl_Target_Income As Label
    Friend WithEvents Tbx_00_Target__zip As TextBox
    Friend WithEvents Lbl_Target_Benefit As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Tbx_00_Target__country As TextBox
    Friend WithEvents Lbl_Target_Otherincome As Label
    Friend WithEvents Tbx_10_Target__rent As TextBox
    Friend WithEvents Lbl_Target_Address As Label
    Friend WithEvents Tbx_10_Target__medicine As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Tbx_00_Target__address As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Tbx_10_Target__food As TextBox
    Friend WithEvents Tbx_10_Target__heating As TextBox
    Friend WithEvents Tbx_00_Target__city As TextBox
    Friend WithEvents Tbx_10_Target__gaselectra As TextBox
    Friend WithEvents Pic_Target__photo As PictureBox
    Friend WithEvents Relation As TabPage
    Friend WithEvents Dgv_relation_giften As DataGridView
    Friend WithEvents Lbl_Overzicht_Giften As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Tbx_00_Relation__city As TextBox
    Friend WithEvents Tbx_00_Relation__zip As TextBox
    Friend WithEvents Tbx_00_Relation__phone As TextBox
    Friend WithEvents Tbx_00_Relation__address As TextBox
    Friend WithEvents Tbx_00_Relation__email As TextBox
    Friend WithEvents Tbx_01_relation__name As TextBox
    Friend WithEvents Tbx_01_Relation__name_add As TextBox
    Friend WithEvents Tbx_00_Relation__description As TextBox
    Friend WithEvents Rbn_Relation_6 As RadioButton
    Friend WithEvents Rbn_Relation_5 As RadioButton
    Friend WithEvents Tbx_01_Relation__title As TextBox
    Friend WithEvents Rbn_Relation_4 As RadioButton
    Friend WithEvents Rbn_Relation_3 As RadioButton
    Friend WithEvents Rbn_Relation_2 As RadioButton
    Friend WithEvents Rbn_Relation_1 As RadioButton
    Friend WithEvents Label81 As Label
    Friend WithEvents Cbx_00_relation__active As CheckBox
    Friend WithEvents Dtp_00_relation__date3 As DateTimePicker
    Friend WithEvents Dtp_00_relation__date2 As DateTimePicker
    Friend WithEvents Dtp_00_relation__date1 As DateTimePicker
    Friend WithEvents Label66 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Lbl_00_relation__reference As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Lbl_relation_pkid As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Tbx_00_Relation__iban As TextBox
    Friend WithEvents CP As TabPage
    Friend WithEvents Cbx_00_cp__active As CheckBox
    Friend WithEvents Tbx_00_cp__description As TextBox
    Friend WithEvents Cmx_01_cp__fk_bankacc_id As ComboBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Lbl_CP_pkid As Label
    Friend WithEvents Tbx_00_CP__telephone As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Tbx_01_CP__name As TextBox
    Friend WithEvents Tbx_00_CP__zip As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Tbx_00_CP__country As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents Tbx_00_CP__email As TextBox
    Friend WithEvents Tbx_00_CP__address As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Tbx_00_CP__city As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Tbx_01_CP__name_add As TextBox
    Friend WithEvents Pic_cp__photo As PictureBox
    Friend WithEvents Account As TabPage
    Friend WithEvents Label50 As Label
    Friend WithEvents Cmx_01_account__fk_accgroup_id As ComboBox
    Friend WithEvents Lbl_Account_Doeltype As Label
    Friend WithEvents Lbl_20_Account__f_key As Label
    Friend WithEvents Lbl_Account_Budget_Difference As Label
    Friend WithEvents Label136 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Tbx_10_Account__b_nov As TextBox
    Friend WithEvents Tbx_10_Account__b_dec As TextBox
    Friend WithEvents Tbx_00_Account__bankcode As TextBox
    Friend WithEvents Tbx_10_Account__b_oct As TextBox
    Friend WithEvents Tbx_10_Account__b_aug As TextBox
    Friend WithEvents Tbx_10_Account__b_sep As TextBox
    Friend WithEvents Pan_account As Panel
    Friend WithEvents Rbtn_Account_Income As RadioButton
    Friend WithEvents Rbtn_Account_Transit As RadioButton
    Friend WithEvents Rbtn_Account_Expense As RadioButton
    Friend WithEvents Tbx_10_Account__b_jul As TextBox
    Friend WithEvents Cbx_00_Account__active As CheckBox
    Friend WithEvents Tbx_10_Account__b_may As TextBox
    Friend WithEvents Tbx_10_Account__b_jun As TextBox
    Friend WithEvents Label51 As Label
    Friend WithEvents Tbx_10_Account__b_apr As TextBox
    Friend WithEvents Tbx_00_Account__searchword As TextBox
    Friend WithEvents Tbx_10_Account__b_feb As TextBox
    Friend WithEvents Lbl_00_pkid As Label
    Friend WithEvents Tbx_10_Account__b_mar As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Tbx_10_Account__b_jan As TextBox
    Friend WithEvents Label110 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents Tbx_00_Account__description As TextBox
    Friend WithEvents Label112 As Label
    Friend WithEvents Tbx_01_Account__name As TextBox
    Friend WithEvents Label113 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label114 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label115 As Label
    Friend WithEvents Label122 As Label
    Friend WithEvents Tbx_10_Account__b_year As TextBox
    Friend WithEvents Label109 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label93 As Label
    Friend WithEvents Tbx_00_Account__type As TextBox
    Friend WithEvents Label92 As Label
    Friend WithEvents Lbl_00_Account__source As Label
    Friend WithEvents Label91 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents Label87 As Label
    Friend WithEvents Btn_Account_Budget_All As Button
    Friend WithEvents Btn_Account_Budget_Id As Button
    Friend WithEvents BankAcc As TabPage
    Friend WithEvents Label104 As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents Cbx_00_BankAcc__active As CheckBox
    Friend WithEvents Label53 As Label
    Friend WithEvents Cmx_01_BankAcc__currency As ComboBox
    Friend WithEvents Tbx_00_BankAcc__bic As TextBox
    Friend WithEvents Tbx_01_BankAcc__name As TextBox
    Friend WithEvents Tbx_00_BankAcc__id2 As TextBox
    Friend WithEvents Lbl_BankAcc_pkid As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Chx_00_BankAcc__expense As CheckBox
    Friend WithEvents Tbx_01_BankAcc__owner As TextBox
    Friend WithEvents Cbx_00_BankAcc__income As CheckBox
    Friend WithEvents Tbx_00_BankAcc__description As TextBox
    Friend WithEvents Tbx_01_BankAcc__accountno As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Tbx_BankAcc_startbalance As TextBox
    Friend WithEvents Label40 As Label
    Friend WithEvents Accgroup As TabPage
    Friend WithEvents Tbx_00_Accgroup__description As TextBox
    Friend WithEvents Label130 As Label
    Friend WithEvents Tbx_00_Accgroup__subtype As TextBox
    Friend WithEvents Label137 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Rbtn_accgroup_Income As RadioButton
    Friend WithEvents Rbtn_accgroup_transit As RadioButton
    Friend WithEvents Rbtn_accgroup_expense As RadioButton
    Friend WithEvents Cbx_00_accgroup__active As CheckBox
    Friend WithEvents Label132 As Label
    Friend WithEvents Lbl_accgroup_pkid As Label
    Friend WithEvents Label134 As Label
    Friend WithEvents Label135 As Label
    Friend WithEvents Tbx_01_Accgroup__name As TextBox
    Friend WithEvents Tbx_01_Accgroup__type As TextBox
    Friend WithEvents TC_Main As TabControl
    Friend WithEvents Panel11 As Panel
    Friend WithEvents ReportTree As TreeView
    Friend WithEvents Label119 As Label
    Friend WithEvents Btn_Rap_Expand_Collapse As Button
    Friend WithEvents Cmbx_Reporting_Year As ComboBox
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Lbl_Rapportage_Detail As Label
    Friend WithEvents Dgv_Report_6 As DataGridView
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Dgv_Rapportage_Overzicht As DataGridView
    Friend WithEvents LbL_Formatting As Label
    Friend WithEvents Lbl_Rapportage As Label
    Friend WithEvents Splitter_left As Splitter
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents Label123 As Label
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Dgv_Uitkering_Account_Details As DataGridView
    Friend WithEvents Splitter2 As Splitter
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Splitter3 As Splitter
    Friend WithEvents Tbx_ As TextBox
    Friend WithEvents Tbx_Journal_Saldo As TextBox
    Friend WithEvents Tbx_Journal_Debit As TextBox
    Friend WithEvents Tbx_Journal_Credit As TextBox
    Friend WithEvents Splitter4 As Splitter
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Rbtn_Overboekingen_alles As RadioButton
    Friend WithEvents Rbtn_Overboekingen_Oudere As RadioButton
    Friend WithEvents Rbtn_Overboekingen_Kind As RadioButton
    Friend WithEvents Accounts As TabPage
    Friend WithEvents Panel17 As Panel
    Friend WithEvents AccountTree As TreeView
    Friend WithEvents Btn_Boeking_Expand_Collapse As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Lbx_Basis As ListBox
    Friend WithEvents Rbn_Incasso_Verschillen As RadioButton
    Friend WithEvents Dgv_incasso_totals As DataGridView
    Friend WithEvents TP_Test As TabPage
    Friend WithEvents TreeView1 As TreeView
    Friend WithEvents Button5 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Pan_Test As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Chbx_test As CheckBox
    Friend WithEvents Dgv_Mgnt_Tables As DataGridView
    Friend WithEvents Lbl_Rel_id As Label
    Friend WithEvents Searchbox2 As TextBox
    Friend WithEvents Zoeken As Label
    Friend WithEvents Testpanel As Panel
    Friend WithEvents Cbx_LifeCycle2 As ComboBox
    Friend WithEvents Pan_Bank2 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Tbx_Transactie_totaal As TextBox
    Friend WithEvents Tbx_Bank_Afschrift As TextBox
    Friend WithEvents Tbx_Bank_Code As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Tbx_Bank_Relation_account As TextBox
    Friend WithEvents Label72 As Label
    Friend WithEvents Tbx_Bank_Relation As TextBox
    Friend WithEvents Label73 As Label
End Class
